"""从 中期报告_2.3_草稿.md 生成 docx。"""
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_LINE_SPACING
from docx.oxml.ns import qn
import re

ROOT = Path(__file__).resolve().parent.parent
MD = ROOT / "docs" / "中期报告_2.3_草稿.md"
OUT = ROOT / "docs" / "中期报告_2.3_分桶编码_v5.docx"


def add_paragraph(doc, text, bold=False, italic=False, font_name="宋体", font_size=12):
    """添加一个段落，固定 20 磅行距，无缩进。"""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = WD_LINE_SPACING.EXACTLY
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.line_spacing = Pt(20)
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.first_line_indent = Pt(0)
    run = p.add_run(text)
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), font_name)
    run.font.size = Pt(font_size)
    run.bold = bold
    run.italic = italic
    return p


def add_formula_paragraph(doc, text, font_size=12):
    """公式段落：Cambria Math + 斜体，居中。"""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = WD_LINE_SPACING.EXACTLY
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.line_spacing = Pt(24)  # 公式行稍大
    pf.space_before = Pt(6)
    pf.space_after = Pt(6)
    pf.first_line_indent = Pt(0)
    pf.alignment = 1  # 居中
    run = p.add_run(text)
    run.font.name = "Cambria Math"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(font_size)
    run.italic = True
    return p


def main():
    text = MD.read_text(encoding="utf-8")
    lines = text.strip().split("\n")

    doc = Document()

    # 设置默认字体
    style = doc.styles["Normal"]
    style.font.name = "宋体"
    style.font.size = Pt(12)
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    pf = style.paragraph_format
    pf.line_spacing = Pt(20)
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.first_line_indent = Pt(0)

    # 页面边距
    for section in doc.sections:
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(3.17)
        section.right_margin = Cm(3.17)

    i = 0
    while i < len(lines):
        line = lines[i]

        # 空行
        if line.strip() == "":
            i += 1
            continue

        # 图占位行
        if line.strip().startswith("[图") and ("插入位置" in line or "outputs/" in line):
            add_paragraph(doc, line.strip(), font_size=9)
            i += 1
            continue

        # 公式块 \[ ... \]
        if line.strip() == "\\[":
            # 收集直到 \]
            formula_lines = []
            i += 1
            while i < len(lines) and lines[i].strip() != "\\]":
                formula_lines.append(lines[i].strip())
                i += 1
            i += 1  # 跳过 \]
            formula_text = " ".join(formula_lines)
            add_formula_paragraph(doc, formula_text)
            continue

        # 普通段落
        # 合并连续非空行作为一个段落
        para_lines = [line]
        i += 1
        while i < len(lines) and lines[i].strip() != "":
            if lines[i].strip().startswith("[图") and "插入位置" in lines[i]:
                break
            if lines[i].strip() == "\\[":
                break
            para_lines.append(lines[i])
            i += 1
        para_text = "".join(para_lines)
        add_paragraph(doc, para_text)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(OUT))
    print(f"saved: {OUT}")


if __name__ == "__main__":
    main()
