"""显式定位/均匀量化各自修补前后四线对照，默认使用未参与选优的验证图。"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from vit_iaq_semcom.experiment import split_indices, provenance, paired_repair_evaluation
from vit_iaq_semcom.repair_channel import configure_repair_channel
from vit_iaq_semcom.training import save_metrics


def validate_comparable(checkpoints):
    """禁止把不同训练设置或预算的模型标作公平对照。最佳轮次允许不同。"""
    for mode, ckpt in checkpoints.items():
        if ckpt.get("schema_version") != 2 or ckpt.get("protocol", {}).get("transmission_mode") != mode:
            raise ValueError(f"Expected a newly trained {mode} checkpoint")
        if not ckpt.get("net_config", {}).get("receiver_conditioning"):
            raise ValueError("Both models must use the same receiver-conditioned architecture")
    a, b = checkpoints["addressed"], checkpoints["uniform"]
    if not a.get("selection_run") or a["selection_run"] != b.get("selection_run"):
        raise ValueError("Unmatched completed training epochs or target training budget")
    for key in ("net_config", "resume_config"):
        if a[key] != b[key]:
            raise ValueError(f"Unmatched training settings: {key}")
    for key in ("train_indices", "validation_indices", "seed", "split_seed", "validation_size",
                "batch_size", "lr", "lambda_mse", "snr_train"):
        if a["training"][key] != b["training"][key]:
            raise ValueError(f"Unmatched training settings: {key}")
    if a["training"]["channel_budget"]["cap"] != b["training"]["channel_budget"]["cap"]:
        raise ValueError("Training channel budgets differ")
    for key in ("arch", "classifier_weights", "preprocessing", "quantization_range", "range_policy", "m_max"):
        if a["protocol"][key] != b["protocol"][key]:
            raise ValueError(f"Unmatched classifier or quantization: {key}")


def plot_report(result, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    fig, ax = plt.subplots(figsize=(8, 5))
    lines = ["# 修补训练四线对照", "",
             f"样本数 {result['n']}；划分 {result['evaluation_split']}；信道种子 {result['seeds']}；两组训练设置已核对。",
             "本图只反映所加载模型的实际表现。小规模冒烟权重不能作为修补收益证据。误差条为信道种子间标准差，不是泛化区间。", "",
             "| SNR/dB | 协议 | 修补前 | 修补后 | 净增益/百分点 | 救回率 | 修坏率 | 实际发送 bit/图 |",
             "|---|---|---:|---:|---:|---:|---:|---:|"]
    for mode, label in (("uniform", "均匀量化"), ("addressed", "显式定位")):
        for key, suffix in ((mode, ""), (mode+"_repair", "+修补")):
            means = [100*result["summary"][str(snr)][mode][key]["mean"] for snr in result["snrs"]]
            std = [100*result["summary"][str(snr)][mode][key]["std"] for snr in result["snrs"]]
            ax.errorbar(result["snrs"], means, yerr=std, fmt="o-", capsize=3, label=label+suffix)
        for snr in result["snrs"]:
            s = result["summary"][str(snr)][mode]
            pct = lambda key: f"{100*s[key]['mean']:.1f}%"
            lines.append(f"| {snr:g} | {label} | {pct(mode)} | {pct(mode+'_repair')} | "
                         f"{100*s['ai_gain']['mean']:+.1f} | {pct('rescued_rate')} | {pct('harmful_repair_rate')} | {result['budgets'][mode]['total']} |")
    ax.set(xlabel="发送编码比特能量 / N0（dB）", ylabel="分类准确率 / %", ylim=(-3, 103),
           xticks=result["snrs"], title=f"配对修补评估 · n={result['n']} · ±1 信道种子标准差")
    ax.grid(alpha=.2)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path.with_suffix(".png"), dpi=160)
    plt.close(fig)
    lines += ["", "- 每种协议仅生成一次受损输入，修补前后共用该输入，修补不增加发送比特。",
              "- 两个模型使用相同架构、训练样本、初始化种子、批大小、训练 SNR 序列和选优设置；按各自最佳验证轮次加载。",
              "- 不同协议的像素码流不同；同名噪声种子不代表每个像素有相同的比特误码。",
              "- 新协议评估按有序样本连续消耗信道随机流；不能与按样本 ID 派生随机流的定位探针直接混合比较。",
              "- 默认验证样本排除修补训练和模型选优图；分类器曾在 CIFAR-100 训练集微调，仍不能替代最终测试。",
              f"- 所加载最佳轮次：{result['selected_epochs']}。", ""]
    path.with_suffix(".md").write_text("\n".join(lines), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--addressed-ckpt")
    ap.add_argument("--uniform-ckpt")
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--split", choices=("validation", "test"), default="validation")
    ap.add_argument("--n", type=int, default=96)
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--sample-offset", type=int, help="默认跳过全部选优验证图")
    ap.add_argument("--snrs", default="0,6,12")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--out", type=Path, default=Path("outputs/corrected/repair_comparison.json"))
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--replot", type=Path)
    args = ap.parse_args()
    if args.replot:
        result = json.loads(args.replot.read_text(encoding="utf-8"))
        if not result.get("complete"):
            ap.error("Cannot plot incomplete results")
        plot_report(result, args.replot)
        return
    if not args.addressed_ckpt or not args.uniform_ckpt:
        ap.error("Provide both new-protocol checkpoints")
    if min(args.n, args.batch) < 1 or args.out.suffix != ".json":
        ap.error("Positive sample/batch counts and .json output required")
    if not args.overwrite and any(args.out.with_suffix(s).exists() for s in (".json", ".md", ".png")):
        ap.error("Output exists; choose a new path or --overwrite")
    snrs, seeds = [float(v) for v in args.snrs.split(",")], [int(v) for v in args.seeds.split(",")]
    if not np.isfinite(snrs).all() or len(set(snrs)) != len(snrs) or min(seeds) < 0 or len(set(seeds)) != len(seeds):
        ap.error("Use distinct finite SNRs and distinct nonnegative seeds")
    import torch
    import torchvision
    import yaml
    from torch.utils.data import DataLoader, Subset
    from vit_iaq_semcom.pipeline import IAQPipeline
    paths = dict(addressed=args.addressed_ckpt, uniform=args.uniform_ckpt)
    checkpoints = {mode: torch.load(path, map_location="cpu", weights_only=True) for mode, path in paths.items()}
    validate_comparable(checkpoints)
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    cfg["device"] = args.device
    pipe = IAQPipeline.from_config(cfg)
    training = checkpoints["addressed"]["training"]
    ds = torchvision.datasets.CIFAR100(args.data_root, train=args.split == "validation", download=True,
                                        transform=pipe.enc.transform)
    if args.split == "validation":
        _, indices = split_indices(len(ds), training["validation_size"], training["split_seed"])
        offset = len(training["validation_indices"]) if args.sample_offset is None else args.sample_offset
    else:
        indices = list(range(len(ds)))
        offset = args.sample_offset or 0
    if offset < 0 or offset + args.n > len(indices):
        ap.error("Requested evaluation window exceeds partition")
    ids = indices[offset:offset+args.n]
    if args.split == "validation" and set(ids) & set(training["train_indices"]+training["validation_indices"]):
        ap.error("Evaluation overlaps repair training or model-selection samples")
    loader = DataLoader(Subset(ds, ids), batch_size=args.batch)
    result = dict(complete=False, n=args.n, sample_ids=ids, sample_offset=offset,
                  evaluation_split=args.split, snrs=snrs, seeds=seeds, batch=args.batch,
                  checkpoints=paths, selected_epochs={m: c["epoch"] for m, c in checkpoints.items()},
                  training_epochs=checkpoints["addressed"]["selection_run"],
                  protocols={}, budgets={}, runs={str(s): {} for s in snrs}, provenance=provenance())
    for mode, path in paths.items():
        c = checkpoints[mode]
        t, p = c["training"], c["protocol"]
        buckets, budget = configure_repair_channel(pipe, mode, t["b_target"], t["m_base"],
                                                   t["base_fec_r"], p["buckets"], t["location_fec_r"])
        net = pipe.load_repair_net(path)
        pipe.validate_repair_protocol(t["m_base"], t["base_fec_r"], buckets, mode, t["location_fec_r"])
        result["protocols"][mode], result["budgets"][mode] = p, budget
        for snr in snrs:
            result["runs"][str(snr)][mode] = {}
            for seed in seeds:
                value = paired_repair_evaluation(pipe, net, loader, snr, t["m_base"],
                    t["base_fec_r"], buckets, seed, mode=mode, location_fec_r=t["location_fec_r"],
                    channel_budget=budget["cap"])
                for sample_id, row in zip(ids, value["predictions"]):
                    row["sample_id"] = sample_id
                result["runs"][str(snr)][mode][str(seed)] = value
                save_metrics(result, args.out)
                print(f"{mode} {snr:g}dB seed={seed}: gain={value['ai_gain']:+.4f}", flush=True)
    result["summary"] = {str(snr): {mode: {key: {
        "mean": float(np.mean([r[key] for r in runs.values()])),
        "std": float(np.std([r[key] for r in runs.values()]))}
        for key in (mode, mode+"_repair", "ai_gain", "rescued_rate", "harmful_repair_rate")}
        for mode, runs in result["runs"][str(snr)].items()} for snr in snrs}
    result["complete"] = True
    save_metrics(result, args.out)
    plot_report(result, args.out)


if __name__ == "__main__":
    main()
