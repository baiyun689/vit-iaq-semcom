"""生成固定训练矩阵；显式 --execute 才串行训练，默认只保存可审阅计划。"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

from vit_iaq_semcom.ablation import VARIANTS
from vit_iaq_semcom.training import save_metrics

ROOT = Path(__file__).resolve().parents[1]


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build_plan(out_dir, profile="formal", seeds=None, overrides=None):
    settings = (dict(device="cpu", n_train=2, n_val=2, epochs=1, batch=1, dim=24, depth=1, heads=3,
                     eval_n=2, eval_seeds="0,1") if profile == "smoke" else
                dict(device="cuda", n_train=45000, n_val=1000, epochs=10, batch=64, dim=192, depth=4, heads=3,
                     eval_n=1000, eval_seeds="0,1,2"))
    settings.update({k: v for k, v in (overrides or {}).items() if v is not None})
    seeds = seeds if seeds is not None else ([0] if profile == "smoke" else [0, 1, 2])
    if not seeds or min(seeds) < 0 or len(seeds) != len(set(seeds)):
        raise ValueError("Training seeds must be distinct nonnegative integers")
    offset = max(120, settings["n_val"])
    if (min(settings[k] for k in ("n_train", "n_val", "epochs", "batch", "eval_n")) < 1
            or settings["n_train"] > 45000 or offset+settings["eval_n"] > 5000):
        raise ValueError("Invalid counts or validation window exceeds reserved partition")
    out_dir = Path(out_dir).resolve()
    jobs = []
    for seed in seeds:
        base = out_dir/f"seed_{seed}"
        for name, (mode, conditioning, regime) in VARIANTS.items():
            folder = base/name
            args = [sys.executable, "-u", "scripts/run_repair_train.py", "--mode", mode,
                    "--conditioning", conditioning, "--device", settings["device"], "--seed", str(seed),
                    "--snr-lo", "6" if regime == "single" else "0", "--snr-hi", "6" if regime == "single" else "12",
                    "--eval-snrs", "0,6,12", "--b_target", "392", "--validation-size", "5000", "--split-seed", "0"]
            for key in ("n_train", "n_val", "epochs", "batch", "dim", "depth", "heads"):
                args += ["--"+key.replace("_", "-"), str(settings[key])]
            args += ["--out", str(folder/"metrics.json"), "--ckpt", str(folder/"best.pt")]
            jobs.append(dict(id=f"seed_{seed}/{name}", kind="train", argv=args,
                outputs=[str(folder/p) for p in ("metrics.json", "best.pt", "best.last.pt")],
                log=str(folder/"run.log"), last_checkpoint=str(folder/"best.last.pt")))
        output = base/"ablation.json"
        args = [sys.executable, "-u", "scripts/run_repair_ablation.py", "--checkpoint-root", str(base),
                "--device", settings["device"], "--n", str(settings["eval_n"]), "--batch", str(settings["batch"]),
                "--sample-offset", str(offset), "--snrs", "0,6,12", "--seeds", settings["eval_seeds"], "--out", str(output)]
        jobs.append(dict(id=f"seed_{seed}/evaluation", kind="evaluate", argv=args,
                         outputs=[str(output.with_suffix(s)) for s in (".json", ".md", ".png")], log=str(base/"evaluation.log")))
    sources = list((ROOT/"src/vit_iaq_semcom").glob("*.py")) + [ROOT/"scripts"/name for name in
        ("run_repair_train.py", "run_repair_ablation.py", "run_repair_suite.py")]
    return dict(profile=profile, settings=settings, training_seeds=seeds, evaluation_offset=offset,
                purpose="smoke only" if profile == "smoke" else "predeclared validation experiment; final test unused",
                config_sha256=file_hash(ROOT/"configs/default.yaml"),
                source_sha256={p.relative_to(ROOT).as_posix(): file_hash(p) for p in sources}, jobs=jobs)


def execute_plan(plan, out_dir):
    """串行运行；已确认完成的文件校验后跳过，失败训练可从完整轮次恢复。"""
    state_path = Path(out_dir)/"state.json"
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {"jobs": {}}
    for job in plan["jobs"]:
        record = state["jobs"].get(job["id"], {})
        if record.get("status") == "complete":
            if any(not Path(p).exists() or file_hash(p) != expected for p, expected in record["output_sha256"].items()):
                raise ValueError(f"Completed artifacts changed: {job['id']}")
            continue
        command = list(job["argv"])
        if any(Path(p).exists() for p in job["outputs"]):
            if job["kind"] != "train" or not Path(job["last_checkpoint"]).exists():
                raise ValueError(f"Partial artifacts require review or a new output directory: {job['id']}")
            import torch
            latest = torch.load(job["last_checkpoint"], map_location="cpu", weights_only=True)
            if latest["epoch"] >= plan["settings"]["epochs"]:
                raise ValueError(f"Completed epoch without verified suite state; review artifacts: {job['id']}")
            command += ["--resume", job["last_checkpoint"], "--overwrite"]
        log = Path(job["log"])
        log.parent.mkdir(parents=True, exist_ok=True)
        state["jobs"][job["id"]] = {"status": "running"}
        save_metrics(state, state_path)
        print(f"Starting {job['id']}; log: {log}", flush=True)
        try:
            env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
            with log.open("a", encoding="utf-8") as stream:
                subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
            hashes = {p: file_hash(p) for p in job["outputs"]}
        except BaseException:
            state["jobs"][job["id"]] = {"status": "failed", "log": str(log)}
            save_metrics(state, state_path)
            raise
        state["jobs"][job["id"]] = {"status": "complete", "output_sha256": hashes}
        save_metrics(state, state_path)
        print(f"Completed {job['id']}", flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--profile", choices=("smoke", "formal"), default="formal")
    ap.add_argument("--seeds", help="训练种子，默认正式 0,1,2；流程验证 0")
    ap.add_argument("--execute", action="store_true")
    for key in ("n-train", "n-val", "epochs", "batch", "eval-n"):
        ap.add_argument("--"+key, type=int)
    args = ap.parse_args()
    overrides = {key: getattr(args, key) for key in ("n_train", "n_val", "epochs", "batch", "eval_n")}
    plan = build_plan(args.out_dir, args.profile, [int(s) for s in args.seeds.split(",")] if args.seeds else None, overrides)
    destination = args.out_dir/"plan.json"
    if destination.exists():
        if json.loads(destination.read_text(encoding="utf-8")) != plan:
            ap.error("Existing plan differs in configuration, sources or environment; choose a new directory")
    else:
        if args.out_dir.exists() and any(args.out_dir.iterdir()):
            ap.error("Output directory is not empty and has no matching plan")
        save_metrics(plan, destination)
    print(f"Saved plan: {destination.resolve()}; {len(plan['jobs'])} sequential jobs", flush=True)
    if args.execute:
        execute_plan(plan, args.out_dir)
    else:
        print("Plan only; no training launched. Use --execute on the intended training machine.")


if __name__ == "__main__":
    main()
