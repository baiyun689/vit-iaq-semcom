// Generate draw.io browser URL from .drawio file
const fs = require("fs");
const zlib = require("zlib");
const path = require("path");
const os = require("os");

const drawioFile = process.argv[2]; // e.g. "outputs/repair_network_arch.drawio"

const xml = fs.readFileSync(drawioFile, "utf8");
const compressed = zlib.deflateRawSync(Buffer.from(encodeURIComponent(xml))).toString("base64");
const payload = encodeURIComponent(JSON.stringify({ type: "xml", compressed: true, data: compressed }));
const url = "https://app.diagrams.net/?grid=0&pv=0&border=10&edit=_blank#create=" + payload;

// Write .url file for Windows
const urlFile = path.join(os.tmpdir(), "drawio.url");
fs.writeFileSync(urlFile, "[InternetShortcut]\r\nURL=" + url + "\r\n");

// Print both
console.log("URL_LENGTH:", url.length);
console.log("URL_FILE:", urlFile);
