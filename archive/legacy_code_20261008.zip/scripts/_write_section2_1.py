"""Write section 2.1 to mid-term report .doc"""
import win32com.client, time, pythoncom

PARAGRAPHS = [
    # (text, bold, indent)
    ("二、目前已完成学位论文工作的内容\r", True, False),
    ("（主要包括所完成的理论和实验研究以及所获得的结论。）\r", False, True),
    ("2.1 实验系统与基线建立\r", True, False),

    (
        "本研究以 ViT 注意力驱动的显式重要性感知图像分类传输为实验验证平台，"
        "建立了完整的端到端管线。管线由五个核心模块串联构成：ViT 编码器提取各图像区域的"
        "注意力分数并据此执行差异化比特分配，均匀量化器将各区域像素值按分配的比特数转换为"
        "比特流，数字调制与信道模块完成基带信号到信道符号的映射并叠加噪声，收端从受损符号"
        "中恢复比特流并反量化重建图像，最后将重建图送入冻结的预训练分类器获得分类结果。"
        "以下逐一说明各模块的功能与设计要点。\r",
        False, True
    ),

    (
        "ViT 编码器与注意力分数提取。选用预训练 ViT（DeiT-Tiny 或 ViT-Base）作为"
        "冻结的特征提取器，不参与任何训练。输入图像 x(H×W×3) 被划分为 N = 196 个"
        "非重叠 patch，经线性投影后与位置编码及 class token 拼接送入 Transformer 编码器。"
        "设最后一层 Transformer 的 class token 对各 patch token 的注意力权重为 a_i"
        "（i = 1, 2, ..., N），则 a_i 反映了第 i 个 patch 对分类决策的相对贡献——"
        "a_i 越大，该 patch 包含的判别性语义信息越丰富。本研究将 {a_i} 作为"
        "“语义重要性”的定量代理，后续所有差异化分配均据此排序。图 1 给出了典型"
        "CIFAR-100 样本的注意力热图，可见 ViT 的注意力自然地集中在目标物体区域"
        "（前景），背景区域注意力显著偏低，验证了以注意力分数指导差异化资源分配"
        "的合理性。\r",
        False, True
    ),
    ("[图 1 插入位置：outputs/attention_fig3.png — 原图与注意力热图并排，标注 ViT 模型与数据集]\r", False, True),

    (
        "差异化比特分配。给定总比特预算 B_target（即 N 个 patch 共用比特数的总和，"
        "本研究工作点取 392 或 980），增量分配算法以注意力分数 {a_i} 为导向，贪心地为"
        "高注意力 patch 逐个追加量化比特，直至预算耗尽。设第 i 个 patch 最终分配比特数为"
        " M_i，总约束为 Σ_i M_i ≤ B_target。该离散分配问题在均匀量化失真模型下有"
        "贪心最优性：每次向当前期望失真最大的 patch 追加 1 bit 可使总体失真下降最大。"
        "最终产生的分配方案 {M_i} 呈非增分布——重要 patch 获得更多比特（可达 7–8 bit），"
        "不重要 patch 获得更少（可低至 1 bit），从而将有限带宽集中投向判别性关键区域。\r",
        False, True
    ),

    (
        "均匀量化与数字信道传输。各 patch 的像素值在给定 M_i 下执行标量均匀量化："
        "将像素值范围均匀划分为 2^{M_i} 个区间，每个区间映射为一个 M_i bit 的二进制"
        "索引，收端以区间中点作为重建值。量化后的比特流经 BPSK 调制映射为 ±1 符号"
        "序列，通过加性白高斯噪声（AWGN）信道或二元对称信道（BSC）。收端采用硬判决"
        "解调恢复比特流，在给定误比特率 p_e 下，各 patch 的量化索引以一定概率发生比特"
        "翻转。反量化模块按 {M_i} 逐 patch 将比特索引映射回重建像素值，"
        "得到重建图像 x̂。\r",
        False, True
    ),

    (
        "分类与评估指标。重建图像 x̂ 送入冻结的预训练分类器（与前述 ViT 编码器"
        "共享 backbone）获得类别预测 ŷ。管线以 Top-1 分类准确率作为核心评价指标，"
        "辅以重建图像的结构相似度（SSIM）作为诊断信号——SSIM 对结构崩塌敏感，"
        "是检测级联失步的有效探针。所有实验在 CIFAR-100 数据集上开展，该数据集含"
        "100 个类别、60 000 张 32×32 彩色图像，分类难度适中，便于快速迭代验证。\r",
        False, True
    ),

    (
        "干净信道基线验证。在无误码条件下（p_e = 0，等价于元信息通过理想信道直达收端），"
        "对差异化分配与均匀分配（所有 patch 分配等量比特，无差异化）进行对比。在总比特"
        "预算 B_target = 980（码率 ρ ≈ 0.625 bit/pixel）下，差异化分配方案较均匀分配"
        "实现约 14 个百分点的 Top-1 准确率提升。该结果表明：在干净信道条件下，"
        "以 ViT 注意力为引导的显式差异化分配能有效将有限带宽聚焦于判别性关键区域，"
        "其性能增益完全来自“把比特用在更重要的地方”这一设计选择，而非编码器结构的"
        "改进。此基线同时界定了显式重要性感知路径的性能上界——后续所有含信道噪声的"
        "实验均应以此为准绳，衡量噪声引入的性能退化量。\r",
        False, True
    ),

    (
        "上述管线与基线构成了完整的实验基础设施，其模块化设计使各环节可独立替换或"
        "增强：后续 2.2 节将在该管线中开启元信息过信道以量化级联崩塌效应；2.3 节将"
        "以非级联粗桶编码替换变长码流结构；2.4 节将在收端引入语义修补网络。\r",
        False, True
    ),
]


def main():
    pythoncom.CoInitialize()
    word = win32com.client.Dispatch('Word.Application')
    word.Visible = False
    word.DisplayAlerts = 0
    doc = None
    try:
        doc = word.Documents.Open(r'C:\Users\BAI\Desktop\中期答辩\中期报告-白云飞.doc')
        time.sleep(1)

        cell = doc.Tables(2).Cell(1, 1)
        cell.Range.Text = ""

        for text, bold, indent in PARAGRAPHS:
            rng = cell.Range
            rng.End = rng.End - 1  # exclude end-of-cell marker
            rng.Collapse(0)  # collapse to end
            rng.Text = text
            rng.Font.Name = '宋体'
            rng.Font.Size = 12
            rng.Font.Bold = bold
            rng.ParagraphFormat.LineSpacingRule = 3
            rng.ParagraphFormat.LineSpacing = 20
            rng.ParagraphFormat.SpaceBefore = 0
            rng.ParagraphFormat.SpaceAfter = 0
            rng.ParagraphFormat.FirstLineIndent = 24 if indent else 0

        doc.Save()
        print("Done - section 2.1 written to Table 2.")

    finally:
        if doc:
            try: doc.Close(SaveChanges=1)
            except: pass
        try: word.Quit()
        except: pass
        pythoncom.CoUninitialize()


if __name__ == '__main__':
    main()
