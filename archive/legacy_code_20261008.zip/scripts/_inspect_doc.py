"""深度检查:搜索VML imagedata和其他非标准图片引用"""
import zipfile
import re

docx_path = r"C:\Users\BAI\Desktop\中期答辩\中期报告-白云飞.docx"

with zipfile.ZipFile(docx_path) as z:
    xml = z.read('word/document.xml').decode('utf-8')

    # 搜索VML imagedata
    vml_imgs = re.findall(r'<v:imagedata[^>]*>', xml)
    print(f"VML imagedata: {len(vml_imgs)}")
    for i, v in enumerate(vml_imgs[:5]):
        print(f"  [{i}] {v[:200]}")

    # 搜索所有包含image的XML片段
    segments = re.findall(r'<[^>]*image[^>]*>', xml, re.IGNORECASE)
    print(f"\n包含'image'标签: {len(segments)}")
    for s in segments[:5]:
        print(f"  {s[:200]}")

    # 搜索w:pict (VML picture)
    picts = re.findall(r'<w:pict>.*?</w:pict>', xml, re.DOTALL)
    print(f"\nw:pict元素: {len(picts)}")
    for i, p in enumerate(picts[:3]):
        # 显示前500字符
        print(f"  [{i}] {p[:500]}")

    # 搜索rId引用模式
    rids = set(re.findall(r'r:id="([^"]+)"', xml))
    print(f"\n所有rId引用: {len(rids)}")
    # 筛选可能的图片rId (通常是rIdXX格式)
    img_rids = [r for r in rids if r.startswith('rId')]
    for r in sorted(img_rids, key=lambda x: int(re.sub(r'\D', '', x) or 0)):
        print(f"  {r}")

    # 检查relationship文件确认哪些rId指向图片
    rels_xml = z.read('word/_rels/document.xml.rels').decode('utf-8')
    all_rels = re.findall(r'<Relationship[^>]*>', rels_xml)
    print(f"\n===== 所有Relationships =====")
    for rel in all_rels:
        rid = re.search(r'Id="([^"]*)"', rel)
        target = re.search(r'Target="([^"]*)"', rel)
        rtype = re.search(r'Type="([^"]*)"', rel)
        rid_s = rid.group(1) if rid else '?'
        target_s = target.group(1) if target else '?'
        type_s = rtype.group(1).split('/')[-1] if rtype else '?'
        if 'image' in type_s.lower() or 'png' in target_s.lower() or 'wmf' in target_s.lower():
            print(f"  {rid_s}: {target_s} ({type_s})")
