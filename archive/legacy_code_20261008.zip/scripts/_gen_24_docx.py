"""从 中期报告_2.4_草稿.md 生成 docx（含架构图）。"""
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm, Inches
from docx.enum.text import WD_LINE_SPACING, WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent.parent
MD = ROOT / "docs" / "中期报告_2.4_草稿.md"
OUT = ROOT / "docs" / "中期报告_2.4_修补网络_v15.docx"
FIG_RE = re.compile(r"^!\[(.+?)\]\((.+?)\)$")  # ![alt](path)


def add_image(doc, fig_path: Path, caption: str):
    """居中插入图片 + 图题。"""
    # 图片
    p_img = doc.add_paragraph()
    p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf = p_img.paragraph_format
    pf.line_spacing = Pt(20)
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.space_before = Pt(6)
    pf.space_after = Pt(0)
    pf.first_line_indent = Pt(0)
    run = p_img.add_run()
    run.add_picture(str(fig_path), width=Inches(5.5))

    # 图题（居中，宋体小五 9pt）
    p_cap = doc.add_paragraph()
    p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf2 = p_cap.paragraph_format
    pf2.line_spacing = Pt(20)
    pf2.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf2.space_before = Pt(0)
    pf2.space_after = Pt(6)
    pf2.first_line_indent = Pt(0)
    run2 = p_cap.add_run(caption)
    run2.font.name = "宋体"
    run2._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    run2.font.size = Pt(9)


def add_paragraph(doc, text, bold=False, font_name="宋体", font_size=12):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = Pt(20)
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.first_line_indent = Pt(0)
    run = p.add_run(text)
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), font_name)
    run.font.size = Pt(font_size)
    run.bold = bold
    return p


def main():
    text = MD.read_text(encoding="utf-8")
    lines = text.strip().split("\n")

    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "宋体"
    style.font.size = Pt(12)
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    pf = style.paragraph_format
    pf.line_spacing = Pt(20)
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.first_line_indent = Pt(0)

    for section in doc.sections:
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(3.17)
        section.right_margin = Cm(3.17)

    i = 0
    while i < len(lines):
        line = lines[i]

        # 跳过空行
        if line.strip() == "":
            i += 1
            continue

        # 图片行: ![caption](path)
        m = FIG_RE.match(line.strip())
        if m:
            caption, rel_path = m.group(1), m.group(2)
            fig_path = (MD.parent / rel_path).resolve()
            if fig_path.exists():
                add_image(doc, fig_path, caption)
            else:
                add_paragraph(doc, f"[图片缺失: {rel_path}]")
            i += 1
            continue

        # 普通段落：空行分隔
        para_lines = [line]
        i += 1
        while i < len(lines) and lines[i].strip() != "":
            # 图片行不归入段落
            if FIG_RE.match(lines[i].strip()):
                break
            para_lines.append(lines[i])
            i += 1
        para_text = "".join(para_lines)
        add_paragraph(doc, para_text)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(OUT))
    print(f"saved: {OUT}")


if __name__ == "__main__":
    main()
