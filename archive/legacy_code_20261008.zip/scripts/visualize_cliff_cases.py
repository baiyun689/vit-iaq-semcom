"""答辩展示图: IAQ 元信息过信道(级联崩坏) vs 粗桶(局部损伤) 接收端图像对比。

与 visualize_repair_cases.py 同口径(SNR=6dB, b392, 同 seed):
  左列: IAQ 增量分配 + 元信息过 AWGN → 级联崩坏(结构性破坏 → SSIM 暴跌)
  右列: 粗桶非级联编码 → 局部错配(结构完整 → SSIM 温和下降)

评估指标: SSIM(结构性相似度)为主、PSNR 为辅。
  SSIM 对结构崩坏敏感:元信息错 → 游标偏移 → 图像完全错位 → SSIM≈0;
  粗桶局部错配仅让 SSIM 温和下降,完美量化"结构性破坏 vs 局部损伤"的差异。

用法(强制 CPU, 符合本机控温):
    python scripts/visualize_cliff_cases.py --snr 0 --n-stat 256 --n-show 4
    python scripts/visualize_cliff_cases.py --indices 0,5,11,23 --snr 3
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import torch
import torchvision
import yaml

matplotlib.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False

from vit_iaq_semcom.channel import awgn_channel
from vit_iaq_semcom.pipeline import IAQPipeline, _from_patches


# ------------------------------------------------------------------ SSIM
def ssim(a: np.ndarray, b: np.ndarray,
         K1: float = 0.01, K2: float = 0.03, L: float = 1.0) -> float:
    """多通道全图 SSIM (Structural Similarity Index)。

    a, b: (H, W, C) float, 取值 [0, L]。返回各通道均值, [0,1] 越高越相似。
    全图单窗口(无滑窗)对 224×224 CIFAR-100 足够分辨结构崩坏 vs 局部损伤。
    """
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if a.ndim == 2:
        a = a[..., None]
        b = b[..., None]
    c = a.shape[2]
    C1 = (K1 * L) ** 2
    C2 = (K2 * L) ** 2

    vals = []
    for ch in range(c):
        ax = a[:, :, ch].ravel()
        bx = b[:, :, ch].ravel()
        mu_a = np.mean(ax)
        mu_b = np.mean(bx)
        sig_a = np.var(ax)
        sig_b = np.var(bx)
        sig_ab = np.mean((ax - mu_a) * (bx - mu_b))
        num = (2.0 * mu_a * mu_b + C1) * (2.0 * sig_ab + C2)
        den = (mu_a ** 2 + mu_b ** 2 + C1) * (sig_a + sig_b + C2)
        vals.append(num / max(den, 1e-12))
    return float(np.mean(vals))


# ------------------------------------------------------------------ helpers
def parse_buckets(s: str) -> list[tuple[int, int]]:
    return [(int(c), int(b)) for c, b in (p.split(":") for p in s.split(","))]


def norm_const(transform):
    for t in getattr(transform, "transforms", [transform]):
        if t.__class__.__name__ == "Normalize":
            return (np.array(t.mean, np.float32).reshape(3, 1, 1),
                    np.array(t.std, np.float32).reshape(3, 1, 1))
    return np.zeros((3, 1, 1), np.float32), np.ones((3, 1, 1), np.float32)


def denorm(x, m, s):
    return np.clip(x * s + m, 0.0, 1.0)


def psnr(a, b):
    mse = float(np.mean((a - b) ** 2))
    return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)


def iaq_encode_decode_with_meta(
    img: np.ndarray, a_i: np.ndarray, pipe: IAQPipeline,
    ebn0_db: float, rng: np.random.Generator,
) -> np.ndarray:
    """一张图经 IAQ 增量分配 + 元信息过 AWGN → 解码重建 (numpy)。"""
    c, h, w = img.shape
    gh, gw = pipe.gh, pipe.gw
    alloc_cfg = dict(pipe.alloc_cfg)
    pkt = pipe.encode(img, a_i, alloc_cfg)
    pkt = awgn_channel(pkt, ebn0_db, metadata_through_channel=True, rng=rng)
    recon_patches = pipe.decode(pkt)
    return _from_patches(recon_patches, c, gh, gw, h // gh, w // gw)


# ------------------------------------------------------------------ main
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--snr", type=float, default=0.0)
    ap.add_argument("--n-stat", type=int, default=256)
    ap.add_argument("--n-show", type=int, default=4)
    ap.add_argument("--indices", default=None)
    ap.add_argument("--buckets", default="49:4,49:2,98:1")
    ap.add_argument("--m_base", type=int, default=1)
    ap.add_argument("--base-fec-r", type=int, default=1)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--data-root", default="./data")
    ap.add_argument("--out", default="outputs/cliff_vs_bucket_cases.png")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    cfg["device"] = "cpu"
    pipe = IAQPipeline.from_config(cfg)
    pipe.b_target = 392
    buckets = parse_buckets(args.buckets)
    pipe.m_max = max(pipe.m_max, max(b for _, b in buckets))

    ds = torchvision.datasets.CIFAR100(
        root=args.data_root, train=False, download=True, transform=pipe.enc.transform)
    classes = ds.classes
    nstat = args.n_stat
    xs, ys = zip(*[ds[i] for i in range(nstat)])
    x, y = torch.stack(xs), torch.tensor(ys)
    print(f"encoder={pipe.enc.arch} buckets={buckets} SNR={args.snr}dB n_stat={nstat}")

    mean, std = norm_const(pipe.enc.transform)
    xnp = x.numpy()

    # ---------- IAQ 路径 ----------
    rng_iaq = np.random.default_rng(args.seed)
    a_all = pipe.enc.attention_scores(x).cpu().numpy()
    recon_iaq = np.empty_like(xnp)

    # 样本0 的元信息损坏检查
    alloc_cfg = dict(pipe.alloc_cfg)
    pkt0_before = pipe.encode(xnp[0], a_all[0], alloc_cfg)
    rng_check = np.random.default_rng(args.seed)
    pkt0_after = awgn_channel(pkt0_before, args.snr, metadata_through_channel=True,
                               rng=rng_check)
    m_before, m_after = pkt0_before.m_map, pkt0_after.m_map
    n_meta_err = int((m_before != m_after).sum())
    print(f"元信息损坏(样本0): {n_meta_err}/{m_before.shape[0]} M_i 值错; "
          f"umin/umax {pkt0_before.umin:.4f}/{pkt0_before.umax:.4f} → "
          f"{pkt0_after.umin:.4f}/{pkt0_after.umax:.4f}")

    for k in range(nstat):
        recon_iaq[k] = iaq_encode_decode_with_meta(
            xnp[k], a_all[k], pipe, args.snr, rng_iaq)

    # ---------- Bucket 路径 ----------
    rng_bucket = np.random.default_rng(args.seed)
    recon_bucket, bdm = pipe.bucket_corrupt(
        xnp, args.snr, args.m_base, args.base_fec_r, buckets, rng_bucket, torch.float32)

    # ---------- 评估 ----------
    with torch.no_grad():
        p_iaq = pipe.enc.classify(torch.from_numpy(recon_iaq).float())[1].cpu().numpy()
        p_bucket = pipe.enc.classify(torch.from_numpy(recon_bucket).float())[1].cpu().numpy()
    yn = y.numpy()
    acc_iaq = float((p_iaq == yn).mean())
    acc_bucket = float((p_bucket == yn).mean())

    od = denorm(xnp, mean, std)           # 原图 [0,1]
    iad = denorm(recon_iaq, mean, std)    # IAQ 重建
    bkd = denorm(recon_bucket, mean, std)  # Bucket 重建

    iaq_psnrs = [psnr(od[i], iad[i]) for i in range(nstat)]
    bkt_psnrs = [psnr(od[i], bkd[i]) for i in range(nstat)]
    iaq_ssims = [ssim(od[i], iad[i]) for i in range(nstat)]
    bkt_ssims = [ssim(od[i], bkd[i]) for i in range(nstat)]

    print(f"IAQ  准确率={acc_iaq:.3f}  PSNR={np.mean(iaq_psnrs):.1f}dB  SSIM={np.mean(iaq_ssims):.4f}")
    print(f"BKT  准确率={acc_bucket:.3f}  PSNR={np.mean(bkt_psnrs):.1f}dB  SSIM={np.mean(bkt_ssims):.4f}")
    print(f"Δ    准确率={(acc_bucket-acc_iaq)*100:+.1f}pt  "
          f"PSNR={np.mean(bkt_psnrs)-np.mean(iaq_psnrs):+.1f}dB  "
          f"SSIM={np.mean(bkt_ssims)-np.mean(iaq_ssims):+.4f}")

    # ---------- 选案例: SSIM 差距最大 (IAQ 崩但 Bucket 尚可) ----------
    if args.indices:
        sel = [int(i) for i in args.indices.split(",")]
    else:
        # IAQ SSIM 低 + Bucket SSIM 高 = 悬崖效应最明显的案例
        scored = sorted(range(nstat), key=lambda i: (
            iaq_ssims[i] - bkt_ssims[i],  # SSIM 降幅越大越好 (负值)
        ))
        sel = scored[:args.n_show]
    sel = sel[:args.n_show]

    ns = len(sel)
    fig = plt.figure(figsize=(11.5, 2.9 * ns + 2.5))
    gs = fig.add_gridspec(ns + 1, 3, height_ratios=[1] * ns + [1.0],
                          hspace=0.30, wspace=0.04)
    col_titles = [
        "IAQ 元信息过信道\n(级联崩坏 → 结构破坏)",
        "粗桶非级联编码\n(局部错配 → 结构完整)",
        "原图\n(真值参考)",
    ]

    for r, i in enumerate(sel):
        truth = classes[yn[i]]
        cells = [
            (iad[i].transpose(1, 2, 0),
             f"SSIM {iaq_ssims[i]:.3f} | PSNR {iaq_psnrs[i]:.1f}dB · "
             f"{classes[p_iaq[i]]} {'✓' if p_iaq[i]==yn[i] else '✗'}",
             "#e94560" if p_iaq[i] != yn[i] else "#888"),
            (bkd[i].transpose(1, 2, 0),
             f"SSIM {bkt_ssims[i]:.3f} | PSNR {bkt_psnrs[i]:.1f}dB · "
             f"{classes[p_bucket[i]]} {'✓' if p_bucket[i]==yn[i] else '✗'}",
             "#0f9" if p_bucket[i] != yn[i] else "#888"),
            (od[i].transpose(1, 2, 0), f"真值: {truth}", "#888"),
        ]
        for c, (img, sub, label_color) in enumerate(cells):
            ax = fig.add_subplot(gs[r, c])
            ax.imshow(img)
            ax.set_xlabel(sub, fontsize=7.5, color=label_color)
            ax.set_xticks([]); ax.set_yticks([])
            if r == 0:
                ax.set_title(col_titles[c], fontsize=10)

    # ---------- 底部: SSIM + PSNR 双指标对比 ----------
    axb = fig.add_subplot(gs[ns, :])
    metrics = ["SSIM ↑", "PSNR(dB) ↑"]
    iaq_vals = [np.mean(iaq_ssims), np.mean(iaq_psnrs)]
    bkt_vals = [np.mean(bkt_ssims), np.mean(bkt_psnrs)]
    x = np.arange(len(metrics))
    w = 0.3
    bars1 = axb.bar(x - w / 2, iaq_vals, w, color="#e94560", label="IAQ(元信息过信道)")
    bars2 = axb.bar(x + w / 2, bkt_vals, w, color="#0f9", label="Bucket(粗桶)")
    for bar, val in zip(bars1, iaq_vals):
        axb.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.002,
                 f"{val:.3f}" if val < 5 else f"{val:.1f}",
                 ha="center", fontsize=10, fontweight="bold", color="#e94560")
    for bar, val in zip(bars2, bkt_vals):
        axb.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.002,
                 f"{val:.3f}" if val < 5 else f"{val:.1f}",
                 ha="center", fontsize=10, fontweight="bold", color="#0f9")
    axb.set_xticks(x); axb.set_xticklabels(metrics, fontsize=10)
    axb.legend(fontsize=9)
    axb.grid(axis="y", alpha=0.3)
    axb.set_title(
        f"SSIM · IAQ={np.mean(iaq_ssims):.4f}  Bucket={np.mean(bkt_ssims):.4f}  "
        f"|  PSNR · IAQ={np.mean(iaq_psnrs):.1f}dB  Bucket={np.mean(bkt_psnrs):.1f}dB  "
        f"|  准确率 IAQ={acc_iaq:.3f}  Bucket={acc_bucket:.3f}  "
        f"(n={nstat}, SNR={args.snr:g}dB)",
        fontsize=9)

    fig.suptitle(
        f"IAQ 元信息过信道(级联崩坏) vs 粗桶非级联编码(局部损伤) · b392 · SNR={args.snr:g}dB",
        fontsize=12, y=0.998)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=150, bbox_inches="tight")
    print(f"saved: {out.resolve()}  cases={sel}")


if __name__ == "__main__":
    main()
