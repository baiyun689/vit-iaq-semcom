"""Summarize the fixed-range CPU pilot from saved results, without rerunning models."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def summarize(root: Path) -> dict:
    sweep = json.loads((root / "bucket_sweep_n24.json").read_text(encoding="utf-8"))
    probes = []
    for path in sorted(root.glob("probe_*_n24.json")):
        result = json.loads(path.read_text(encoding="utf-8"))
        if (result["sample_ids"] != sweep["sample_ids"] or result["n"] != sweep["n"]
                or result["b_target"] != sweep["b_target"] or result["m_base"] != sweep["m_base"]):
            raise ValueError(f"Incompatible pilot samples or source budget: {path}")
        transport = result["transport_assignment"]
        rows = transport["per_image"]
        if [row["sample_id"] for row in rows] != sweep["sample_ids"]:
            raise ValueError(f"Incomplete or misaligned per-image records: {path}")
        actual = sum(row["actual_prediction"] == row["label"] for row in rows)
        oracle = sum(row["oracle_prediction"] == row["label"] for row in rows)
        slots = sum(row["enhancement_slot_count"] for row in rows)
        probes.append({
            "file": path.name, "buckets": result["buckets"], "snr": transport["snr"],
            "actual_correct": actual, "oracle_correct": oracle,
            "actual_accuracy": actual / len(rows), "oracle_accuracy": oracle / len(rows),
            "oracle_gain_pp": 100 * (oracle - actual) / len(rows),
            "oracle_rescued_count": sum(row["actual_prediction"] != row["label"] and
                                         row["oracle_prediction"] == row["label"] for row in rows),
            "oracle_harmed_count": sum(row["actual_prediction"] == row["label"] and
                                        row["oracle_prediction"] != row["label"] for row in rows),
            "bucket_mismatch_rate": sum(row["bucket_mismatch_rate"] for row in rows) / len(rows),
            "enhancement_assignment_error_rate": sum(row["misassigned_slot_count"] for row in rows) / slots,
            "original_attention_clean_accuracy": result["a_clean_bucket"],
            "base_attention_clean_accuracy": result["b_acc_bucket_from_base"],
            "attention_spearman": result["b_spearman_mean"],
        })
    if not probes:
        raise ValueError("No probe results found")
    candidates = sorted(sweep["configs"], key=lambda row: (-row["acc"], row["mse"]))
    return {"n": sweep["n"], "sample_ids": sweep["sample_ids"], "b_target": sweep["b_target"],
            "base_acc": sweep["base_acc"], "uniform": sweep["ref"]["uniform"],
            "ideal": sweep["ref"]["ideal"], "candidates": candidates, "probes": probes,
            "selection_status": "provisional, exploratory validation subset; no final configuration selected"}


def label(buckets):
    return " + ".join(f"{count}×{bits}b" for count, bits in buckets)


def write_report(summary, root):
    n = summary["n"]
    percent = lambda value: f"{value * 100:.1f}%"
    lines = [
        "# 新协议下的桶配置与真实排序错配小样本实验", "",
        "实验日期：2026-10-03。真实 CIFAR-100 图像与已缓存的微调 ViT-Base 权重，CPU 运行。", "",
        f"使用固定验证划分的前 {n} 张图，split_seed=0，batch=4，基础层 1 bit，B=392，基础层不加 FEC。",
        "各分档方案和均匀量化的载荷均为 392×768=301056 bit/图；理想 IAQ 是具有免费分配辅助信息的参考。",
        "全部方案采用相同固定共享量化范围。桶搜索用 100 dB 近似无误码信道；传输探针使用信道种子 0。", "",
        "## 近无误码配置对照", "",
        "| 方案 | 正确数 | 准确率 | 重建 MSE |", "|---|---:|---:|---:|",
        f"| 未量化 | {round(summary['base_acc'] * n)}/{n} | {percent(summary['base_acc'])} | — |",
        f"| 均匀 2 bit | {round(summary['uniform']['acc'] * n)}/{n} | {percent(summary['uniform']['acc'])} | {summary['uniform']['mse']:.5f} |",
        f"| 理想 IAQ | {round(summary['ideal']['acc'] * n)}/{n} | {percent(summary['ideal']['acc'])} | {summary['ideal']['mse']:.5f} |",
    ]
    for row in summary["candidates"]:
        lines.append(f"| {label(row['buckets'])} | {round(row['acc'] * n)}/{n} | {percent(row['acc'])} | {row['mse']:.5f} |")
    lines += ["", "桶搜索中的分档编码使用基础层派生排序。它与探针中使用原图注意力的理想分档量化不同。", "",
              "## 相同受损码流的实际排序与发送端排序对照", "",
              "oracle 对照保持接收到的比特不变，仅用发送端真实排序解码；该排序只用于离线诊断，接收端实际不可得。",
              "增强归属错配按有增强数据的排名槽统计；档位错配按全部图像块统计，二者分母不同。", "",
              "| 桶配置 | SNR/dB | 实际正确数 | oracle 正确数 | oracle 净增益/百分点 | 档位错配 | 增强归属错配 |",
              "|---|---:|---:|---:|---:|---:|---:|"]
    for row in summary["probes"]:
        lines.append(f"| {label(row['buckets'])} | {row['snr']:g} | {row['actual_correct']}/{n} | {row['oracle_correct']}/{n} | {row['oracle_gain_pp']:+.1f} | {percent(row['bucket_mismatch_rate'])} | {percent(row['enhancement_assignment_error_rate'])} |")
    lines += ["", "## 判断与下一步", "",
              f"近无误码下暂列第一的候选为 {label(summary['candidates'][0]['buckets'])}，仅用于后续扩大验证。",
              "排序变化会把固定排名槽中的增强值交给不同图像块。同档交换也会产生这个问题，因此码流边界固定并不意味着空间归属可靠。",
              "本轮首先检查定位机制，而不把大规模修补训练当作自动解决方案。建议对照：固定空间位置传增强值、只派生粗组而减少组内排序依赖、显式携带并保护必要的定位信息。带来的比特开销均须计入总预算。",
              "修补网络后续需与均匀量化加修补进行消融，区分一般图像恢复能力与分档编码的实际贡献。", "",
              "## 解释边界", "",
              f"- n={n}，一张图对应 {100/n:.2f} 个百分点，不能据此断言统计显著性或最终配置最优。",
              "- 同一小样本参与配置扫描，候选的分数有选择偏差；后续应扩大验证并保留最终测试集。",
              "- 每个 SNR 只使用一个信道种子，不估计信道种子间标准差。",
              "- 分类器原本已在 CIFAR-100 上微调；这里是修补训练/协议选型的验证划分，不能当作分类器的新独立测试集。",
              "- oracle 比实际准确率高说明这些样本对排序归属敏感，不保证任意修补网络能获得同样收益；oracle 也不是严格性能上界。",
              "- 没有训练新的修补网络，也没有对最终测试集调参。", "",
              "## 复现", "", "```powershell",
              "$env:CUDA_VISIBLE_DEVICES='-1'", "$env:OMP_NUM_THREADS='2'", "$env:MKL_NUM_THREADS='2'", "$env:HF_HUB_OFFLINE='1'",
              "python scripts/run_bucket_sweep.py --device cpu --n 24 --batch 4 --b_target 392 --m_base 1 --split-seed 0 --out outputs/corrected/pilot_20261003/bucket_sweep_n24.json",
              "# 原配置：--buckets 49:4,49:2,98:1，SNR=6；候选配置：--buckets 98:3,98:1，SNR=0/6/12。",
              "python scripts/run_bucket_probe.py --device cpu --n 24 --batch 4 --b_target 392 --m_base 1 --buckets 98:3,98:1 --channel-snr 6 --seed 0 --split-seed 0 --out outputs/corrected/pilot_20261003/probe_candidate_snr6_n24.json",
              "python scripts/summarize_bucket_pilot.py --root outputs/corrected/pilot_20261003", "```", "",
              "原始 JSON 保留完整样本编号和逐图诊断；manifest.json 保存配置、软件版本以及权重/数据文件哈希。",
              "已有文件不会被实验入口自动覆盖，重跑请使用新输出目录。", ""]
    (root / "report.md").write_text("\n".join(lines), encoding="utf-8")


def plot(summary, root):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    fig, axes = plt.subplots(1, 3, figsize=(15, 5.8))
    rows = summary["candidates"]
    names = ["均匀 2 bit", "理想 IAQ"] + [label(row["buckets"]) for row in rows]
    values = [summary["uniform"]["acc"], summary["ideal"]["acc"]] + [row["acc"] for row in rows]
    axes[0].barh(names, [100 * v for v in values], color=["#8da0ae", "#4267ac"] + ["#3d9d8c"] * len(rows))
    axes[0].invert_yaxis()
    axes[0].set_xlim(0, 100)
    for i, value in enumerate(values):
        axes[0].text(value * 100 + 1, i, f"{round(value * summary['n'])}/{summary['n']}", va="center", fontsize=9)
    axes[0].set_title("近无误码：桶配置对照")
    axes[0].set_xlabel("准确率 / %")
    candidate = sorted([row for row in summary["probes"] if "candidate" in row["file"]], key=lambda row: row["snr"])
    if candidate:
        snrs = [row["snr"] for row in candidate]
        axes[1].plot(snrs, [100 * row["actual_accuracy"] for row in candidate], "o-", label="实际接收端排序")
        axes[1].plot(snrs, [100 * row["oracle_accuracy"] for row in candidate], "s--", label="已知发送端排序（诊断）")
        axes[2].plot(snrs, [100 * row["bucket_mismatch_rate"] for row in candidate], "o-", label="档位错配 / 全部块")
        axes[2].plot(snrs, [100 * row["enhancement_assignment_error_rate"] for row in candidate], "s-", label="归属错配 / 增强槽")
        for ax in axes[1:]:
            ax.set_ylim(-3, 103)
            ax.set_xticks(snrs)
            ax.set_xlabel("发送编码比特能量 / N0（dB）")
            ax.legend(fontsize=8, loc="best")
            ax.grid(alpha=.2)
        axes[1].set_title("候选配置：相同受损码流")
        axes[1].set_ylabel("准确率 / %")
        axes[2].set_title("候选配置：两类错配")
        axes[2].set_ylabel("错配比例 / %")
    fig.suptitle(f"新协议真实小样本筛查 · n={summary['n']} · B={summary['b_target']} · 基础层 1 bit · 单信道种子", fontsize=14)
    fig.text(.5, .015, "验证集探索结果；每张图约 4.17 个百分点；候选尚未定型，未训练修补网络。", ha="center", fontsize=10)
    fig.tight_layout(rect=(0, .05, 1, .94))
    fig.savefig(root / "pilot_summary.png", dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("outputs/corrected/pilot_20261003"))
    args = parser.parse_args()
    result = summarize(args.root)
    (args.root / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    write_report(result, args.root)
    plot(result, args.root)
    print(f"Saved summary.json, report.md and pilot_summary.png in {args.root.resolve()}")
