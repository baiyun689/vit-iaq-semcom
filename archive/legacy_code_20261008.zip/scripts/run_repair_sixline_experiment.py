"""Six-line fixed-range experiment under one common channel-bit upper bound.

Actual packet lengths include metadata and repetition redundancy. Unused budget is
allowed and reported; the ideal reference gets free oracle side information and uses
the same source allocation budget as the unprotected-metadata branch. Bucket and
repair share noise seeds. The SNR-dependent repetition policy is a heuristic, not an
optimized FEC baseline. New results go to outputs/corrected and require v2 weights.
The SNR axis is energy per transmitted coded bit / N0, not information-bit energy.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt

matplotlib.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False

from vit_iaq_semcom.experiment import parse_buckets, provenance
from vit_iaq_semcom.bucket import validate_buckets
from vit_iaq_semcom.channel import pack_metadata


def matched_rate(snr: float) -> int:
    """重复码速率分母 r(SNR 越低保护越强,奇数)。"""
    if snr < 0:
        return 5
    if snr < 4:
        return 3
    return 1


def source_budget(channel_budget: int, values_per_patch: int, metadata_bits: int, rate: int) -> int:
    from vit_iaq_semcom.fec import validate_repetition
    validate_repetition(rate)
    remaining = channel_budget - metadata_bits * rate
    if remaining < 0:
        raise ValueError("Metadata protection alone exceeds the channel budget")
    return remaining // values_per_patch


def evaluate(pipe, loader, snr, *, channel_budget, seed=0, b_target=None, **kwargs):
    import numpy as np
    previous_budget = pipe.b_target
    totals, records, diagnostics = [], [], []
    components = []
    try:
        if b_target is not None:
            pipe.b_target = b_target
        for batch_index, (xb, yb) in enumerate(loader):
            out = pipe.run_batch(xb, labels=yb, channel_type="awgn", ebn0_db=snr,
                                 seed=seed + batch_index, **kwargs)
            for counts in out["bit_counts"]:
                if counts["total"] > channel_budget:
                    raise ValueError(f"Actual packet exceeds budget: {counts['total']} > {channel_budget}")
                totals.append(counts["total"])
                components.append(counts)
            diagnostics.extend(out["diagnostics"])
            records.extend({"label": int(label), "prediction": int(pred)}
                           for label, pred in zip(yb, out["preds"].cpu()))
    finally:
        pipe.b_target = previous_budget
    if not records:
        raise ValueError("Empty evaluation dataset")
    return {"accuracy": float(np.mean([r["label"] == r["prediction"] for r in records])),
            "channel_bits": {"min": min(totals), "max": max(totals), "mean": float(np.mean(totals))},
            "bit_counts": components, "diagnostics": diagnostics, "predictions": records}


def plot_results(res: dict, out: Path) -> None:
    snr = res["snr"]
    fig, ax = plt.subplots(figsize=(7.8, 4.8))
    ax.axhline(res["base_acc"], color="gray", ls=":", lw=1,
               label=f"无量化基线 ({res['base_acc']:.2f})")
    style = {
        "uniform": ("^-", "tab:green", "均匀量化（无元信息）"),
        "ideal": ("o-", "tab:blue", "元信息无损传输（理想）"),
        "raw": ("s-", "tab:red", "元信息过信道传输"),
        "protected": ("D-", "tab:purple", "FEC 保护元信息"),
        "bucket": ("v-", "tab:orange", "分层分档定长编码"),
        "bucket_repair": ("*-", "black", "分层分档定长编码 + 语义修补网络"),
    }
    for line, (mk, col, lab) in style.items():
        if line in res["acc"]:
            deviation = res.get("std", {}).get(line)
            ax.errorbar(snr, res["acc"][line], yerr=deviation, fmt=mk, color=col,
                        label=lab, capsize=3 if deviation is not None else 0)
    rho = res["b_target"] / (res.get("n_patches", 196) * 8)
    ax.set_xlabel("Coded-bit energy / N0 (dB)")
    ax.set_ylabel("CIFAR-100 Top-1 准确率")
    uncertainty = "\n误差条：信道随机种子间 ±1 标准差" if res.get("std") else ""
    ax.set_title(f"比特预算 B={res['b_target']} (ρ={rho:.2f}){uncertainty}")
    ax.legend(fontsize=8, ncol=2)
    ax.grid(True, alpha=0.3)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"saved: {out.resolve()}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--n", type=int, default=256, help="样本数(吃 GPU,默认小)")
    ap.add_argument("--b_target", type=int, default=392)
    ap.add_argument("--m_base", type=int, default=1)
    ap.add_argument("--buckets", default="49:4,49:2,98:1", help="粗桶配置 cnt:总比特,...")
    ap.add_argument("--snr", default="-4,-2,0,2,4,6,8,10,12")
    ap.add_argument("--design-snr", type=float, default=None,
                    help="失配场景固定设计点;不给=匹配场景")
    ap.add_argument("--repair-ckpt", default=None, help="Version 2 repair checkpoint (required)")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--sample-seed", type=int, default=0)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--bucket-base-fec-r", type=int, default=1,
                    help="④⑤ 基础层 FEC(默认 1=不保护,最干净同带宽)")
    # 修补网络结构(须与训练一致)
    ap.add_argument("--data-root", default="./data")
    ap.add_argument("--device", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--replot", default=None)
    args = ap.parse_args()

    if args.replot:
        res = json.loads(Path(args.replot).read_text(encoding="utf-8"))
        plot_results(res, Path(args.out or Path(args.replot).with_suffix(".png")))
        return

    if not args.repair_ckpt:
        ap.error("--repair-ckpt is required; a missing network must not be plotted as repair")
    if args.n < 1 or args.batch < 1 or args.b_target < 1:
        ap.error("n, batch and b_target must be positive")
    import numpy as np
    import torch
    import torchvision
    import yaml
    from torch.utils.data import DataLoader, Subset
    from vit_iaq_semcom.pipeline import IAQPipeline

    scen = "mismatch" if args.design_snr is not None else "matched"
    out = Path(args.out or f"outputs/corrected/repair_sixline_{scen}_b{args.b_target}.png")
    if not args.overwrite and (out.exists() or out.with_suffix(".json").exists()):
        ap.error("Output exists; choose another --out or explicitly use --overwrite")
    snrs = [float(s) for s in args.snr.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    if not np.isfinite(snrs).all() or any(seed < 0 for seed in seeds) or len(seeds) != len(set(seeds)):
        ap.error("SNRs must be finite and seeds must be distinct nonnegative integers")
    if args.design_snr is not None and not np.isfinite(args.design_snr):
        ap.error("design-snr must be finite")
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    if args.device:
        cfg["device"] = args.device
    pipe = IAQPipeline.from_config(cfg)
    if pipe.range_policy != "fixed":
        ap.error("Six-line comparison requires the fixed-range protocol")
    buckets = parse_buckets(args.buckets)
    gh, gw = pipe.gh, pipe.gw
    n_patch = gh * gw
    c, h, w = pipe.enc.preprocessing["input_size"]
    p_scalars = c * (h // gh) * (w // gw)
    depths = validate_buckets(buckets, n_patch, args.m_base, pipe.m_max)
    bucket_source = int(depths.sum())
    channel_budget = p_scalars * args.b_target
    bucket_total = p_scalars * (bucket_source + n_patch * args.m_base * (args.bucket_base_fec_r - 1))
    if bucket_total > channel_budget:
        ap.error(f"Bucket configuration including FEC needs {bucket_total} bits; cap is {channel_budget}. Reduce source depth or change the budget.")
    pipe.b_target = bucket_source
    pipe.validate_bucket_protocol(buckets, args.m_base, args.bucket_base_fec_r)
    pipe.load_repair_net(args.repair_ckpt)
    pipe.validate_repair_protocol(args.m_base, args.bucket_base_fec_r, buckets)
    meta_bits = len(pack_metadata(np.zeros(n_patch, dtype=int), *pipe.quantization_range, pipe.m_max))

    ds = torchvision.datasets.CIFAR100(root=args.data_root, train=False, download=True,
                                      transform=pipe.enc.transform)
    if args.n > len(ds):
        ap.error("n exceeds the test dataset size")
    ids = np.random.default_rng(args.sample_seed).permutation(len(ds))[:args.n].tolist()
    loader = DataLoader(Subset(ds, ids), batch_size=args.batch)
    base_correct = sum(int((pipe.enc.classify(x)[1].cpu() == y).sum()) for x, y in loader)
    base_acc = base_correct / len(ids)
    snrs = [float(s) for s in args.snr.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]
    acc = {k: [] for k in ("ideal", "uniform", "raw", "protected", "bucket", "bucket_repair")}
    std = {k: [] for k in acc}
    runs, chan_bits = {}, {}
    for snr in snrs:
        r = matched_rate(args.design_snr if args.design_snr is not None else snr)
        raw_budget = source_budget(channel_budget, p_scalars, meta_bits, 1)
        protected_budget = source_budget(channel_budget, p_scalars, meta_bits, r)
        settings = {
            "ideal": dict(mode="iaq", alloc="incremental", b_target=raw_budget),
            "uniform": dict(mode="iaq", alloc="uniform", b_target=args.b_target),
            "raw": dict(mode="iaq", alloc="incremental", metadata_through_channel=True, b_target=raw_budget),
            "protected": dict(mode="uep", meta_fec_r=r, b_target=protected_budget),
            "bucket": dict(mode="bucket", m_base=args.m_base, base_fec_r=args.bucket_base_fec_r, buckets=buckets, b_target=bucket_source),
            "bucket_repair": dict(mode="bucket+repair", m_base=args.m_base, base_fec_r=args.bucket_base_fec_r, buckets=buckets, b_target=bucket_source),
        }
        runs[str(snr)] = {}
        chan_bits[str(snr)] = {}
        for line, options in settings.items():
            results = [evaluate(pipe, loader, snr, channel_budget=channel_budget, seed=seed, **options) for seed in seeds]
            for result in results:
                for sample_id, record in zip(ids, result["predictions"]):
                    record["sample_id"] = sample_id
            values = [result["accuracy"] for result in results]
            acc[line].append(float(np.mean(values)))
            std[line].append(float(np.std(values)))
            runs[str(snr)][line] = results
            chan_bits[str(snr)][line] = results[0]["channel_bits"]
        print(f"SNR={snr:g} " + " ".join(f"{k}={acc[k][-1]:.3f}" for k in acc))
    res = {"snr": snrs, "acc": acc, "std": std, "base_acc": base_acc, "n": len(ids),
           "b_target": args.b_target, "n_patches": n_patch, "channel_budget": channel_budget,
           "m_base": args.m_base, "buckets": buckets, "design_snr": args.design_snr,
           "repair_ckpt": args.repair_ckpt, "bucket_base_fec_r": args.bucket_base_fec_r,
           "arch": pipe.enc.arch, "channel_bits": chan_bits, "runs": runs,
           "seeds": seeds, "sample_ids": ids, "sample_seed": args.sample_seed, "batch_size": args.batch,
           "evaluation_split": "test", "protocol": pipe.repair_protocol, "provenance": provenance(),
           "budget_convention": "same upper bound; actual bits reported; oracle side information reported separately",
           "snr_convention": "transmitted coded-bit energy / N0; unit-energy BPSK"}
    out.parent.mkdir(parents=True, exist_ok=True)
    out.with_suffix(".json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    plot_results(res, out)


if __name__ == "__main__":
    main()
