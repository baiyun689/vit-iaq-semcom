"""粗桶分配可行性探针（brainstorm: 非级联重要性分配 + AI 修补，验证假设）。

纯推理、不训练、不建修补网络。回答两个未知数:
  (a) 粗桶留住多少 IAQ 红利? —— 干净信道下比 均匀 / 增量(理想IAQ) / 粗桶 三种分配的准确率。
  (b) 派生错几个 patch? —— 用基础层重建图派生的"桶分配" vs 用原图派生的,量错配比例
      (=AI 修补的工作量),并看据此重建的准确率掉多少。

粗桶 = 按注意力排序入"固定大小、固定比特"的桶(非级联的关键);默认 b588:
  49×6 + 49×4 + 98×1 = 588。排序入桶取代增量分配。

用法(vit-iaq-semcom 环境,建议 CPU 小样本):
    python scripts/run_bucket_probe.py --n 128 --device cpu
    python scripts/run_bucket_probe.py --n 128 --buckets 98:4,98:2 --device cpu
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from vit_iaq_semcom.a1 import base_reconstruct as _base_recon_one
from vit_iaq_semcom.bit_allocation import incremental_allocation, uniform_allocation
from vit_iaq_semcom.bucket import bucket_alloc, bucket_index  # 单一真源(src/bucket.py)
from vit_iaq_semcom.pipeline import IAQPipeline, _from_patches, _to_patches
from vit_iaq_semcom.quantization import uniform_dequantize, uniform_quantize


from vit_iaq_semcom.experiment import parse_buckets, split_indices, provenance, protocol_config
from vit_iaq_semcom.training import save_metrics


def reconstruct(img: np.ndarray, m_map: np.ndarray, umin: float, umax: float,
                gh: int, gw: int) -> np.ndarray:
    """干净信道:按 M_i 逐 patch 均匀量化再反量化(m=0 → 中点)。"""
    c, h, w = img.shape
    ph, pw = h // gh, w // gw
    patches = _to_patches(img, gh, gw)
    out = np.empty_like(patches)
    mid = 0.5 * (umin + umax)
    for i in range(patches.shape[0]):
        m = int(m_map[i])
        if m <= 0:
            out[i] = mid
        else:
            q = uniform_quantize(patches[i], m, umin, umax)
            out[i] = uniform_dequantize(q, m, umin, umax)
    return _from_patches(out, c, gh, gw, ph, pw)


def acc_for(pipe, x_np, y, m_maps, dtype, batch=64):
    """给每图一组 M_i,重建→分类→准确率。"""
    import torch
    recon = np.empty_like(x_np)
    for k in range(x_np.shape[0]):
        umin, umax = pipe.image_range(x_np[k])
        recon[k] = reconstruct(x_np[k], m_maps[k], umin, umax, pipe.gh, pipe.gw)
    correct = total = 0
    for s in range(0, recon.shape[0], batch):
        xb = torch.from_numpy(recon[s:s + batch]).to(dtype)
        preds = pipe.enc.classify(xb)[1].cpu().numpy()
        correct += int((preds == y[s:s + batch]).sum())
        total += xb.shape[0]
    return correct / total


def probe_batch(pipe, x, y, *, b_target, m_base, buckets, channel_snr, rng):
    """Bound image and attention tensors to one batch; return small diagnostics."""
    import torch
    x_np = x.cpu().numpy()
    n_patch = pipe.gh * pipe.gw

    base_acc = float((pipe.enc.classify(x)[1].cpu().numpy() == y).mean())

    # 原图注意力
    a_orig = pipe._attn.attention_scores(x).cpu().numpy()
    # 基础层重建图注意力(派生用)
    x_base = np.stack([
        _base_recon_one(x_np[k], m_base, *pipe.image_range(x_np[k]))
        for k in range(x_np.shape[0])])
    a_base = pipe._attn.attention_scores(torch.from_numpy(x_base).to(x.dtype)).cpu().numpy()

    # ---- (a) 干净信道:均匀 / 增量 / 粗桶(均由原图注意力派生)----
    M_uni = [uniform_allocation(n_patch, b_target, pipe.m_max) for _ in range(x_np.shape[0])]
    M_inc = [incremental_allocation(a_orig[k], b_target, pipe.m_max) for k in range(x_np.shape[0])]
    M_buk = [bucket_alloc(a_orig[k], buckets) for k in range(x_np.shape[0])]

    acc_uni = acc_for(pipe, x_np, y, M_uni, x.dtype)
    acc_inc = acc_for(pipe, x_np, y, M_inc, x.dtype)
    acc_buk = acc_for(pipe, x_np, y, M_buk, x.dtype)

    # ---- (b) 派生定位:桶分配 原图 vs 基础层 ----
    Bo = np.stack([bucket_index(a_orig[k], buckets) for k in range(x_np.shape[0])])
    Bb = np.stack([bucket_index(a_base[k], buckets) for k in range(x_np.shape[0])])
    mis_frac = float((Bo != Bb).mean())                       # 任意错配(含相邻边界抖动)
    severe_frac = float((np.abs(Bo - Bb) >= 2).mean())        # 严重错配(跨≥2档,如 0↔2)
    # 双端使用同一基础层排序时的源编码质量；真实传输错配另行诊断。
    M_buk_base = [bucket_alloc(a_base[k], buckets) for k in range(x_np.shape[0])]
    acc_buk_base = acc_for(pipe, x_np, y, M_buk_base, x.dtype)

    # Spearman 秩相关系数: 原图注意力 vs 基础层重建图注意力 (逐图取均值)
    spearman_rhos = []
    for k in range(x_np.shape[0]):
        # rankdata 处理平局, 等价于 scipy.stats.spearmanr
        from scipy.stats import spearmanr as _sp
        rho = (_sp(a_orig[k], a_base[k]).statistic
               if np.ptp(a_orig[k]) > 0 and np.ptp(a_base[k]) > 0 else np.nan)
        spearman_rhos.append(rho)
    valid_rhos = [float(rho) for rho in spearman_rhos if np.isfinite(rho)]

    # 桶分配一致率 (1 − mis_frac)
    bucket_agreement = 1.0 - mis_frac

    # Separate transport attribution: same received bits, actual vs oracle sender ranking.
    from vit_iaq_semcom.bucket import (bucket_encode, bucket_through_channel, bucket_decode_base,
                                      bucket_decode, assignment_diagnostics)
    received = []
    c, h, w = x_np.shape[1:]
    ph, pw = h // pipe.gh, w // pipe.gw
    for k in range(len(x_np)):
        pkt = bucket_encode(_to_patches(x_np[k], pipe.gh, pipe.gw), a_base[k],
                            *pipe.image_range(x_np[k]), m_base, buckets, pipe.m_max)
        received.append(bucket_through_channel(pkt, channel_snr, rng))
    bases = np.stack([_from_patches(bucket_decode_base(pkt), c, pipe.gh, pipe.gw, ph, pw)
                      for pkt in received])
    a_rx = pipe._attn.attention_scores(torch.from_numpy(bases).to(x.dtype)).cpu().numpy()
    actual = np.stack([_from_patches(bucket_decode(pkt, a_rx[k]), c, pipe.gh, pipe.gw, ph, pw)
                       for k, pkt in enumerate(received)])
    oracle = np.stack([_from_patches(bucket_decode(pkt, a_base[k]), c, pipe.gh, pipe.gw, ph, pw)
                       for k, pkt in enumerate(received)])
    actual_pred = pipe.enc.classify(torch.from_numpy(actual).to(x.dtype))[1].cpu().numpy()
    oracle_pred = pipe.enc.classify(torch.from_numpy(oracle).to(x.dtype))[1].cpu().numpy()
    transport = {"snr": channel_snr, "actual_accuracy": float((actual_pred == y).mean()),
                 "oracle_assignment_accuracy": float((oracle_pred == y).mean()),
                 "per_image": [{**assignment_diagnostics(a_base[k], a_rx[k], buckets, m_base),
                                "label": int(y[k]), "actual_prediction": int(actual_pred[k]),
                                "oracle_prediction": int(oracle_pred[k])}
                               for k in range(len(received))]}

    return {
        "base_acc_no_quant": base_acc, "a_clean_uniform": acc_uni,
        "a_clean_incremental": acc_inc, "a_clean_bucket": acc_buk,
        "b_bucket_agreement": bucket_agreement, "b_misbucket_frac": mis_frac,
        "b_severe_misbucket_frac": severe_frac, "b_acc_bucket_from_base": acc_buk_base,
        "b_acc_drop_vs_orig": acc_buk - acc_buk_base,
    }, transport, valid_rhos


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--n", type=int, default=128)
    ap.add_argument("--b_target", type=int, default=588)
    ap.add_argument("--m_base", type=int, default=1, help="派生排序用的基础层比特")
    ap.add_argument("--buckets", default="49:6,49:4,98:1")
    ap.add_argument("--data-root", default="./data")
    ap.add_argument("--device", default=None)
    ap.add_argument("--out", default="outputs/corrected/bucket_probe.json")
    ap.add_argument("--channel-snr", type=float, default=6.0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--split-seed", type=int, default=0)
    ap.add_argument("--validation-size", type=int, default=5000)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()
    if min(args.n, args.batch) < 1 or min(args.workers, args.seed, args.split_seed) < 0:
        ap.error("n and batch must be positive; workers and seeds must be nonnegative")
    if not np.isfinite(args.channel_snr):
        ap.error("channel-snr must be finite")
    if Path(args.out).exists() and not args.overwrite:
        ap.error("Output exists; use a new path or --overwrite")

    import torch
    import torchvision
    import yaml

    buckets = parse_buckets(args.buckets)
    bsum = sum(c * b for c, b in buckets)
    bcnt = sum(c for c, _ in buckets)
    print(f"buckets={buckets} 总比特={bsum} (b_target={args.b_target}) 覆盖patch={bcnt}")
    if bsum != args.b_target:
        raise ValueError(f"Bucket source budget {bsum} != requested {args.b_target}")

    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    if args.device:
        cfg["device"] = args.device
    pipe = IAQPipeline.from_config(cfg)
    pipe.b_target = args.b_target
    pipe.validate_bucket_protocol(buckets, args.m_base, 1)
    print(f"encoder={pipe.enc.arch} device={pipe.enc.device} b_target={pipe.b_target} "
          f"m_base={args.m_base}")

    ds = torchvision.datasets.CIFAR100(
        root=args.data_root, train=True, download=True, transform=pipe.enc.transform)
    _, validation_ids = split_indices(len(ds), args.validation_size, args.split_seed)
    if args.n > len(validation_ids):
        ap.error("n exceeds the validation partition")
    sample_ids = validation_ids[:args.n]
    from torch.utils.data import DataLoader, Subset
    loader = DataLoader(Subset(ds, sample_ids), batch_size=args.batch, num_workers=args.workers)
    rng = np.random.default_rng(args.seed)
    totals, transport_rows, valid_rhos = {}, [], []
    actual_correct = oracle_correct = 0
    offset = 0
    for x, labels in loader:
        metrics, transport, rhos = probe_batch(
            pipe, x, labels.numpy(), b_target=args.b_target, m_base=args.m_base,
            buckets=buckets, channel_snr=args.channel_snr, rng=rng)
        for key, value in metrics.items():
            totals[key] = totals.get(key, 0.0) + value * len(x)
        for sample_id, row in zip(sample_ids[offset:offset + len(x)], transport["per_image"]):
            row["sample_id"] = sample_id
            actual_correct += row["actual_prediction"] == row["label"]
            oracle_correct += row["oracle_prediction"] == row["label"]
            transport_rows.append(row)
        valid_rhos.extend(rhos)
        offset += len(x)
    metrics = {key: value / len(sample_ids) for key, value in totals.items()}
    transport = {"snr": args.channel_snr, "actual_accuracy": actual_correct / len(sample_ids),
                 "oracle_assignment_accuracy": oracle_correct / len(sample_ids), "per_image": transport_rows}

    res = {
        "n": len(sample_ids), "batch_size": args.batch, "workers": args.workers, "evaluation_split": "validation", "sample_ids": sample_ids,
        "provenance": provenance(), "transport_assignment": transport,
        "validation_size": args.validation_size,
        "protocol": protocol_config(pipe, args.m_base, 1, buckets),
        "split_seed": args.split_seed, "channel_seed": args.seed,
        "allocation_probe_note": "Original-image vs base-image allocation; not transmitter-receiver transport mismatch", "b_target": args.b_target, "m_base": args.m_base,
        "buckets": buckets, "bucket_bits_sum": bsum, "arch": pipe.enc.arch,
        **metrics,
        "bucket_keeps_of_iaq_gain": (
            (metrics["a_clean_bucket"] - metrics["a_clean_uniform"]) /
            (metrics["a_clean_incremental"] - metrics["a_clean_uniform"])
            if metrics["a_clean_incremental"] > metrics["a_clean_uniform"] else None),
        "b_spearman_mean": float(np.mean(valid_rhos)) if valid_rhos else None,
        "b_spearman_valid_count": len(valid_rhos),
        "b_spearman_undefined_count": len(sample_ids) - len(valid_rhos),
    }
    print(f"Evaluated {len(sample_ids)} validation samples in batches of {args.batch}")
    save_metrics(res, args.out)
    print(f"saved: {Path(args.out).resolve()}")


if __name__ == "__main__":
    main()
