"""从 中期报告_4_后续工作计划_草稿.md 生成 docx。"""
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent.parent
MD = ROOT / "docs" / "中期报告_4_后续工作计划_草稿.md"
OUT = ROOT / "docs" / "中期报告_4_后续工作计划_v1.docx"


def add_paragraph(doc, text, bold=False, font_name="宋体", font_size=12):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = Pt(20)
    pf.line_spacing_rule = 2  # WD_LINE_SPACING.EXACTLY
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.first_line_indent = Pt(0)
    run = p.add_run(text)
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), font_name)
    run.font.size = Pt(font_size)
    run.bold = bold
    return p


def is_heading_line(text):
    """章节标题（4 开头）或子标题（（一）（二）（三）开头）加粗。"""
    return text.startswith("4 ") or text.startswith("（")


def main():
    text = MD.read_text(encoding="utf-8")
    lines = text.strip().split("\n")

    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "宋体"
    style.font.size = Pt(12)
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    pf = style.paragraph_format
    pf.line_spacing = Pt(20)
    pf.line_spacing_rule = 2
    pf.first_line_indent = Pt(0)

    for section in doc.sections:
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(3.17)
        section.right_margin = Cm(3.17)

    i = 0
    while i < len(lines):
        line = lines[i]
        if line.strip() == "":
            i += 1
            continue

        para_lines = [line]
        i += 1
        while i < len(lines) and lines[i].strip() != "":
            para_lines.append(lines[i])
            i += 1
        para_text = "".join(para_lines)

        add_paragraph(doc, para_text, bold=is_heading_line(para_text))

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(OUT))
    print(f"saved: {OUT}")


if __name__ == "__main__":
    main()
