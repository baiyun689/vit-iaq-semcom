"""2.4 节图5：语义修补网络架构 — 黑白 PPT 框图。
输出可编辑的 .pptx 和导出的 .png。
用法：python scripts/visualize_repair_arch.py
"""

from __future__ import annotations
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_CONNECTOR_TYPE, MSO_SHAPE

ROOT = Path(__file__).resolve().parent.parent
OUT_PPTX = ROOT / "outputs" / "repair_arch.pptx"
OUT_PNG  = ROOT / "outputs" / "repair_arch.png"

BLACK   = RGBColor(0x00, 0x00, 0x00)
GRAY    = RGBColor(0x66, 0x66, 0x66)
WHITE   = RGBColor(0xFF, 0xFF, 0xFF)

# ── layout constants (in inches) ──
SLIDE_W = 10.0
SLIDE_H = 3.2

BOX_W, BOX_H   = 1.10, 0.42
BOX_W2, BOX_H2 = 1.35, 0.55   # transformer
GAP = 0.12

# X positions of each column
X = [
    0.25,                              # 0: inputs
    0.25 + BOX_W + GAP,                # 1: embed
    0.25 + 2*(BOX_W + GAP),            # 2: add+pos
    0.25 + 2*(BOX_W + GAP) + 0.40,     # 3: transformer
    0.25 + 2*(BOX_W + GAP) + 0.40 + BOX_W2 + GAP,   # 4: LN+Lin
    0.25 + 2*(BOX_W + GAP) + 0.40 + BOX_W2 + GAP + BOX_W + GAP,  # 5: res add
    0.25 + 2*(BOX_W + GAP) + 0.40 + BOX_W2 + GAP + BOX_W + GAP + 0.28,  # 6: repaired
    0.25 + 2*(BOX_W + GAP) + 0.40 + BOX_W2 + GAP + BOX_W + GAP + 0.28 + BOX_W + 0.04 + GAP,  # 7: vit
]

Y_TOP, Y_BOT = 1.52, 0.62
MY = (Y_TOP + Y_BOT) / 2 + BOX_H / 2  # merge Y


def add_box(slide, left, top, w, h, text, sub=None, bold=True, fs=10):
    """添加白底黑框矩形 + 居中文字。"""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                   Inches(left), Inches(top),
                                   Inches(w), Inches(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = WHITE
    shape.line.color.rgb = BLACK
    shape.line.width = Pt(1.5)
    tf = shape.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text
    run.font.size = Pt(fs)
    run.font.bold = bold
    run.font.color.rgb = BLACK
    if sub:
        p2 = tf.add_paragraph()
        p2.alignment = PP_ALIGN.CENTER
        r2 = p2.add_run()
        r2.text = sub
        r2.font.size = Pt(7)
        r2.font.color.rgb = GRAY
    return shape


def add_plus(slide, left, top, r=0.12):
    """⊕ 圆圈。"""
    shape = slide.shapes.add_shape(MSO_SHAPE.OVAL,
                                   Inches(left - r), Inches(top - r),
                                   Inches(r * 2), Inches(r * 2))
    shape.fill.solid()
    shape.fill.fore_color.rgb = WHITE
    shape.line.color.rgb = BLACK
    shape.line.width = Pt(1)
    tf = shape.text_frame
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = "+"
    run.font.size = Pt(9)
    run.font.bold = True
    run.font.color.rgb = BLACK


def add_arrow(slide, x1, y1, x2, y2, dashed=False):
    """折线箭头。"""
    conn = slide.shapes.add_connector(
        MSO_CONNECTOR_TYPE.STRAIGHT,
        Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    conn.line.color.rgb = BLACK
    conn.line.width = Pt(1.0)
    if dashed:
        conn.line.dash_style = 2  # dash
    # arrow head
    conn.end_x = Inches(x2)
    conn.end_y = Inches(y2)
    # pptx connector arrows are limited; add explicit endpoints
    try:
        conn.begin_x = Inches(x1)
        conn.begin_y = Inches(y1)
    except:
        pass
    return conn


def add_label(slide, left, top, w, text, fs=7, color=GRAY, bold=False):
    """纯文本框。"""
    txBox = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(w), Inches(0.20))
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    run = p.add_run()
    run.text = text
    run.font.size = Pt(fs)
    run.font.color.rgb = color
    run.font.bold = bold
    return txBox


def main():
    prs = Presentation()
    prs.slide_width  = Inches(SLIDE_W)
    prs.slide_height = Inches(SLIDE_H)
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank

    # ── title ──
    add_label(slide, SLIDE_W / 2 - 1.80, 0.08, 3.60,
              "图5  语义修补网络架构 (Semantic Repair Network)", fs=13, color=BLACK, bold=True)

    # ═══ ROW 1: Input → Embed ═══
    add_box(slide, X[0], Y_TOP, BOX_W, BOX_H, "Damaged Recon. X", "(B,3,224,224)")
    add_box(slide, X[1], Y_TOP, BOX_W, BOX_H, "Patch Embed", "Linear(768,192)")
    add_arrow(slide, X[0] + BOX_W, Y_TOP + BOX_H / 2, X[1], Y_TOP + BOX_H / 2)

    # ═══ ROW 2: D → Depth Embed ═══
    add_box(slide, X[0], Y_BOT, BOX_W, BOX_H, "Bit-Depth Map D", "(B,196) [0,m_max]")
    add_box(slide, X[1], Y_BOT, BOX_W, BOX_H, "Depth Embed", "Embed(9,192)")
    add_arrow(slide, X[0] + BOX_W, Y_BOT + BOX_H / 2, X[1], Y_BOT + BOX_H / 2)

    # ═══ Merge + PosEmbed ═══
    add_plus(slide, X[2], MY)
    add_arrow(slide, X[1] + BOX_W / 2, Y_TOP + BOX_H / 2, X[2], MY)
    add_arrow(slide, X[1] + BOX_W / 2, Y_BOT + BOX_H / 2, X[2], MY)
    add_label(slide, X[2] - 0.30, MY + 0.18, 0.60, "+PosEmbed", fs=6, color=GRAY)

    # ═══ Transformer ═══
    add_box(slide, X[3], MY - BOX_H2 / 2, BOX_W2, BOX_H2,
            "Transformer Encoder  x 4",
            "dim=192  heads=3  FFN=768  GELU", fs=9)
    add_arrow(slide, X[2] + 0.12, MY, X[3], MY)

    # ═══ LN + Linear ═══
    add_box(slide, X[4], MY - BOX_H2 / 2 + BOX_H2 - BOX_H, BOX_W, BOX_H - 0.04,
            "LayerNorm", "dim=192", fs=8)
    add_box(slide, X[4], MY - BOX_H2 / 2, BOX_W, BOX_H - 0.04,
            "Linear  192  →  768", "zero-init", fs=8)
    add_arrow(slide, X[3] + BOX_W2, MY, X[4], MY)
    add_arrow(slide, X[4] + BOX_W / 2, MY - BOX_H2 / 2 + BOX_H2 - BOX_H,
              X[4] + BOX_W / 2, MY - BOX_H2 / 2 + BOX_H - 0.04)

    # ═══ Residual add ═══
    add_plus(slide, X[5], MY)
    add_arrow(slide, X[4] + BOX_W, MY - BOX_H / 2 - 0.06, X[5], MY - 0.02)

    # skip connection
    SKIP_Y = 2.45
    add_arrow(slide, X[0] + BOX_W / 2, Y_TOP + BOX_H, X[0] + BOX_W / 2, SKIP_Y, dashed=True)
    add_arrow(slide, X[0] + BOX_W / 2, SKIP_Y, X[5], SKIP_Y, dashed=True)
    add_arrow(slide, X[5], SKIP_Y, X[5], MY + 0.12, dashed=True)
    add_label(slide, X[0] + BOX_W / 2 - 0.20, SKIP_Y + 0.02, 0.40, "skip", fs=6, color=GRAY)

    # ═══ Repaired X' ═══
    add_box(slide, X[6], MY - BOX_H2 / 2, BOX_W + 0.04, BOX_H2,
            "Repaired  X'", "X' = X + R", fs=9)
    add_arrow(slide, X[5] + 0.10, MY, X[6], MY)

    # ═══ Frozen ViT ═══
    add_box(slide, X[7], MY - BOX_H / 2, BOX_W - 0.10, BOX_H,
            "Frozen ViT", "classifier", fs=8)
    add_arrow(slide, X[6] + BOX_W + 0.04, MY, X[7], MY)

    # ── stage labels ──
    LY = 0.28
    stages = [
        (X[0], BOX_W, "Input"),
        (X[1], BOX_W, "Embedding"),
        (X[3], BOX_W2, "Context Propagation"),
        (X[4], BOX_W, "Projection"),
        (X[6], BOX_W + 0.04, "Residual"),
        (X[7], BOX_W - 0.10, "Frozen"),
    ]
    for sx, sw, sl in stages:
        add_label(slide, sx, LY, sw, sl, fs=7, color=BLACK, bold=True)

    # ── footnote ──
    note = ("D: free by-product of receiver decoding (zero bandwidth).     "
            "Zero-init head: R=0 at init (residual safety).     "
            "Only repair net trained; classifier & patch_embed frozen.")
    add_label(slide, 0.20, 0.04, 9.60, note, fs=6, color=GRAY)

    # ── save ──
    OUT_PPTX.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(OUT_PPTX))
    print(f"saved: {OUT_PPTX.resolve()}")

    # ── export PNG via PowerPoint COM ──
    try:
        import win32com.client
        ppt = win32com.client.Dispatch("PowerPoint.Application")
        ppt.Visible = False
        pres = ppt.Presentations.Open(str(OUT_PPTX.resolve()))
        pres.Slides(0).Export(str(OUT_PNG.resolve()), "PNG", 1200, 384)
        pres.Close()
        ppt.Quit()
        print(f"saved: {OUT_PNG.resolve()}")
    except Exception as e:
        print(f"PNG export skipped ({e}). Open PPT manually → Save As PNG.")


if __name__ == "__main__":
    main()
