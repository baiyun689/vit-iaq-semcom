"""六个独立训练条件的配对消融；同传输协议仅生成一次受损输入。"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from vit_iaq_semcom.ablation import VARIANTS, LABELS, validate_ablation_checkpoints, paired_ablation_differences
from vit_iaq_semcom.experiment import split_indices, provenance, paired_model_evaluation
from vit_iaq_semcom.repair_channel import configure_repair_channel
from vit_iaq_semcom.training import save_metrics


def report(result, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    fig, ax = plt.subplots(figsize=(9, 5.5))
    lines = ["# 独立训练条件的修补消融", "",
             f"每个模型训练 {result['n_train']} 图、完成 {result['training_epochs']['completed_epochs']} 轮；评估 {result['n']} 图；训练种子 {result['training_seed']}。",
             "条件在训练前确定，评估不临时更改网络开关。图像重采样区间为探索性结果，不包含训练方差和多重比较校正。", "",
             "| SNR/dB | 条件 | 修补前 | 修补后 | 净增益/百分点 | 救回率 | 修坏率 |",
             "|---|---|---:|---:|---:|---:|---:|"]
    for name in VARIANTS:
        y = [100*result["summary"][str(snr)][name]["after"] for snr in result["snrs"]]
        err = [100*result["summary"][str(snr)][name]["std"] for snr in result["snrs"]]
        ax.errorbar(result["snrs"], y, yerr=err, fmt="o-", capsize=3, label=LABELS[name])
        for snr in result["snrs"]:
            s = result["summary"][str(snr)][name]
            lines.append(f"| {snr:g} | {LABELS[name]} | {s['before']*100:.1f}% | {s['after']*100:.1f}% | {s['gain']*100:+.1f} | {s['rescued']*100:.1f}% | {s['harmed']*100:.1f}% |")
    ax.set(xlabel="发送编码比特能量 / N0（dB）", ylabel="修补后分类准确率 / %", ylim=(-3, 103),
           xticks=result["snrs"], title=f"独立训练消融 · 训练 {result['n_train']} 图 · 评估 {result['n']} 图\n误差条为信道种子间 ±1 标准差")
    ax.grid(alpha=.2)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(path.with_suffix(".png"), dpi=160)
    plt.close(fig)
    lines += ["", "## 完整条件减去对照条件", "", "| SNR/dB | 对照 | 差值/百分点 | 探索性 95% 区间 |", "|---|---|---:|---|"]
    for snr, comparisons in result["paired_analysis"]["comparisons"].items():
        for name, values in comparisons.items():
            low, high = values["image_bootstrap_95_pp"]
            lines.append(f"| {float(snr):g} | {LABELS[name]} | {values['difference_pp']:+.1f} | [{low:+.1f}, {high:+.1f}] |")
    lines += ["", "- 关闭位深时接收状态仍可能携带增强是否存在的信息；该对照只隔离位深嵌入的直接作用。",
              "- 关闭接收状态时位深仍可反映增强可用性；仅受损图条件才同时关闭两类显式条件。像素本身仍可能体现量化差异。",
              "- 五个显式条件共用同一受损输入、位深和收端状态；网络依据已保存的训练条件屏蔽相应嵌入。参数总量与初始化相同，有效条件路径不同。",
              "- 单点与跨 SNR 对照只改变训练 SNR 范围，模型选择使用相同验证 SNR 列表。它不等同于在每个测试 SNR 单独训练的最优模型。",
              "- 默认验证图排除修补训练和模型选优图。分类器曾在 CIFAR-100 训练集微调，此结果不能替代最终测试。",
              "- 小规模流程验证不证明任何消融条件有效；不同训练种子的结果应分别保留，不混作独立图像。", ""]
    path.with_suffix(".md").write_text("\n".join(lines), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--checkpoint-root", type=Path, help="含六个条件子目录及 best.pt")
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--n", type=int, default=96)
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--sample-offset", type=int)
    ap.add_argument("--split", choices=("validation", "test"), default="validation")
    ap.add_argument("--snrs", default="0,6,12")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--single-snr", type=float, default=6.)
    ap.add_argument("--out", type=Path, default=Path("outputs/corrected/repair_ablation.json"))
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--replot", type=Path)
    args = ap.parse_args()
    if args.replot:
        r = json.loads(args.replot.read_text(encoding="utf-8"))
        if not r.get("complete"):
            ap.error("Cannot plot incomplete results")
        report(r, args.replot)
        return
    if args.checkpoint_root is None or min(args.n, args.batch) < 1 or args.out.suffix != ".json":
        ap.error("Provide checkpoint root, positive counts and .json output")
    if not args.overwrite and any(args.out.with_suffix(s).exists() for s in (".json", ".md", ".png")):
        ap.error("Output exists; use a new path or --overwrite")
    snrs, seeds = [float(v) for v in args.snrs.split(",")], [int(v) for v in args.seeds.split(",")]
    if not np.isfinite(snrs).all() or len(set(snrs)) != len(snrs) or min(seeds) < 0 or len(set(seeds)) != len(seeds):
        ap.error("Use finite distinct SNRs and nonnegative distinct seeds")
    import torch
    import torchvision
    import yaml
    from torch.utils.data import DataLoader, Subset
    from vit_iaq_semcom.pipeline import IAQPipeline
    paths = {name: args.checkpoint_root/name/"best.pt" for name in VARIANTS}
    checkpoints = {name: torch.load(p, map_location="cpu", weights_only=True) for name, p in paths.items()}
    validate_ablation_checkpoints(checkpoints, args.single_snr)
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    cfg["device"] = args.device
    pipe = IAQPipeline.from_config(cfg)
    t = checkpoints["addressed_full"]["training"]
    ds = torchvision.datasets.CIFAR100(args.data_root, train=args.split == "validation", download=True, transform=pipe.enc.transform)
    indices = split_indices(len(ds), t["validation_size"], t["split_seed"])[1] if args.split == "validation" else list(range(len(ds)))
    offset = args.sample_offset if args.sample_offset is not None else (len(t["validation_indices"]) if args.split == "validation" else 0)
    if offset < 0 or offset+args.n > len(indices):
        ap.error("Requested window exceeds evaluation partition")
    ids = indices[offset:offset+args.n]
    if args.split == "validation" and set(ids) & set(t["train_indices"]+t["validation_indices"]):
        ap.error("Evaluation overlaps repair training or model-selection samples")
    loader = DataLoader(Subset(ds, ids), batch_size=args.batch)
    result = dict(complete=False, n=args.n, sample_ids=ids, sample_offset=offset, snrs=snrs, seeds=seeds,
        evaluation_split=args.split, batch=args.batch, n_train=t["n_train"], training_seed=t["seed"],
        training_epochs=checkpoints["addressed_full"]["selection_run"], single_snr=args.single_snr,
        selected_epochs={name: c["epoch"] for name, c in checkpoints.items()},
        checkpoint_sha256={name: hashlib.sha256(p.read_bytes()).hexdigest() for name, p in paths.items()},
        runs={str(s): {str(seed): {} for seed in seeds} for s in snrs}, budgets={}, provenance=provenance())
    for mode in ("addressed", "uniform"):
        names = [name for name, v in VARIANTS.items() if v[0] == mode]
        c = checkpoints[names[0]]
        settings = c["training"]
        buckets, budget = configure_repair_channel(pipe, mode, settings["b_target"], settings["m_base"],
            settings["base_fec_r"], c["protocol"]["buckets"], settings["location_fec_r"])
        result["budgets"][mode] = budget
        nets = {}
        for name in names:
            nets[name] = pipe.load_repair_net(str(paths[name]))
            pipe.validate_repair_protocol(settings["m_base"], settings["base_fec_r"], buckets, mode, settings["location_fec_r"])
        for snr in snrs:
            for seed in seeds:
                values = paired_model_evaluation(pipe, nets, loader, snr, settings["m_base"], settings["base_fec_r"],
                    buckets, seed, mode=mode, location_fec_r=settings["location_fec_r"], channel_budget=budget["cap"])
                for value in values.values():
                    for sid, row in zip(ids, value["predictions"]):
                        row["sample_id"] = sid
                result["runs"][str(snr)][str(seed)].update(values)
                save_metrics(result, args.out)
                print(f"{mode} SNR={snr:g} seed={seed} completed", flush=True)
    result["summary"] = {}
    for snr in snrs:
        result["summary"][str(snr)] = {}
        for name, (mode, _, _) in VARIANTS.items():
            runs = [result["runs"][str(snr)][str(seed)][name] for seed in seeds]
            mean = lambda key: float(np.mean([r[key] for r in runs]))
            result["summary"][str(snr)][name] = dict(before=mean(mode), after=mean(mode+"_repair"),
                std=float(np.std([r[mode+"_repair"] for r in runs])), gain=mean("ai_gain"),
                rescued=mean("rescued_rate"), harmed=mean("harmful_repair_rate"))
    result["paired_analysis"] = paired_ablation_differences(result)
    result["complete"] = True
    save_metrics(result, args.out)
    report(result, args.out)


if __name__ == "__main__":
    main()
