"""SSIM 分布直方图: 差异化裸传(级联崩塌) vs 粗桶(结构完整) — 用于中期报告图 3。

用法:
    python scripts/visualize_ssim_dist.py --snr 3 --n 256
    python scripts/visualize_ssim_dist.py --snr 0 --n 256 --out outputs/ssim_dist_snr0.png
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import torch
import torchvision
import yaml

matplotlib.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False

from vit_iaq_semcom.channel import awgn_channel
from vit_iaq_semcom.pipeline import IAQPipeline, _from_patches


def ssim(a: np.ndarray, b: np.ndarray,
         K1: float = 0.01, K2: float = 0.03, L: float = 1.0) -> float:
    """多通道全图 SSIM (与 visualize_cliff_cases.py 同实现)。"""
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if a.ndim == 2:
        a = a[..., None]; b = b[..., None]
    c = a.shape[2]
    C1 = (K1 * L) ** 2; C2 = (K2 * L) ** 2
    vals = []
    for ch in range(c):
        ax = a[:, :, ch].ravel(); bx = b[:, :, ch].ravel()
        mu_a = np.mean(ax); mu_b = np.mean(bx)
        sig_a = np.var(ax); sig_b = np.var(bx)
        sig_ab = np.mean((ax - mu_a) * (bx - mu_b))
        num = (2.0 * mu_a * mu_b + C1) * (2.0 * sig_ab + C2)
        den = (mu_a ** 2 + mu_b ** 2 + C1) * (sig_a + sig_b + C2)
        vals.append(num / max(den, 1e-12))
    return float(np.mean(vals))


def norm_const(transform):
    for t in getattr(transform, "transforms", [transform]):
        if t.__class__.__name__ == "Normalize":
            return (np.array(t.mean, np.float32).reshape(3, 1, 1),
                    np.array(t.std, np.float32).reshape(3, 1, 1))
    return np.zeros((3, 1, 1), np.float32), np.ones((3, 1, 1), np.float32)


def denorm(x, m, s):
    return np.clip(x * s + m, 0.0, 1.0)


def parse_buckets(s: str) -> list[tuple[int, int]]:
    return [(int(c), int(b)) for c, b in (p.split(":") for p in s.split(","))]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--snr", type=float, default=3.0)
    ap.add_argument("--n", type=int, default=256)
    ap.add_argument("--buckets", default="49:4,49:2,98:1")
    ap.add_argument("--m_base", type=int, default=1)
    ap.add_argument("--base-fec-r", type=int, default=1)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--data-root", default="./data")
    ap.add_argument("--out", default="outputs/ssim_distribution.png")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    cfg["device"] = "cpu"
    pipe = IAQPipeline.from_config(cfg)
    pipe.b_target = 392
    buckets = parse_buckets(args.buckets)
    pipe.m_max = max(pipe.m_max, max(b for _, b in buckets))

    ds = torchvision.datasets.CIFAR100(
        root=args.data_root, train=False, download=True, transform=pipe.enc.transform)
    nstat = args.n
    xs, ys = zip(*[ds[i] for i in range(nstat)])
    x = torch.stack(xs)
    print(f"encoder={pipe.enc.arch} SNR={args.snr}dB n={nstat}")

    mean, std = norm_const(pipe.enc.transform)
    xnp = x.numpy()

    # ── IAQ 裸传 ──
    rng_iaq = np.random.default_rng(args.seed)
    a_all = pipe.enc.attention_scores(x).cpu().numpy()
    recon_iaq = np.empty_like(xnp)
    for k in range(nstat):
        c, h, w = xnp[k].shape
        alloc_cfg = dict(pipe.alloc_cfg)
        pkt = pipe.encode(xnp[k], a_all[k], alloc_cfg)
        pkt = awgn_channel(pkt, args.snr, metadata_through_channel=True, rng=rng_iaq)
        recon_patches = pipe.decode(pkt)
        recon_iaq[k] = _from_patches(recon_patches, c, pipe.gh, pipe.gw, h // pipe.gh, w // pipe.gw)

    # ── Bucket ──
    rng_bucket = np.random.default_rng(args.seed)
    recon_bucket, bdm = pipe.bucket_corrupt(
        xnp, args.snr, args.m_base, args.base_fec_r, buckets, rng_bucket, torch.float32)

    od = denorm(xnp, mean, std)
    iad = denorm(recon_iaq, mean, std)
    bkd = denorm(recon_bucket, mean, std)

    iaq_ssims = np.array([ssim(od[i], iad[i]) for i in range(nstat)])
    bkt_ssims = np.array([ssim(od[i], bkd[i]) for i in range(nstat)])

    iaq_neg = int((iaq_ssims < 0).sum())
    bkt_neg = int((bkt_ssims < 0).sum())

    print(f"IAQ   SSIM mean={iaq_ssims.mean():.4f}  min={iaq_ssims.min():.4f}  neg={iaq_neg}/{nstat}")
    print(f"Bucket SSIM mean={bkt_ssims.mean():.4f}  min={bkt_ssims.min():.4f}  neg={bkt_neg}/{nstat}")

    # ── Plot ──
    fig, ax = plt.subplots(figsize=(10, 5))
    bins = np.linspace(-0.25, 1.05, 53)

    ax.hist(iaq_ssims, bins=bins, alpha=0.65, color="#e94560", label=f"裸传元信息 (μ={iaq_ssims.mean():.3f}, 负值 {iaq_neg}/{nstat})")
    ax.hist(bkt_ssims, bins=bins, alpha=0.65, color="#0f9", label=f"粗桶 (μ={bkt_ssims.mean():.3f}, 负值 {bkt_neg}/{nstat})")

    # 标注负值区域
    ax.axvline(0, color="black", lw=1.2, ls="--")
    ax.annotate("SSIM < 0\n(结构反相关)", xy=(-0.05, 8), fontsize=9, color="#c0392b",
                ha="right", fontweight="bold")

    ax.set_xlabel("SSIM", fontsize=11)
    ax.set_ylabel("图像数量", fontsize=11)
    ax.set_title(
        f"SSIM 分布: 裸传元信息 vs 粗桶 (Eb/N0={args.snr:g} dB, n={nstat}, b=392)",
        fontsize=12)
    ax.legend(fontsize=10, loc="upper left")
    ax.set_xlim(-0.25, 1.05)
    ax.grid(axis="y", alpha=0.3)

    fig.tight_layout()
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=150)
    print(f"saved: {out.resolve()}")

    # 顺便保存 JSON 数据以便后续 --replot
    dat = {
        "snr": args.snr, "n": nstat, "b_target": 392,
        "iaq_ssim_mean": float(iaq_ssims.mean()),
        "iaq_ssim_min": float(iaq_ssims.min()),
        "iaq_ssim_neg": int(iaq_neg),
        "bucket_ssim_mean": float(bkt_ssims.mean()),
        "bucket_ssim_min": float(bkt_ssims.min()),
        "bucket_ssim_neg": int(bkt_neg),
    }
    json_path = out.with_suffix(".json")
    import json
    json_path.write_text(json.dumps(dat, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"data: {json_path.resolve()}")


if __name__ == "__main__":
    main()
