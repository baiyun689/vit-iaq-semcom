"""训练收端语义修补网络（change iaq-learned-semantic-repair，task 3.2）。

数据 = CIFAR-100 过粗桶 / 显式定位 / 均匀量化 + 随机 SNR 的 AWGN；
新协议附带收端实际增强可用性和整帧擦除比例，不能使用发送端诊断真值。
目标 = **分类任务**(交叉熵为主 + 重建 MSE 为辅),跨 SNR 训一个网络。

冻结：分类裁判(含其 patch_embed)全程不动；只训修补网络。梯度经 repaired 图回流到
修补器(分类器权重冻结、但输入可微)。**用任务目标训练**,不重蹈 §2.5 代理目标(逼近干净
图注意力)摊平注意力的覆辙。

⚠️ GPU 重活(CIFAR-100 + ViT-Base 前向 × 每步)。本机 GPU 满载会过热关机 —— **请在另一台
机器上跑**。本机仅可 `--device cpu --n-train 64 --epochs 1` 极小样本冒烟验证管路。

用法(目标机器)：
    python scripts/run_repair_train.py --n-train 45000 --epochs 10 --batch 64 \
        --m_base 1 --buckets 49:4,49:2,98:1 --snr-lo 0 --snr-hi 12 --device cuda
"""

from __future__ import annotations

import argparse
import copy
import random
from pathlib import Path

import numpy as np


from vit_iaq_semcom.experiment import (parse_buckets, split_indices, provenance,
                                        check_protocol, paired_repair_evaluation)
from vit_iaq_semcom.training import capture_rng, restore_rng, save_checkpoint, save_metrics
from vit_iaq_semcom.repair_channel import configure_repair_channel, repair_channel_protocol, training_snr


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--n-train", type=int, default=45000)
    ap.add_argument("--n-val", "--n-test", dest="n_val", type=int, default=1000,
                    help="Held-out training validation samples; --n-test is a legacy alias")
    ap.add_argument("--validation-size", type=int, default=5000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--split-seed", type=int, default=0)
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--b_target", type=int, default=392)
    ap.add_argument("--mode", choices=("bucket", "addressed", "uniform"), default="bucket")
    ap.add_argument("--conditioning", choices=("full", "no_depth", "no_receiver", "none"), default="full",
                    help="训练与推理始终采用此输入消融；保持网络参数量相同")
    ap.add_argument("--location-fec-r", type=int, default=3)
    ap.add_argument("--m_base", type=int, default=1)
    ap.add_argument("--buckets", help="候选桶配置；addressed 默认 98:3,98:1，会自动扣减定位开销")
    ap.add_argument("--base-fec-r", type=int, default=1, help="基础层重复码(1=不保护)")
    ap.add_argument("--snr-lo", type=float, default=0.0, help="训练 Eb/N0 区间下界(dB)")
    ap.add_argument("--snr-hi", type=float, default=12.0, help="训练 Eb/N0 区间上界(dB)")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--lambda-mse", type=float, default=0.1, help="重建 MSE 辅损权重")
    ap.add_argument("--dim", type=int, default=192)
    ap.add_argument("--depth", type=int, default=4)
    ap.add_argument("--heads", type=int, default=3)
    ap.add_argument("--data-root", default="./data")
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--eval-snrs", default="0,3,6,9,12")
    ap.add_argument("--out", default="outputs/corrected/repair_train.json")
    ap.add_argument("--ckpt", default="outputs/corrected/repair_net.pt")
    ap.add_argument("--resume", help="Resume an epoch-boundary checkpoint; --epochs is the total target")
    ap.add_argument("--last-ckpt", help="Latest progress path; default: <ckpt stem>.last<suffix>")
    args = ap.parse_args()
    if args.mode == "bucket" and args.conditioning != "full":
        ap.error("Conditioning ablations currently use addressed or uniform mode")
    if min(args.n_train, args.n_val, args.batch, args.epochs) < 1 or args.workers < 0:
        ap.error("Sample counts, batch and epochs must be positive; workers must be nonnegative")
    if not np.isfinite([args.snr_lo, args.snr_hi, args.lr, args.lambda_mse]).all() or args.snr_lo > args.snr_hi or args.lr <= 0 or args.lambda_mse < 0:
        ap.error("Invalid training hyperparameters")
    if args.seed < 0 or args.split_seed < 0 or not np.isfinite([float(v) for v in args.eval_snrs.split(",")]).all():
        ap.error("Seeds must be nonnegative and evaluation SNRs finite")
    last_path = Path(args.last_ckpt) if args.last_ckpt else Path(args.ckpt).with_name(
        Path(args.ckpt).stem + ".last" + Path(args.ckpt).suffix)
    paths = [Path(args.out).resolve(), Path(args.ckpt).resolve(), last_path.resolve()]
    if len(set(paths)) != len(paths):
        ap.error("Metrics, best checkpoint and latest checkpoint must use different paths")
    for path in paths:
        if Path(path).exists() and not args.overwrite:
            ap.error(f"Output already exists: {path}. Choose a new path or --overwrite")

    import torch
    import torch.nn.functional as F
    import torchvision
    import yaml

    from vit_iaq_semcom.pipeline import IAQPipeline
    from vit_iaq_semcom.repair import SemanticRepairNet

    torch.manual_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)
    rng = np.random.default_rng(args.seed)
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    cfg["device"] = args.device
    buckets = parse_buckets(args.buckets or ("98:3,98:1" if args.mode == "addressed" else "49:4,49:2,98:1"))

    pipe = IAQPipeline.from_config(cfg)
    buckets, budget = configure_repair_channel(pipe, args.mode, args.b_target, args.m_base,
                                               args.base_fec_r, buckets, args.location_fec_r)
    clf = pipe.enc                                    # 冻结分类裁判
    clf.model.eval()
    for p in clf.model.parameters():
        p.requires_grad_(False)
    dev = clf.device

    gh, gw = pipe.gh, pipe.gw
    # patch 维度由 224/grid 推出(deit/vit patch16 → 16×16×3)
    _, height, width = clf.preprocessing["input_size"]
    ph, pw = height // gh, width // gw
    net_config = dict(grid=(gh, gw), patch_dim=(3, ph, pw), m_max=pipe.m_max,
                      dim=args.dim, depth=args.depth, heads=args.heads)
    if args.mode != "bucket":
        net_config["receiver_conditioning"] = True
    if args.conditioning != "full":
        net_config["conditioning"] = args.conditioning
    net = SemanticRepairNet(**net_config).to(dev)
    net.train()
    opt = torch.optim.AdamW(net.parameters(), lr=args.lr)
    n_param = sum(p.numel() for p in net.parameters())
    print(f"encoder={clf.arch} device={dev} b_target={pipe.b_target} m_base={args.m_base} "
          f"buckets={buckets} 修补参数={n_param/1e6:.2f}M snr=[{args.snr_lo},{args.snr_hi}]dB")

    tf = clf.transform
    tr = torchvision.datasets.CIFAR100(args.data_root, train=True, download=True, transform=tf)
    from torch.utils.data import DataLoader, Subset
    train_indices, val_indices = split_indices(len(tr), args.validation_size, args.split_seed)
    if args.n_train > len(train_indices) or args.n_val > len(val_indices):
        ap.error("Requested sample count exceeds its partition; change the count or validation-size")
    train_indices = train_indices[:args.n_train]
    val_indices = val_indices[:args.n_val]
    generator = torch.Generator().manual_seed(args.seed)
    train_loader = DataLoader(Subset(tr, train_indices), batch_size=args.batch, shuffle=True,
                              num_workers=args.workers, generator=generator)
    val_loader = DataLoader(Subset(tr, val_indices), batch_size=args.batch,
                            num_workers=args.workers,
                            generator=torch.Generator().manual_seed(args.seed + 10000))
    nb = len(train_indices)
    eval_snrs = [float(v) for v in args.eval_snrs.split(",")]
    protocol = repair_channel_protocol(pipe, args.mode, args.m_base, args.base_fec_r,
                                       buckets, args.location_fec_r)
    # Only the target epoch and artifact paths may change during an exact restart.
    resume_config = {key: getattr(args, key) for key in (
        "seed", "split_seed", "workers", "validation_size", "batch", "lr", "lambda_mse",
        "snr_lo", "snr_hi", "n_train", "n_val")}
    resume_config.update(eval_snrs=eval_snrs, data_root=str(Path(args.data_root).resolve()),
                         device=str(dev))
    if args.mode != "bucket":
        resume_config.update(snr_schedule="seed-epoch-batch-v1", channel_budget=budget["cap"])
    start_epoch, history, best_score, best_checkpoint = 0, [], float("-inf"), None
    if args.resume:
        checkpoint = torch.load(args.resume, map_location="cpu", weights_only=True)
        required = {"rng_state", "resume_config", "optimizer", "epoch", "history", "training"}
        if not isinstance(checkpoint, dict) or not required <= checkpoint.keys():
            ap.error("Checkpoint has no complete restart state; retrain or use a resumable checkpoint")
        check_protocol(checkpoint["protocol"], protocol)
        if checkpoint["net_config"] != net_config or checkpoint["resume_config"] != resume_config:
            ap.error("Resume configuration differs: preserve architecture, data, batch, seeds and training settings")
        if (checkpoint["training"]["train_indices"] != train_indices or
                checkpoint["training"]["validation_indices"] != val_indices):
            ap.error("Resume dataset partition differs")
        start_epoch = checkpoint["epoch"]
        if args.epochs <= start_epoch:
            ap.error("--epochs must exceed the number of completed epochs in the checkpoint")
        net.load_state_dict(checkpoint["state_dict"])
        opt.load_state_dict(checkpoint["optimizer"])
        history = copy.deepcopy(checkpoint["history"])
        best_checkpoint = copy.deepcopy(checkpoint.get("best_checkpoint", checkpoint))
        best_score = best_checkpoint["selection_score"]
        restore_rng(checkpoint["rng_state"], rng, generator)
        print(f"Resuming after epoch {start_epoch}; best validation accuracy={best_score:.4f}")
    run_provenance = provenance()

    # ------------------------------------------------------------------ 训练
    for ep in range(start_epoch, args.epochs):
        run_ce = run_mse = 0.0
        net.train()
        for batch_index, (xb, yb) in enumerate(train_loader):
            yb = yb.to(dev)
            # 保留旧 bucket 续训轨迹；新对照使用与码流长度无关的相同 SNR 序列。
            ebn0 = (float(rng.uniform(args.snr_lo, args.snr_hi)) if args.mode == "bucket" else
                    training_snr(args.seed, ep, batch_index, args.snr_lo, args.snr_hi))
            recon_np, bdm_np, state_np = pipe.repair_corrupt(
                xb.numpy(), ebn0, args.m_base, args.base_fec_r, buckets, rng, xb.dtype,
                args.mode, args.location_fec_r)
            if any(counts["total"] > budget["cap"] for counts in pipe.last_bit_counts):
                raise ValueError("Training packet exceeds configured channel budget")
            corrupted = torch.from_numpy(recon_np).to(xb.dtype).to(dev)
            bdm = torch.from_numpy(bdm_np).to(dev)
            clean = xb.to(dev)
            receiver_state = torch.as_tensor(state_np, dtype=xb.dtype, device=dev) if state_np is not None else None

            repaired = net(corrupted, bdm, receiver_state)          # 可微(梯度只进修补器)
            logits = clf.model(repaired)                          # 冻结分类器,输入可微
            ce = F.cross_entropy(logits, yb)
            mse = F.mse_loss(repaired, clean)
            loss = ce + args.lambda_mse * mse
            if not torch.isfinite(loss):
                raise ValueError("Non-finite training loss; latest completed epoch remains available")
            opt.zero_grad()
            loss.backward()
            opt.step()
            run_ce += float(ce.detach()) * xb.shape[0]
            run_mse += float(mse.detach()) * xb.shape[0]
        print(f"epoch {ep+1}/{args.epochs} ce={run_ce/nb:.4f} mse={run_mse/nb:.5f}")

        # Keep validation noise and loader seeds fixed across epochs, and isolate all
        # validation randomness from the training trajectory.
        epoch_rng = capture_rng(rng, generator)
        curve = {}
        try:
            for index, snr in enumerate(eval_snrs):
                val_loader.generator.manual_seed(args.seed + 10000)
                curve[snr] = paired_repair_evaluation(pipe, net, val_loader, snr, args.m_base,
                    args.base_fec_r, buckets, args.seed + 10000 + index, mode=args.mode,
                    location_fec_r=args.location_fec_r, channel_budget=budget["cap"])
                for sample_id, record in zip(val_indices, curve[snr]["predictions"]):
                    record["sample_id"] = sample_id
        finally:
            restore_rng(epoch_rng, rng, generator)
        score = float(np.mean([point[f"{args.mode}_repair"] for point in curve.values()]))
        if not np.isfinite(score):
            raise ValueError("Non-finite validation accuracy; checkpoint selection aborted")
        history.append({"epoch": ep + 1, "ce": run_ce / nb, "mse": run_mse / nb,
                        "validation_accuracy": score,
                        "curve": {snr: {k: v for k, v in point.items() if k != "predictions"}
                                  for snr, point in curve.items()}})
        res = {
            "n_train": int(nb), "n_val": len(val_indices), "evaluation_split": "validation", "b_target": args.b_target,
            "m_base": args.m_base, "buckets": buckets, "base_fec_r": args.base_fec_r,
            "snr_train": [args.snr_lo, args.snr_hi], "epochs": ep + 1,
            "lr": args.lr, "lambda_mse": args.lambda_mse, "arch": clf.arch,
            "repair_params_M": n_param / 1e6, "curve": curve,
            "seed": args.seed, "split_seed": args.split_seed, "train_indices": train_indices, "validation_indices": val_indices,
            "validation_size": args.validation_size, "batch_size": args.batch,
            "protocol": protocol, "provenance": run_provenance,
            "mode": args.mode, "channel_budget": budget, "location_fec_r": args.location_fec_r,
            "conditioning": args.conditioning,
        }
        current = {"schema_version": 2, "state_dict": net.state_dict(), "net_config": net_config,
                   "protocol": protocol, "training": res, "optimizer": opt.state_dict(),
                   "epoch": ep + 1, "rng_state": epoch_rng, "resume_config": resume_config,
                   "history": copy.deepcopy(history), "selection_score": score,
                   "selection_metric": "mean validation accuracy across fixed evaluation SNRs"}
        if score > best_score:  # Ties retain the earliest best epoch.
            best_score = score
            best_checkpoint = copy.deepcopy(current)
        if args.mode != "bucket":
            # 最优轮次可以不同，但对照必须完成相同训练轮数。
            best_checkpoint["selection_run"] = {"completed_epochs": ep + 1, "target_epochs": args.epochs}
        # The latest file embeds the best checkpoint so a single file can restart
        # into another directory without losing an earlier best model.
        save_checkpoint({**current, "best_checkpoint": best_checkpoint}, last_path)
        save_checkpoint(best_checkpoint, args.ckpt)
        save_metrics({**res, "last_curve": curve, "curve": best_checkpoint["training"]["curve"],
                      "history": history, "best_epoch": best_checkpoint["epoch"],
                      "best_validation_accuracy": best_score, "target_epochs": args.epochs,
                      "best_ckpt": str(Path(args.ckpt).resolve()), "last_ckpt": str(last_path.resolve()),
                      "resumed_from": args.resume}, args.out)
        print(f"validation={score:.4f}; best epoch={best_checkpoint['epoch']} accuracy={best_score:.4f}; saved")
    print(f"Saved {nb} training and {len(val_indices)} validation sample IDs with paired metrics")
    print(f"saved metrics: {Path(args.out).resolve()}")
    print(f"saved repair ckpt: {Path(args.ckpt).resolve()}")


if __name__ == "__main__":
    main()
