"""Validation-only noisy baselines and addressed enhancement ablation; no training."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from vit_iaq_semcom.experiment import parse_buckets, split_indices, provenance, protocol_config
from vit_iaq_semcom.training import save_metrics


LABELS = {"uniform": "均匀量化", "original": "原分档配置", "candidate": "候选分档配置",
          "adjusted": "扣减精度分档（隐式排序）", "addressed": "显式定位（含保护开销）",
          "oracle": "同受损载荷 + 真值定位（诊断）"}


def sample_rng(seed, sample_id):
    return np.random.default_rng(np.random.SeedSequence([seed, int(sample_id)]))


def evaluate_batch(pipe, x, labels, sample_ids, snrs, seeds, original, candidate, adjusted,
                   m_base, header_r, channel_budget):
    """Reuse base attention; matched branches receive exactly the same corrupted payload."""
    import torch
    from vit_iaq_semcom.a1 import base_reconstruct
    from vit_iaq_semcom.addressed import (addressed_encode, addressed_through_channel,
        addressed_decode, addressed_bit_counts, location_diagnostics)
    from vit_iaq_semcom.bucket import (bucket_encode, bucket_through_channel, bucket_decode,
                                      bucket_decode_base, assignment_diagnostics)
    from vit_iaq_semcom.channel import awgn_channel
    from vit_iaq_semcom.pipeline import _to_patches, _from_patches

    images = x.numpy()
    _, c, h, w = images.shape
    gh, gw = pipe.gh, pipe.gw
    ph, pw = h // gh, w // gw
    ranges = pipe.quantization_range
    to_image = lambda patches: _from_patches(patches, c, gh, gw, ph, pw)
    bases = np.stack([base_reconstruct(img, m_base, *ranges) for img in images])
    tx_scores = pipe._attn.attention_scores(torch.as_tensor(bases, dtype=x.dtype)).cpu().numpy()
    packets = {key: [] for key in ("uniform", "original", "candidate", "addressed")}
    for image, score in zip(images, tx_scores):
        patches = _to_patches(image, gh, gw)
        packets["uniform"].append(pipe.encode(image, score, {"strategy": "uniform"}))
        for name, buckets in (("original", original), ("candidate", candidate)):
            packets[name].append(bucket_encode(patches, score, *ranges, m_base, buckets, pipe.m_max))
        packets["addressed"].append(addressed_encode(patches, score, *ranges, m_base, adjusted,
                                                    pipe.m_max, header_r))
    output = {}
    for snr in snrs:
        for seed in seeds:
            received = [addressed_through_channel(pkt, snr, sample_rng(seed, sid))
                        for pkt, sid in zip(packets["addressed"], sample_ids)]
            rx_bases = np.stack([to_image(bucket_decode_base(pkt.payload)) for pkt in received])
            rx_scores = pipe._attn.attention_scores(torch.as_tensor(rx_bases, dtype=x.dtype)).cpu().numpy()
            recon = {name: [] for name in LABELS}
            records = {name: [] for name in LABELS}
            for k, (image, sample_id) in enumerate(zip(images, sample_ids)):
                def record(name, image_hat, counts, diagnostics):
                    if counts["total"] > channel_budget:
                        raise ValueError(f"{name} exceeds channel budget")
                    recon[name].append(image_hat)
                    records[name].append({"sample_id": int(sample_id), "label": int(labels[k]),
                        "bit_counts": {**counts, "unused": channel_budget - counts["total"]},
                        "diagnostics": diagnostics,
                        "recon_mse": float(np.mean((image_hat - image) ** 2))})
                packet = awgn_channel(packets["uniform"][k], snr, False, sample_rng(seed, sample_id))
                image_hat = to_image(pipe.decode(packet))
                record("uniform", image_hat, {"total": int(packet.payload_bits.size)}, {})
                for name, buckets in (("original", original), ("candidate", candidate)):
                    pkt = bucket_through_channel(packets[name][k], snr, sample_rng(seed, sample_id))
                    if not np.array_equal(pkt.base_bits, received[k].payload.base_bits):
                        raise AssertionError("Paired base noise must match across all bucket branches")
                    record(name, to_image(bucket_decode(pkt, rx_scores[k])),
                           {"total": int(pkt.base_bits.size + pkt.enh_bits.size)},
                           assignment_diagnostics(tx_scores[k], rx_scores[k], buckets, m_base))
                pkt = received[k]
                counts = addressed_bit_counts(adjusted, gh * gw, c * ph * pw, m_base, header_r)
                record("adjusted", to_image(bucket_decode(pkt.payload, rx_scores[k])),
                       {"total": int(pkt.payload.base_bits.size + pkt.payload.enh_bits.size)},
                       assignment_diagnostics(tx_scores[k], rx_scores[k], adjusted, m_base))
                patches, _, _ = addressed_decode(pkt)
                record("addressed", to_image(patches), counts,
                       location_diagnostics(packets["addressed"][k], pkt))
                record("oracle", to_image(bucket_decode(pkt.payload, tx_scores[k])), counts,
                       {"oracle_sender_ranking": True})
            for name in LABELS:
                predictions = pipe.enc.classify(torch.as_tensor(np.stack(recon[name]), dtype=x.dtype))[1].cpu()
                for row, prediction in zip(records[name], predictions):
                    row["prediction"] = int(prediction)
            output[(str(snr), str(seed))] = records
    return output


def aggregate(result):
    stats = {}
    for snr in result["snrs"]:
        values = {}
        for name in LABELS:
            runs = [result["runs"][str(snr)][str(seed)][name] for seed in result["seeds"]]
            accuracies = [float(np.mean([row["prediction"] == row["label"] for row in rows])) for rows in runs]
            values[name] = {"accuracy": float(np.mean(accuracies)), "std": float(np.std(accuracies)),
                            "per_seed_accuracy": accuracies,
                            "channel_bits": runs[0][0]["bit_counts"]["total"]}
        rows = [row for seed in result["seeds"] for row in result["runs"][str(snr)][str(seed)]["addressed"]]
        keys = ("enhancement_slot_count", "erased_records", "accepted_records", "undetected_wrong_records")
        diagnostics = {key: sum(row["diagnostics"][key] for row in rows) for key in keys}
        values["addressed"]["diagnostics"] = diagnostics
        stats[str(snr)] = values
    return stats


def paired_differences(result, n_resamples=10000, bootstrap_seed=20261003):
    """Resample images, keeping all noise-seed observations of an image together.

    Intervals are exploratory percentile bootstrap intervals conditional on the fixed
    classifier, protocol and sampled channel seeds; they do not cover training variance.
    """
    ids = result["sample_ids"]
    if not ids or len(ids) != len(set(ids)) or len(ids) != result["n"]:
        raise ValueError("Need unique complete sample IDs for paired analysis")
    draws = np.random.default_rng(bootstrap_seed).integers(0, len(ids), size=(n_resamples, len(ids)))
    comparisons = {}
    for snr in result["snrs"]:
        branches = {}
        for name in LABELS:
            rows_by_seed = [result["runs"][str(snr)][str(seed)][name] for seed in result["seeds"]]
            if any([row["sample_id"] for row in rows] != ids for rows in rows_by_seed):
                raise ValueError("Unpaired or incomplete branch sample IDs")
            branches[name] = np.asarray([[row["prediction"] == row["label"] for row in rows]
                                         for rows in rows_by_seed], dtype=float)
        comparisons[str(snr)] = {}
        for reference in ("uniform", "adjusted", "oracle"):
            per_image = (branches["addressed"] - branches[reference]).mean(axis=0)
            distribution = per_image[draws].mean(axis=1)
            interval = np.quantile(distribution, [.025, .975])
            comparisons[str(snr)][reference] = {
                "mean_difference_pp": float(100 * per_image.mean()),
                "image_bootstrap_95_percentile_pp": (100 * interval).tolist(),
                "positive_images": int(np.sum(per_image > 0)),
                "negative_images": int(np.sum(per_image < 0)),
                "tied_images": int(np.sum(per_image == 0)),
                "per_image_difference": per_image.tolist(),
            }
    return {"resampling_unit": "image; all channel seeds kept together", "resamples": n_resamples,
            "bootstrap_seed": bootstrap_seed, "comparisons": comparisons}


def select_validation_ids(ids, n, offset=0):
    if n < 1 or offset < 0 or offset + n > len(ids):
        raise ValueError("Requested validation window exceeds partition or has invalid bounds")
    return ids[offset:offset + n]


def report(result, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    fig, ax = plt.subplots(figsize=(9, 5.5))
    for name, title in LABELS.items():
        y = [100 * result["summary"][str(snr)][name]["accuracy"] for snr in result["snrs"]]
        error = [100 * result["summary"][str(snr)][name]["std"] for snr in result["snrs"]]
        ax.errorbar(result["snrs"], y, yerr=error, fmt="o--" if name == "oracle" else "o-",
                    capsize=3, label=title)
    ax.set(xlabel="发送编码比特能量 / N0（dB）", ylabel="分类准确率 / %", ylim=(-3, 103),
           xticks=result["snrs"], title=f"显式定位对照 · 验证样本 n={result['n']} · B={result['b_target']}\n误差条为信道种子间 ±1 标准差")
    ax.legend(fontsize=9)
    ax.grid(alpha=.2)
    fig.tight_layout()
    fig.savefig(path.with_suffix(".png"), dpi=160)
    plt.close(fig)
    lines = ["# 有噪声基线与显式定位对照", "",
             f"验证样本 {result['n']} 张；信道种子 {result['seeds']}；固定范围、基础层 {result['m_base']} bit；总发送上限 {result['channel_budget']} bit/图。",
             f"原配置 {result['original_buckets']}；候选配置 {result['candidate_buckets']}；支付定位开销后 {result['addressed_buckets']}。", "",
             "| 方案 | " + " | ".join(f"{snr:g} dB 均值±标准差" for snr in result["snrs"]) + " | 每图发送 bit |",
             "|---|" + "---:|" * (len(result["snrs"]) + 1)]
    for name, title in LABELS.items():
        cells = [f"{100*result['summary'][str(snr)][name]['accuracy']:.1f}% ± {100*result['summary'][str(snr)][name]['std']:.1f}" for snr in result["snrs"]]
        lines.append("| " + title + " | " + " | ".join(cells) + f" | {result['summary'][str(result['snrs'][0])][name]['channel_bits']} |")
    lines += ["", "## 定位信息与擦除", "",
              "8 位 CRC 只检验块编号；编号与校验一起重复保护。坏头/越界编号/重复编号导致对应增强记录擦除；基础层不变。有效但错误的码字可能漏检。",
              "",
              "| SNR/dB | 总增强记录 | 接受 | 擦除 | 漏检错投（仿真真值统计） |", "|---|---:|---:|---:|---:|"]
    for snr in result["snrs"]:
        d = result["summary"][str(snr)]["addressed"]["diagnostics"]
        lines.append(f"| {snr:g} | {d['enhancement_slot_count']} | {d['accepted_records']} | {d['erased_records']} | {d['undetected_wrong_records']} |")
    if "paired_analysis" in result:
        lines += ["", "## 按图像配对的差值", "",
                  "先对每张图的三个信道种子取平均差值，再以图像为单位重采样 10000 次。下列区间是探索性的 95% 百分位 bootstrap 区间，条件于当前分类器、协议和所取信道种子；不包含训练方差或模型选择不确定性。",
                  "",
                  "| SNR/dB | 显式定位相对 | 平均差值/百分点 | 探索性 95% 区间 | 净获益/净受损/持平图像 |",
                  "|---|---|---:|---|---|"]
        for snr in result["snrs"]:
            for reference, value in result["paired_analysis"]["comparisons"][str(snr)].items():
                lo, hi = value["image_bootstrap_95_percentile_pp"]
                lines.append(f"| {snr:g} | {LABELS[reference]} | {value['mean_difference_pp']:+.1f} | [{lo:+.1f}, {hi:+.1f}] | {value['positive_images']}/{value['negative_images']}/{value['tied_images']} |")
    lines += ["", "## 对照解释", "",
              "- 显式定位、扣减精度分档和 oracle 使用完全相同的基础层/增强层受损比特，定位差别由接收端处理决定。",
              "- 扣减精度分档少用定位保护对应的预算，专门隔离定位影响；其余实际用量在上表中列明，不能说所有方案恰好用满相同比特数。",
              "- oracle 额外获知发送端排序，只用于诊断；显式定位解码器不使用发送端真值。",
              "- 每条记录保存样本编号、预测、开销和诊断。随机流由信道种子与样本 ID 决定。",
              "- 小样本、共享样本的多信道种子重复并非独立新增图像；标准差不是泛化置信区间。",
              "- 样本来自 CIFAR-100 训练集的固定验证划分，分类器已在该数据集微调；本轮没有使用最终测试集选型。",
              "- 编号防错不保护基础层或增强像素本身；精度扣减是启发式；本实验未训练修补网络。",
              "- 本轮按样本 ID 派生随机流，与前一轮按批消耗随机流不同；有噪声数值以本次共同重跑的各条线为准。", "",
              "分类准确率可能随 SNR 非单调；不能据少量观测声称噪声通常有益，需检查样本与种子稳定性。", "",
              f"本轮从固定验证划分第 {result.get('sample_offset', 0)} 个位置开始取样。排除参考文件：{result.get('exclude_reference')}。这仍是协议验证数据，不是最终测试集。", "",
              "## 协议与运行配置", "", "```json", json.dumps({k: result[k] for k in
              ("addressed_budget", "header_r", "batch", "seeds", "sample_ids", "protocol")}, ensure_ascii=False, indent=2), "```", ""]
    path.with_suffix(".md").write_text("\n".join(lines), encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--n", type=int, default=24)
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--b-target", type=int, default=392)
    ap.add_argument("--m-base", type=int, default=1)
    ap.add_argument("--header-r", type=int, default=3)
    ap.add_argument("--original", default="49:4,49:2,98:1")
    ap.add_argument("--candidate", default="98:3,98:1")
    ap.add_argument("--snrs", default="0,6,12")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--split-seed", type=int, default=0)
    ap.add_argument("--validation-size", type=int, default=5000)
    ap.add_argument("--sample-offset", type=int, default=0, help="Offset within the fixed validation partition")
    ap.add_argument("--exclude-reference", type=Path, help="Reject overlap with sample_ids from a prior result JSON")
    ap.add_argument("--data-root", default="data")
    ap.add_argument("--out", type=Path, default=Path("outputs/corrected/addressed_20261003/comparison.json"))
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--replot", type=Path)
    args = ap.parse_args()
    if args.replot:
        result = json.loads(args.replot.read_text(encoding="utf-8"))
        if not result["complete"]:
            ap.error("Cannot plot incomplete results")
        result["paired_analysis"] = paired_differences(result)
        report(result, args.replot)
        return
    if args.out.suffix != ".json" or min(args.n, args.batch, args.b_target) < 1 or args.split_seed < 0:
        ap.error("Require positive counts/budget, nonnegative split seed and a .json output")
    if not args.overwrite and any(args.out.with_suffix(s).exists() for s in (".json", ".png", ".md")):
        ap.error("Output exists; use a new path or --overwrite")
    snrs, seeds = [float(s) for s in args.snrs.split(",")], [int(s) for s in args.seeds.split(",")]
    if not np.isfinite(snrs).all() or len(set(snrs)) != len(snrs) or min(seeds) < 0 or len(set(seeds)) != len(seeds):
        ap.error("Use finite distinct SNRs and distinct nonnegative seeds")
    import torch
    import torchvision
    import yaml
    from torch.utils.data import DataLoader, Subset
    from vit_iaq_semcom.pipeline import IAQPipeline
    from vit_iaq_semcom.addressed import fit_addressed_buckets
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    cfg["device"] = args.device
    pipe = IAQPipeline.from_config(cfg)
    pipe.b_target = args.b_target
    original, candidate = parse_buckets(args.original), parse_buckets(args.candidate)
    for buckets in (original, candidate):
        pipe.validate_bucket_protocol(buckets, args.m_base, 1)
    c, h, w = pipe.enc.preprocessing["input_size"]
    p = c * (h // pipe.gh) * (w // pipe.gw)
    cap = args.b_target * p
    adjusted, counts = fit_addressed_buckets(candidate, pipe.gh * pipe.gw, p, args.m_base,
                                            pipe.m_max, cap, args.header_r)
    ds = torchvision.datasets.CIFAR100(args.data_root, train=True, download=True, transform=pipe.enc.transform)
    _, ids = split_indices(len(ds), args.validation_size, args.split_seed)
    try:
        ids = select_validation_ids(ids, args.n, args.sample_offset)
    except ValueError as exc:
        ap.error(str(exc))
    if args.exclude_reference:
        previous = json.loads(args.exclude_reference.read_text(encoding="utf-8"))
        if set(ids) & set(previous["sample_ids"]):
            ap.error("Validation samples overlap the excluded reference")
    loader = DataLoader(Subset(ds, ids), batch_size=args.batch)
    result = dict(complete=False, n=args.n, snrs=snrs, seeds=seeds, sample_ids=ids,
        b_target=args.b_target, m_base=args.m_base, header_r=args.header_r, channel_budget=cap,
        original_buckets=original, candidate_buckets=candidate, addressed_buckets=adjusted,
        addressed_budget=counts, batch=args.batch, split_seed=args.split_seed,
        sample_offset=args.sample_offset, exclude_reference=str(args.exclude_reference) if args.exclude_reference else None,
        validation_size=args.validation_size, evaluation_split="validation", device=str(pipe.enc.device),
        protocol=protocol_config(pipe, args.m_base, 1, adjusted), provenance=provenance(),
        runs={str(snr): {str(seed): {key: [] for key in LABELS} for seed in seeds} for snr in snrs})
    print(f"addressed buckets={adjusted}, total bits={counts['total']}/{cap}", flush=True)
    offset = 0
    for x, labels in loader:
        batch = evaluate_batch(pipe, x, labels, ids[offset:offset+len(x)], snrs, seeds,
                               original, candidate, adjusted, args.m_base, args.header_r, cap)
        for (snr, seed), branches in batch.items():
            for name, rows in branches.items():
                result["runs"][snr][seed][name].extend(rows)
        offset += len(x)
        result["completed_samples"] = offset
        save_metrics(result, args.out)
        print(f"Completed {offset}/{args.n} images across {len(snrs)} SNRs and {len(seeds)} channel seeds", flush=True)
    result["summary"] = aggregate(result)
    result["paired_analysis"] = paired_differences(result)
    result["complete"] = True
    save_metrics(result, args.out)
    report(result, args.out)
    for snr in snrs:
        print(f"SNR={snr:g}: " + " ".join(f"{name}={result['summary'][str(snr)][name]['accuracy']:.3f}" for name in LABELS))
    print(f"Saved {args.out.resolve()}")


if __name__ == "__main__":
    main()
