"""2.4 节图6：语义修补网络性能增益（双线图）。
从 repair_train.json 提取粗桶 vs 粗桶+修补，突出 AI 增益。
用法：python scripts/visualize_repair_gain.py
"""

from __future__ import annotations
import json
from pathlib import Path
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "outputs" / "六线图2" / "repair_train.json"
OUT  = ROOT / "outputs" / "repair_gain.png"


def main():
    d = json.loads(DATA.read_text(encoding="utf-8"))
    curve = d["curve"]
    snrs = [float(k) for k in curve.keys()]
    snrs.sort()

    bucket      = [curve[f"{s:.1f}"]["bucket"] for s in snrs]
    bucket_rep  = [curve[f"{s:.1f}"]["bucket_repair"] for s in snrs]
    ai_gain     = [curve[f"{s:.1f}"]["ai_gain"] for s in snrs]

    fig, ax = plt.subplots(figsize=(5.8, 3.8))
    ax.set_xlim(-0.8, 12.8)
    ax.set_ylim(0.0, 0.78)

    # lines
    ax.plot(snrs, bucket,     "v-", color="#555555", lw=1.6, ms=6,
            label="Bucket (without repair)")
    ax.plot(snrs, bucket_rep, "o-", color="black",   lw=1.8, ms=7,
            label="Bucket + Semantic Repair")

    # fill between (AI gain shading)
    ax.fill_between(snrs, bucket, bucket_rep, alpha=0.15, color="black")

    # gain annotations
    for s, b, r, g in zip(snrs, bucket, bucket_rep, ai_gain):
        mid = (b + r) / 2
        ax.annotate(f"+{g:.2f}", (s, mid), fontsize=7.5, color="black",
                    ha="center", va="center", fontweight="bold",
                    bbox=dict(boxstyle="round,pad=0.15", facecolor="white",
                              edgecolor="black", linewidth=0.6))

    ax.set_xlabel("Eb/N0 (dB)", fontsize=11)
    ax.set_ylabel("CIFAR-100 Top-1 Accuracy", fontsize=11)
    ax.legend(fontsize=9, loc="lower right", framealpha=0.9)
    ax.grid(True, alpha=0.25, linestyle="--")

    ax.set_title("图6  语义修补性能增益", fontsize=12, fontweight="bold")


    OUT.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout(pad=0.5)
    fig.savefig(OUT, dpi=180, bbox_inches="tight", facecolor="white")
    print(f"saved: {OUT.resolve()}")


if __name__ == "__main__":
    main()
