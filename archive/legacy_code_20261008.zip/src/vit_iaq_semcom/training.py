"""Epoch-boundary restart state and atomic experiment artifacts."""
from __future__ import annotations

import json
import os
import random
import tempfile
from pathlib import Path

import numpy as np
import torch


def capture_rng(rng, generator) -> dict:
    legacy = np.random.get_state()
    return {
        "python": random.getstate(),
        "numpy": [legacy[0], torch.tensor(legacy[1].astype(np.int64)), *legacy[2:]],
        "channel": rng.bit_generator.state,
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_initialized() else [],
        "loader": generator.get_state(),
    }


def restore_rng(state, rng, generator) -> None:
    random.setstate(state["python"])
    legacy = state["numpy"]
    np.random.set_state((legacy[0], legacy[1].cpu().numpy().astype(np.uint32), *legacy[2:]))
    rng.bit_generator.state = state["channel"]
    torch.set_rng_state(state["torch"].cpu())
    if state["cuda"]:
        if len(state["cuda"]) != torch.cuda.device_count():
            raise ValueError("Resume requires the same number of CUDA devices")
        torch.cuda.set_rng_state_all([value.cpu() for value in state["cuda"]])
    generator.set_state(state["loader"].cpu())


def _atomic_write(path, write) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            write(stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def save_checkpoint(value, path) -> None:
    _atomic_write(path, lambda stream: torch.save(value, stream))


def save_metrics(value, path) -> None:
    data = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")
    _atomic_write(path, lambda stream: stream.write(data))
