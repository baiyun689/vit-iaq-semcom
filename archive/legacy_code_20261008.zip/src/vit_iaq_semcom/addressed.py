"""Fixed enhancement slots with transmitted patch IDs and protected ID checksums.

Shared framing/range settings are protocol constants, not received side information.
CRC covers the ID only; undetected errors and damaged enhancement values remain possible.
No transmitter ranking is needed by addressed_decode.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from itertools import groupby

import numpy as np

from .bucket import (BucketPacket, validate_buckets, validate_packet, bits_per_rank,
                     bucket_encode, bucket_decode_base, bucket_through_channel)
from .fec import validate_repetition, repetition_encode, repetition_decode
from .modulation import bpsk_awgn
from .quantization import index_to_bits, bitstream_to_indices, uniform_dequantize


def id_width(n: int) -> int:
    if not isinstance(n, (int, np.integer)) or n < 1:
        raise ValueError("Patch count must be a positive integer")
    return max(1, int(n - 1).bit_length())


def crc8(bits: np.ndarray) -> int:
    """MSB-first polynomial 0x07, init/xorout=0; zero-pad ID to full bytes."""
    crc = 0
    for byte in np.packbits(bits):
        crc ^= int(byte)
        for _ in range(8):
            crc = ((crc << 1) ^ (0x07 if crc & 0x80 else 0)) & 0xFF
    return crc


def encode_id(patch_id: int, n: int, r: int) -> np.ndarray:
    if not 0 <= patch_id < n:
        raise ValueError("Patch ID out of range")
    bits = index_to_bits(patch_id, id_width(n))
    return repetition_encode(np.concatenate([bits, index_to_bits(crc8(bits), 8)]), r)


def addressed_bit_counts(buckets, n, p, m_base, header_r=3, base_r=1) -> dict:
    validate_repetition(header_r)
    validate_repetition(base_r)
    depths = bits_per_rank(buckets, n)
    if p < 1 or not isinstance(p, (int, np.integer)) or m_base < 1 or np.any(depths < m_base):
        raise ValueError("Invalid patch dimensions or base depth")
    active = int(np.sum(depths > m_base))
    base = int(n * p * m_base)
    enhancement = int(np.sum(depths - m_base) * p)
    metadata, checksum = active * id_width(n), active * 8
    fec = base * (base_r - 1) + (metadata + checksum) * (header_r - 1)
    return dict(base=base, enhancement=enhancement, metadata=metadata, checksum=checksum,
                fec=fec, total=base + enhancement + metadata + checksum + fec)


def fit_addressed_buckets(buckets, n, p, m_base, m_max, channel_budget, header_r=3, base_r=1):
    """Pay for headers by removing lowest-priority enhancement bit planes first."""
    depths = validate_buckets(buckets, n, m_base, m_max).copy()
    if np.any(depths[:-1] < depths[1:]):
        raise ValueError("Budget fitting requires nonincreasing rank depths")
    validate_repetition(header_r)
    validate_repetition(base_r)
    if not isinstance(channel_budget, (int, np.integer)) or channel_budget < n * p * m_base * base_r:
        raise ValueError("Channel budget cannot carry the base layer")
    while True:
        adjusted = [(len(list(group)), int(value)) for value, group in groupby(depths)]
        counts = addressed_bit_counts(adjusted, n, p, m_base, header_r, base_r)
        if counts["total"] <= channel_budget:
            return adjusted, {**counts, "unused": int(channel_budget - counts["total"])}
        active = np.flatnonzero(depths > m_base)
        depths[active[-1]] -= 1


@dataclass
class AddressedPacket:
    payload: BucketPacket
    headers: np.ndarray
    header_r: int


def addressed_encode(patches, scores, umin, umax, m_base, buckets, m_max,
                     header_r=3, base_r=1) -> AddressedPacket:
    validate_repetition(header_r)
    payload = bucket_encode(patches, scores, umin, umax, m_base, buckets, m_max, base_r)
    order = np.argsort(-np.asarray(scores), kind="stable")
    depths = bits_per_rank(buckets, len(order))
    ids = order[depths > m_base]
    headers = np.concatenate([encode_id(int(i), len(order), header_r) for i in ids]) if len(ids) else np.zeros(0, dtype=np.uint8)
    return AddressedPacket(payload, headers, header_r)


def _validate(packet):
    validate_packet(packet.payload)
    validate_repetition(packet.header_r)
    p = packet.payload
    active = int(np.sum(bits_per_rank(p.buckets, p.n_patches) > p.m_base))
    if packet.headers.ndim != 1 or len(packet.headers) != active * (id_width(p.n_patches) + 8) * packet.header_r:
        raise ValueError("Address header length does not match fixed framing")
    for bits in (packet.headers, p.base_bits, p.enh_bits):
        if not np.isin(bits, [0, 1]).all():
            raise ValueError("Packet must contain binary bits")


def addressed_through_channel(packet, snr, rng) -> AddressedPacket:
    _validate(packet)
    if np.isnan(snr) or snr == -np.inf:
        raise ValueError("Invalid channel SNR")
    # Payload draws occur first, matching bucket_through_channel with the same RNG.
    payload = bucket_through_channel(packet.payload, snr, rng)
    return replace(packet, payload=payload, headers=bpsk_awgn(packet.headers, snr, rng))


def decode_ids(packet) -> tuple[list[int | None], dict]:
    _validate(packet)
    n = packet.payload.n_patches
    width = id_width(n)
    rows = repetition_decode(packet.headers, packet.header_r).reshape(-1, width + 8)
    ids = []
    crc_failures = out_of_range = 0
    for row in rows:
        value = int(bitstream_to_indices(row[:width], width, 1)[0])
        valid_crc = crc8(row[:width]) == int(bitstream_to_indices(row[width:], 8, 1)[0])
        if not valid_crc:
            crc_failures += 1
        elif value >= n:
            out_of_range += 1
        ids.append(value if valid_crc and value < n else None)
    counts = {}
    for value in ids:
        if value is not None:
            counts[value] = counts.get(value, 0) + 1
    duplicates = sum(value is not None and counts[value] > 1 for value in ids)
    ids = [value if value is not None and counts[value] == 1 else None for value in ids]
    return ids, {"enhancement_slot_count": len(ids), "crc_failures": crc_failures,
                 "out_of_range_ids": out_of_range, "duplicate_records": duplicates,
                 "erased_records": sum(value is None for value in ids),
                 "accepted_records": sum(value is not None for value in ids)}


def addressed_decode(packet) -> tuple[np.ndarray, np.ndarray, dict]:
    """Decode without attention, true IDs or sender rank. Rejected records keep base."""
    ids, diagnostics = decode_ids(packet)
    p = packet.payload
    out = bucket_decode_base(p)
    depth = np.full(p.n_patches, p.m_base, dtype=np.int64)
    base = repetition_decode(p.base_bits, p.base_fec_r).reshape(p.n_patches, p.values_per_patch, p.m_base)
    cursor = 0
    slot = 0
    for total_depth in bits_per_rank(p.buckets, p.n_patches):
        extra = int(total_depth) - p.m_base
        if extra == 0:
            continue
        length = p.values_per_patch * extra
        enhancement = p.enh_bits[cursor:cursor + length].reshape(p.values_per_patch, extra)
        cursor += length  # Always consume the fixed slot, even when its ID is invalid.
        patch_id = ids[slot]
        slot += 1
        if patch_id is None:
            continue
        full = np.concatenate([base[patch_id], enhancement], axis=1).ravel()
        indices = bitstream_to_indices(full, int(total_depth), p.values_per_patch)
        out[patch_id] = uniform_dequantize(indices, int(total_depth), p.umin, p.umax)
        depth[patch_id] = total_depth
    return out, depth, diagnostics


def location_diagnostics(sent, received) -> dict:
    """Simulation only: count accepted but wrong IDs; never used by the decoder."""
    true_ids, _ = decode_ids(sent)
    rx_ids, diagnostic = decode_ids(received)
    wrong = sum(rx is not None and rx != tx for tx, rx in zip(true_ids, rx_ids))
    return {**diagnostic, "undetected_wrong_records": wrong,
            "header_coded_bit_errors": int(np.sum(sent.headers != received.headers)),
            "base_coded_bit_errors": int(np.sum(sent.payload.base_bits != received.payload.base_bits)),
            "enhancement_bit_errors": int(np.sum(sent.payload.enh_bits != received.payload.enh_bits))}
