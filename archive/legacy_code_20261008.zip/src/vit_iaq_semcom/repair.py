"""Receiver residual repair conditioned on allocated bit depth.

Bit depth describes quantization precision, not measured channel reliability. A zero
output head makes the INITIAL network an identity. Trained residuals may harm task
performance; evaluate both beneficial and harmful changes on paired corruptions.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn


def patchify(img: torch.Tensor, gh: int, gw: int) -> torch.Tensor:
    """(B,C,H,W) -> (B,N,C*ph*pw)，行优先 patch 顺序（对齐 pipeline._to_patches）。"""
    b, c, h, w = img.shape
    ph, pw = h // gh, w // gw
    p = img.reshape(b, c, gh, ph, gw, pw)        # (B,C,gh,ph,gw,pw)
    p = p.permute(0, 2, 4, 1, 3, 5)              # (B,gh,gw,C,ph,pw)
    return p.reshape(b, gh * gw, c * ph * pw)    # (B,N,C*ph*pw)


def unpatchify(patches: torch.Tensor, c: int, gh: int, gw: int, ph: int, pw: int) -> torch.Tensor:
    """逆操作：(B,N,C*ph*pw) -> (B,C,H,W)。"""
    b = patches.shape[0]
    p = patches.reshape(b, gh, gw, c, ph, pw)    # (B,gh,gw,C,ph,pw)
    p = p.permute(0, 3, 1, 4, 2, 5)              # (B,C,gh,ph,gw,pw)
    return p.reshape(b, c, gh * ph, gw * pw)


class SemanticRepairNet(nn.Module):
    """轻量 patch-Transformer：受损重建、位深及可选收端状态 → 残差修正。"""

    def __init__(
        self,
        grid: tuple[int, int] = (14, 14),
        patch_dim: tuple[int, int, int] = (3, 16, 16),  # (C, ph, pw)
        m_max: int = 8,
        dim: int = 192,
        depth: int = 4,
        heads: int = 3,
        mlp_ratio: float = 4.0,
        receiver_conditioning: bool = False,
        conditioning: str = "full",
    ) -> None:
        super().__init__()
        if conditioning not in ("full", "no_depth", "no_receiver", "none"):
            raise ValueError("Unknown repair conditioning ablation")
        self.conditioning = conditioning
        self.gh, self.gw = grid
        self.c, self.ph, self.pw = patch_dim
        self.m_max = m_max
        n = self.gh * self.gw
        pdim = self.c * self.ph * self.pw

        self.patch_embed = nn.Linear(pdim, dim)
        # 位深描述接收精度，并非信道可靠性或真值误码标签。
        self.depth_embed = nn.Embedding(m_max + 1, dim)
        self.receiver_conditioning = receiver_conditioning
        self.receiver_embed = nn.Linear(2, dim, bias=False) if receiver_conditioning else None
        self.pos_embed = nn.Parameter(torch.zeros(1, n, dim))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        layer = nn.TransformerEncoderLayer(
            d_model=dim, nhead=heads, dim_feedforward=int(dim * mlp_ratio),
            activation="gelu", batch_first=True, norm_first=True,
        )
        self.blocks = nn.TransformerEncoder(
            layer, num_layers=depth, enable_nested_tensor=False)
        self.norm = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, pdim)
        # head 零初始化只保证初始化时为恒等映射，不保证训练后性能
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self, img: torch.Tensor, bit_depth: torch.Tensor,
                receiver_state: torch.Tensor | None = None) -> torch.Tensor:
        """img: (B,C,H,W) 受损重建；bit_depth: (B,N) int 每 patch 总比特。返回修正图 (B,C,H,W)。"""
        x = patchify(img, self.gh, self.gw)                  # (B,N,pdim)
        d = bit_depth.clamp(0, self.m_max).long()            # (B,N)
        # 保留全部参数和初始化顺序，只屏蔽条件贡献；不能改变码流或重建。
        depth_token = self.depth_embed(d) * float(self.conditioning not in ("no_depth", "none"))
        tok = self.patch_embed(x) + depth_token + self.pos_embed
        if self.receiver_conditioning:
            if (receiver_state is None or receiver_state.shape != (*bit_depth.shape, 2)
                    or not torch.isfinite(receiver_state).all()
                    or torch.any((receiver_state < 0) | (receiver_state > 1))):
                raise ValueError("Expected finite receiver state (B,N,2) in [0,1]")
            state_token = self.receiver_embed(receiver_state.to(dtype=img.dtype, device=img.device))
            tok = tok + state_token * float(self.conditioning not in ("no_receiver", "none"))
        elif receiver_state is not None:
            raise ValueError("This repair network was not configured for receiver state")
        tok = self.blocks(tok)
        residual = self.head(self.norm(tok))                 # (B,N,pdim)
        out = x + residual                                   # Residual correction; no accuracy guarantee
        return unpatchify(out, self.c, self.gh, self.gw, self.ph, self.pw)


@torch.no_grad()
def repair_reconstruction(
    net: SemanticRepairNet,
    recon: np.ndarray,
    bit_depth: np.ndarray,
    dtype: torch.dtype = torch.float32,
    device: torch.device | str | None = None,
    receiver_state: np.ndarray | None = None,
) -> np.ndarray:
    """推理接口（task 3.3）：受损重建 (B,C,H,W) + 比特深度图 (B,N) → 修正重建 (B,C,H,W) numpy。

    纯前向、不训练；网络若未训练(head 零初始化)则输出恒等于输入(兜底)。
    """
    net.eval()
    dev = torch.device(device) if device is not None else next(net.parameters()).device
    x = torch.as_tensor(recon, dtype=dtype, device=dev)
    d = torch.as_tensor(bit_depth, device=dev)
    state = torch.as_tensor(receiver_state, dtype=dtype, device=dev) if receiver_state is not None else None
    if x.ndim == 3:                                          # (C,H,W) → (1,C,H,W)
        x = x.unsqueeze(0)
        d = d.unsqueeze(0)
        if state is not None:
            state = state.unsqueeze(0)
    fixed = net(x, d, state)
    return fixed.cpu().numpy().astype(recon.dtype)
