"""端到端 IAQ 流程编排 (Sec. II 图 1)。

device: 图像张量 -> ViT 注意力 a_i -> 增量比特分配 M_i -> patch 均匀量化 -> 载荷比特 + 元信息
channel: (BSC) 载荷恒过；元信息按开关
server : 按收到的 M_i 切分载荷 -> 反量化重建张量 -> ViT 分类 -> Top-1

约定（design D6）：量化作用在 ViT 输入张量上（已归一化、224×224）。一个 patch =
16×16×3 = 768 个标量，整 patch 用同一比特数 M_i。默认范围由预处理常数固定共享；image_minmax 仅用于显式元信息/理想参考。
本流程纯推理，不训练任何网络。
"""

from __future__ import annotations

import numpy as np
import torch

from .a1 import (
    A1Packet,
    a1_decode,
    a1_decode_base,
    a1_encode,
    a1_through_channel,
    base_reconstruct,
)
from .bit_allocation import allocate
from .bucket import (
    assignment_diagnostics,
    validate_buckets,
    bit_depth_map,
    bucket_decode,
    bucket_decode_base,
    bucket_encode,
    bucket_through_channel,
)
from .channel import Packet, apply_channel, awgn_channel, awgn_channel_fec, pack_metadata
from .experiment import bit_accounting, protocol_config, check_protocol
from .fec import validate_repetition
from .quantization import (
    bitstream_to_indices,
    quantize_to_bitstream,
    uniform_dequantize,
)
from .repair import SemanticRepairNet, repair_reconstruction
from .vit_encoder import ViTEncoder


def _to_patches(img: np.ndarray, gh: int, gw: int) -> np.ndarray:
    """(C,H,W) -> (N, C*ph*pw)，行优先 patch 顺序（与 timm patch_embed 一致）。"""
    c, h, w = img.shape
    ph, pw = h // gh, w // gw
    p = img.reshape(c, gh, ph, gw, pw)          # (C, gh, ph, gw, pw)
    p = p.transpose(1, 3, 0, 2, 4)              # (gh, gw, C, ph, pw)
    return p.reshape(gh * gw, c * ph * pw)      # (N, C*ph*pw)


def _from_patches(patches: np.ndarray, c: int, gh: int, gw: int, ph: int, pw: int) -> np.ndarray:
    """逆操作：(N, C*ph*pw) -> (C, H, W)。"""
    p = patches.reshape(gh, gw, c, ph, pw)      # (gh, gw, C, ph, pw)
    p = p.transpose(2, 0, 3, 1, 4)              # (C, gh, ph, gw, pw)
    return p.reshape(c, gh * ph, gw * pw)


class IAQPipeline:
    """重要性感知量化语义通信端到端流程。"""

    def __init__(
        self,
        encoder: ViTEncoder,
        m_max: int = 8,
        b_target: int = 980,
        weight: str = "attention",
        strategy: str = "incremental",
        range_policy: str = "fixed",
        quantization_range: tuple[float, float] | None = None,
    ) -> None:
        self.enc = encoder
        if not isinstance(m_max, int) or not 1 <= m_max <= 16:
            raise ValueError("m_max must be an integer in [1, 16]")
        if not isinstance(b_target, int) or b_target < 0:
            raise ValueError("b_target must be a nonnegative integer")
        self.m_max = m_max
        self.b_target = b_target
        self.alloc_cfg = {"weight": weight, "strategy": strategy}
        self.gh, self.gw = encoder.grid_size
        if range_policy not in ("fixed", "image_minmax"):
            raise ValueError("range_policy must be fixed or image_minmax")
        self.range_policy = range_policy
        self.quantization_range = tuple(quantization_range if quantization_range is not None else getattr(encoder, "quantization_range", (-10.0, 10.0)))
        if len(self.quantization_range) != 2 or not np.isfinite(self.quantization_range).all() or self.quantization_range[0] >= self.quantization_range[1]:
            raise ValueError("Invalid fixed quantization range")
        self.last_diagnostics: list[dict] = []
        self.last_bit_counts: list[dict] = []
        self.repair_protocol: dict | None = None
        # 可选：A1 在压缩图上派生分配的专职注意力提取器(§2.5 微调后的 student)。
        # None 时回退 self.enc。分类裁判恒为冻结 self.enc,不受影响。
        self.attn_enc: ViTEncoder | None = None
        # 可选：收端学习式语义修补网络(bucket+repair 模式)。未加载时 bucket+repair 报错。
        self.repair_net: SemanticRepairNet | None = None

    @property
    def _attn(self) -> ViTEncoder:
        """A1 派生分配用的注意力提取器:有微调 student 用它,否则回退分类网络。"""
        return self.attn_enc if self.attn_enc is not None else self.enc

    def load_attn_encoder(self, ckpt_path: str, cfg: dict, role: str = "server") -> ViTEncoder:
        """加载 §2.5 微调后的 student 注意力提取器(.pt = state_dict),供 A1 派生分配用。

        分类裁判仍是冻结 self.enc(不挪尺子);收发两端共用此 attn_enc → metadata-free 不破。
        注意:student 是针对某个 m_base 压缩分布训的,run_batch 的 m_base 须与训练时一致。
        用 weights='random' 建同架构空壳再灌 student 权重,避免重复下载原 hf 权重。
        """
        m = cfg["model"]
        enc = ViTEncoder(
            arch=m.get(f"{role}_arch", m["arch"]),
            weights="random",
            num_classes=m["num_classes"],
            device=cfg.get("device", "cuda"),
        )
        state = torch.load(ckpt_path, map_location=enc.device, weights_only=True)
        state = state.get("state_dict", state) if isinstance(state, dict) else state
        enc.model.load_state_dict(state, strict=True)
        import hashlib
        from pathlib import Path
        enc.weights_id = "sha256:" + hashlib.sha256(Path(ckpt_path).read_bytes()).hexdigest()
        enc.model.eval()
        self.attn_enc = enc
        return enc

    @classmethod
    def from_config(cls, cfg: dict) -> "IAQPipeline":
        enc = ViTEncoder.from_config(cfg, role="server")
        q = cfg.get("quantization", {})
        return cls(
            encoder=enc,
            m_max=q.get("m_max", 8),
            b_target=q.get("b_target", 980),
            weight=q.get("weight", "attention"),
            strategy=q.get("alloc", q.get("strategy", "incremental")),
            range_policy=q.get("range_policy", "fixed"),
            quantization_range=q.get("fixed_range"),
        )

    def image_range(self, img: np.ndarray) -> tuple[float, float]:
        if self.range_policy == "fixed":
            return self.quantization_range
        return float(img.min()), float(img.max())

    def validate_bucket_protocol(self, buckets, m_base, base_fec_r):
        if self.range_policy != "fixed":
            raise ValueError("Metadata-free modes require a fixed shared quantization range")
        validate_repetition(base_fec_r)
        depths = validate_buckets(buckets, self.gh * self.gw, m_base, self.m_max)
        if int(depths.sum()) != self.b_target:
            raise ValueError(f"Bucket source budget {int(depths.sum())} != b_target {self.b_target}")

    def validate_repair_protocol(self, m_base, base_fec_r, buckets, mode="bucket", location_fec_r=3):
        from .repair_channel import repair_channel_protocol
        if self.repair_net is None:
            raise ValueError(f"{mode}+repair requires a loaded repair checkpoint")
        if self.repair_protocol is not None:
            check_protocol(self.repair_protocol, repair_channel_protocol(
                self, mode, m_base, base_fec_r, buckets, location_fec_r))

    # ---------------------------------------------------------------- device
    def encode(self, img: np.ndarray, a_i: np.ndarray, alloc_cfg: dict | None = None) -> Packet:
        """一张图（C,H,W 归一化张量）+ 其 a_i -> Packet。alloc_cfg 可覆盖分配策略。"""
        c, h, w = img.shape
        ph, pw = h // self.gh, w // self.gw
        patches = _to_patches(img, self.gh, self.gw)      # (N, P)
        n, p = patches.shape

        umin, umax = self.image_range(img)
        m_map = allocate(a_i, self.b_target, self.m_max, alloc_cfg or self.alloc_cfg)

        streams = [
            quantize_to_bitstream(patches[i], int(m_map[i]), umin, umax)
            for i in range(n)
        ]
        payload = (
            np.concatenate(streams).astype(np.uint8)
            if streams else np.zeros(0, dtype=np.uint8)
        )
        return Packet(payload, m_map, umin, umax, values_per_patch=p, m_max=self.m_max)

    # ---------------------------------------------------------------- server
    def decode(self, pkt: Packet) -> np.ndarray:
        """Packet -> 重建 patch 张量 (N, P)。按收到的 M_i 顺序切分（失步即崩）。"""
        n = pkt.m_map.shape[0]
        p = pkt.values_per_patch
        out = np.empty((n, p), dtype=np.float64)
        cursor = 0
        padded_bits = 0
        for i in range(n):
            m = int(pkt.m_map[i])
            nbits = m * p
            seg = pkt.payload_bits[cursor:cursor + nbits]
            padded_bits += max(0, nbits - seg.size)
            idx = bitstream_to_indices(seg, m, count=p)
            out[i] = uniform_dequantize(idx, m, pkt.umin, pkt.umax)
            cursor += nbits
        self.last_diagnostics.append({"padded_payload_bits": int(padded_bits),
                                      "unused_payload_bits": max(0, int(pkt.payload_bits.size - cursor)),
                                      "invalid_received_range": bool(pkt.umin >= pkt.umax)})
        return out

    # -------------------------------------------------------------------- A1
    def _run_a1(
        self, x: np.ndarray, ebn0_db: float, m_base: int, base_fec_r: int,
        b_enh: int | None, rng: np.random.Generator, dtype: torch.dtype,
    ) -> np.ndarray:
        """A1 元信息-free 批处理：两端在基础层重建图上各自算注意力派生分配。

        发端在自己的基础层重建上算 a_i 编码；收端解出基础层(经 FEC)后**重新**算 a_i
        派生 ΔM_i，故基础层受损时收发分配会随之一致地变化(诚实建模)。
        """
        b, c, h, w = x.shape
        ph, pw = h // self.gh, w // self.gw
        n = self.gh * self.gw
        if b_enh is None:
            b_enh = self.b_target - n * m_base

        if self.range_policy != "fixed":
            raise ValueError("A1 requires a fixed shared range; image_minmax would use oracle information")
        if b_enh < 0:
            raise ValueError("A1 enhancement budget cannot be negative")
        if not 1 <= m_base <= self.m_max:
            raise ValueError("Require 1 <= m_base <= m_max")
        umins = np.full(b, self.quantization_range[0])
        umaxs = np.full(b, self.quantization_range[1])

        # 发端：基础层重建 → 注意力 → 编码 → 过信道
        x_base_tx = np.stack(
            [base_reconstruct(x[k], m_base, umins[k], umaxs[k]) for k in range(b)])
        a_tx = self._attn.attention_scores(
            torch.from_numpy(x_base_tx).to(dtype)).cpu().numpy()
        pkts: list[A1Packet] = []
        for k in range(b):
            pkt = a1_encode(_to_patches(x[k], self.gh, self.gw), a_tx[k],
                            umins[k], umaxs[k], m_base, b_enh, self.m_max, base_fec_r)
            self.last_bit_counts.append(bit_accounting(base=pkt.base_bits.size // base_fec_r,
                                                       enhancement=pkt.enh_bits.size, base_r=base_fec_r))
            pkts.append(a1_through_channel(pkt, ebn0_db, rng))

        # 收端：解基础层 → 重新算注意力 → 派生 ΔM_i → 解增强层
        x_base_rx = np.empty_like(x)
        for k in range(b):
            _, base_patches = a1_decode_base(pkts[k])
            x_base_rx[k] = _from_patches(base_patches, c, self.gh, self.gw, ph, pw)
        a_rx = self._attn.attention_scores(
            torch.from_numpy(x_base_rx).to(dtype)).cpu().numpy()
        recon = np.empty_like(x)
        for k in range(b):
            recon[k] = _from_patches(
                a1_decode(pkts[k], a_rx[k]), c, self.gh, self.gw, ph, pw)
        return recon

    # ---------------------------------------------------------------- bucket
    def load_repair_net(self, ckpt_path: str, **net_kwargs) -> SemanticRepairNet:
        """加载已训练的语义修补网络(.pt = state_dict),供 bucket+repair 模式用。

        net_kwargs 须与训练时构造一致(grid/patch_dim/m_max/dim/depth/heads)。
        """
        state = torch.load(ckpt_path, map_location=self.enc.device, weights_only=True)
        if not isinstance(state, dict) or state.get("schema_version") != 2:
            raise ValueError("Legacy repair checkpoint lacks protocol metadata. Retrain with the corrected fixed-range pipeline.")
        saved_kwargs = state["net_config"]
        for key, value in net_kwargs.items():
            saved = saved_kwargs.get(key)
            if (list(value) if isinstance(value, tuple) else value) != (list(saved) if isinstance(saved, tuple) else saved):
                raise ValueError(f"Repair architecture mismatch: {key}")
        net = SemanticRepairNet(**saved_kwargs)
        net.load_state_dict(state["state_dict"], strict=True)
        net.to(self.enc.device).eval()
        self.repair_net = net
        self.repair_protocol = state["protocol"]
        return net

    def bucket_corrupt(
        self, x: np.ndarray, ebn0_db: float, m_base: int, base_fec_r: int,
        buckets: list[tuple[int, int]] | None, rng: np.random.Generator,
        dtype: torch.dtype,
    ) -> tuple[np.ndarray, np.ndarray]:
        """粗桶非级联源编码 → 信道 → 解码,返回 (受损重建 (B,C,H,W), 比特深度图 (B,N))。

        发端在基础层重建图上算注意力排序入桶；收端解基础层 → 重新算注意力派生排序 →
        定长读增强层重组(边界不失步，归属仍可能错配)。比特深度图(派生副产品)供修补网络作可靠性输入。
        不含修补 —— 供 bucket/bucket+repair 推理与修补网络训练共用(同一损伤分布)。
        """
        b, c, h, w = x.shape
        ph, pw = h // self.gh, w // self.gw
        n = self.gh * self.gw
        if not np.isfinite(x).all() or np.isnan(ebn0_db) or ebn0_db == -np.inf:
            raise ValueError("Nonfinite input or invalid channel parameter")
        if buckets is None:                          # 安全回退:单桶≈均匀(实验脚本应显式传桶)
            buckets = [(n, max(self.b_target // n, m_base))]
        self.validate_bucket_protocol(buckets, m_base, base_fec_r)
        self.last_diagnostics = []
        self.last_bit_counts = []
        umins = np.full(b, self.quantization_range[0])
        umaxs = np.full(b, self.quantization_range[1])

        # 发端：基础层重建 → 注意力 → 入桶编码 → 过信道
        x_base_tx = np.stack(
            [base_reconstruct(x[k], m_base, umins[k], umaxs[k]) for k in range(b)])
        a_tx = self._attn.attention_scores(
            torch.from_numpy(x_base_tx).to(dtype)).cpu().numpy()
        pkts = []
        for k in range(b):
            pkt = bucket_encode(_to_patches(x[k], self.gh, self.gw), a_tx[k],
                                umins[k], umaxs[k], m_base, buckets, self.m_max, base_fec_r)
            received = bucket_through_channel(pkt, ebn0_db, rng)
            self.last_bit_counts.append(bit_accounting(base=pkt.base_bits.size // base_fec_r,
                                                       enhancement=pkt.enh_bits.size, base_r=base_fec_r))
            self.last_diagnostics.append({"base_coded_bit_errors": int(np.sum(pkt.base_bits != received.base_bits)),
                                          "enhancement_bit_errors": int(np.sum(pkt.enh_bits != received.enh_bits)),
                                          "input_clipped_values": int(np.sum((x[k] < umins[k]) | (x[k] > umaxs[k])))})
            pkts.append(received)

        # 收端：解基础层 → 重新算注意力 → 派生排序 → 定长解增强层
        x_base_rx = np.empty_like(x)
        for k in range(b):
            x_base_rx[k] = _from_patches(
                bucket_decode_base(pkts[k]), c, self.gh, self.gw, ph, pw)
        a_rx = self._attn.attention_scores(
            torch.from_numpy(x_base_rx).to(dtype)).cpu().numpy()
        recon = np.empty_like(x)
        bdm = np.zeros((b, n), dtype=np.int64)
        for k in range(b):
            recon[k] = _from_patches(
                bucket_decode(pkts[k], a_rx[k]), c, self.gh, self.gw, ph, pw)
            bdm[k] = bit_depth_map(a_rx[k], buckets, self.m_max)
            self.last_diagnostics[k].update(assignment_diagnostics(a_tx[k], a_rx[k], buckets, m_base))
        return recon, bdm

    def _run_bucket(
        self, x: np.ndarray, ebn0_db: float, m_base: int, base_fec_r: int,
        buckets: list[tuple[int, int]] | None, rng: np.random.Generator,
        dtype: torch.dtype, repair: bool,
    ) -> np.ndarray:
        """粗桶批处理；repair=True 时在解码图上加收端学习式修补(零额外带宽)。"""
        recon, bdm = self.bucket_corrupt(
            x, ebn0_db, m_base, base_fec_r, buckets, rng, dtype)
        if repair:
            effective_buckets = buckets or [(self.gh * self.gw, self.b_target // (self.gh * self.gw))]
            self.validate_repair_protocol(m_base, base_fec_r, effective_buckets)
            repaired = repair_reconstruction(self.repair_net, recon, bdm, dtype)
            for k, diagnostics in enumerate(self.last_diagnostics):
                diagnostics["repair_residual_mse"] = float(np.mean((repaired[k] - recon[k]) ** 2))
            recon = repaired
        return recon

    # ------------------------------------------------------------- end-to-end
    def addressed_corrupt(self, x, ebn0_db, m_base, base_fec_r, buckets, rng, dtype,
                          location_fec_r=3, *, return_receiver_state=False):
        from .addressed import (addressed_encode, addressed_through_channel, addressed_decode,
                                addressed_bit_counts, location_diagnostics)
        if buckets is None:
            raise ValueError("addressed requires an explicit budget-adjusted bucket configuration")
        self.validate_bucket_protocol(buckets, m_base, base_fec_r)
        validate_repetition(location_fec_r)
        if not np.isfinite(x).all() or np.isnan(ebn0_db) or ebn0_db == -np.inf:
            raise ValueError("Nonfinite input or invalid SNR")
        b, c, h, w = x.shape
        ph, pw = h // self.gh, w // self.gw
        bases = np.stack([base_reconstruct(img, m_base, *self.quantization_range) for img in x])
        scores = self._attn.attention_scores(torch.from_numpy(bases).to(dtype)).cpu().numpy()
        recon, depths = np.empty_like(x), []
        states = []
        self.last_bit_counts, self.last_diagnostics = [], []
        for k, img in enumerate(x):
            sent = addressed_encode(_to_patches(img, self.gh, self.gw), scores[k],
                                    *self.quantization_range, m_base, buckets, self.m_max,
                                    location_fec_r, base_fec_r)
            received = addressed_through_channel(sent, ebn0_db, rng)
            patches, depth, receiver_diagnostics = addressed_decode(received)
            recon[k] = _from_patches(patches, c, self.gh, self.gw, ph, pw)
            depths.append(depth)
            # 校验失败的编号不能定位到原图块；只广播收端已知的全帧擦除比例。
            erased = receiver_diagnostics["erased_records"] / max(1, receiver_diagnostics["enhancement_slot_count"])
            states.append(np.stack([depth > m_base, np.full(len(depth), erased)], axis=-1).astype(np.float32))
            self.last_bit_counts.append(addressed_bit_counts(buckets, self.gh * self.gw,
                                       c * ph * pw, m_base, location_fec_r, base_fec_r))
            self.last_diagnostics.append(location_diagnostics(sent, received))
        if return_receiver_state:
            return recon, np.stack(depths), np.stack(states)
        return recon, np.stack(depths)

    def repair_corrupt(self, x, ebn0_db, m_base, base_fec_r, buckets, rng, dtype,
                       mode="bucket", location_fec_r=3):
        """训练、配对验证和推理共用损伤入口，第三项仅包含接收端状态。"""
        if mode == "bucket":
            recon, depth = self.bucket_corrupt(x, ebn0_db, m_base, base_fec_r, buckets, rng, dtype)
            return recon, depth, None
        if mode == "addressed":
            return self.addressed_corrupt(x, ebn0_db, m_base, base_fec_r, buckets, rng, dtype,
                                          location_fec_r, return_receiver_state=True)
        if mode != "uniform" or self.range_policy != "fixed" or base_fec_r != 1:
            raise ValueError("Uniform repair requires a fixed range and no base-layer FEC")
        if not np.isfinite(x).all() or np.isnan(ebn0_db) or ebn0_db == -np.inf:
            raise ValueError("Nonfinite input or invalid SNR")
        b, c, h, w = x.shape
        ph, pw, n = h // self.gh, w // self.gw, self.gh * self.gw
        recon, depths = np.empty_like(x), []
        self.last_bit_counts, self.last_diagnostics = [], []
        for k, img in enumerate(x):
            # 均匀分配先验已知，无需计算注意力或发送分配图。
            packet = self.encode(img, np.ones(n), {"strategy": "uniform"})
            received = awgn_channel(packet, ebn0_db, False, rng)
            recon[k] = _from_patches(self.decode(received), c, self.gh, self.gw, ph, pw)
            depths.append(received.m_map.copy())
            self.last_bit_counts.append(bit_accounting(payload=packet.payload_bits.size))
        return recon, np.stack(depths), np.zeros((b, n, 2), dtype=np.float32)

    @torch.no_grad()
    def run_batch(
        self,
        images: torch.Tensor,
        labels: torch.Tensor | None = None,
        channel_type: str = "bsc",
        mu: float = 0.0,
        ebn0_db: float = float("inf"),
        metadata_through_channel: bool = False,
        alloc: str | None = None,
        seed: int = 0,
        mode: str = "iaq",
        meta_fec_r: int = 1,
        payload_fec_r: int = 1,
        base_fec_r: int = 1,
        m_base: int = 1,
        b_enh: int | None = None,
        buckets: list[tuple[int, int]] | None = None,
        location_fec_r: int = 3,
    ) -> dict:
        """images: (B,3,224,224) 预处理后张量。返回 logits/preds/(accuracy)。

        channel_type: 'bsc'(用 mu) | 'awgn'(用 ebn0_db)。
        alloc: 覆盖比特分配策略('incremental'|'uniform'|...)，None 用 pipeline 默认。
        mode: 'iaq'(默认,既有路径) | 'eep' | 'uep' | 'a1'(元信息-free)
              | 'bucket' | 'addressed' | 'uniform'，后三者均可加 '+repair'，修补零额外带宽。
        meta_fec_r/payload_fec_r: EEP/UEP 的元信息/载荷重复码速率分母。
        base_fec_r/m_base/b_enh: A1 的基础层 FEC、基础层比特、增强层预算(缺省 b_target−N·m_base)。
        buckets: bucket/bucket+repair 模式的桶配置 list[(cnt, 总比特)]，缺省单桶≈均匀。
        """
        if mode not in ("iaq", "eep", "uep", "a1", "bucket", "bucket+repair", "addressed",
                        "addressed+repair", "uniform", "uniform+repair"):
            raise ValueError(f"Unknown transmission mode: {mode}")
        if channel_type not in ("bsc", "awgn"):
            raise ValueError(f"Unknown channel type: {channel_type}")
        if mode != "iaq" and channel_type != "awgn":
            raise ValueError(f"{mode} currently supports AWGN only")
        if not 0 <= mu <= 1 or np.isnan(ebn0_db) or ebn0_db == -np.inf:
            raise ValueError("Invalid channel noise parameter")
        if images.ndim != 4 or images.shape[0] == 0 or not torch.isfinite(images).all():
            raise ValueError("Expected a finite nonempty BCHW image tensor")
        for rate in (base_fec_r, meta_fec_r, payload_fec_r):
            validate_repetition(rate)
        if mode.endswith("+repair") and self.repair_net is None:
            raise ValueError(f"{mode} requires a loaded repair checkpoint")
        self.last_diagnostics = []
        self.last_bit_counts = []
        rng = np.random.default_rng(seed)
        x = images.cpu().numpy()
        b, c, h, w = x.shape
        if h % self.gh or w % self.gw:
            raise ValueError("Image dimensions must be divisible by the patch grid")
        ph, pw = h // self.gh, w // self.gw

        if mode == "a1":
            recon = self._run_a1(x, ebn0_db, m_base, base_fec_r, b_enh, rng, images.dtype)
        elif mode in ("addressed", "addressed+repair", "uniform", "uniform+repair"):
            channel_mode = mode.split("+")[0]
            if mode.endswith("+repair"):
                self.validate_repair_protocol(m_base, base_fec_r, buckets, channel_mode, location_fec_r)
            recon, depth, state = self.repair_corrupt(x, ebn0_db, m_base, base_fec_r, buckets,
                                                     rng, images.dtype, channel_mode, location_fec_r)
            if mode.endswith("+repair"):
                recon = repair_reconstruction(self.repair_net, recon, depth, images.dtype, receiver_state=state)
        elif mode in ("bucket", "bucket+repair"):
            recon = self._run_bucket(
                x, ebn0_db, m_base, base_fec_r, buckets, rng, images.dtype,
                repair=(mode == "bucket+repair"))
        else:
            alloc_cfg = {**self.alloc_cfg, "strategy": alloc} if alloc else None
            a = self.enc.attention_scores(images).cpu().numpy()   # (B, N)
            recon = np.empty_like(x)
            for k in range(b):
                image_rng = np.random.default_rng(rng.integers(0, 2**32))
                pkt = self.encode(x[k], a[k], alloc_cfg)
                uniform = (alloc or self.alloc_cfg["strategy"]) == "uniform"
                sends_meta = mode in ("eep", "uep") or metadata_through_channel
                metadata_bits = int(pack_metadata(pkt.m_map, pkt.umin, pkt.umax, pkt.m_max).size)
                count = bit_accounting(payload=pkt.payload_bits.size,
                                       metadata=metadata_bits if sends_meta else 0,
                                       payload_r=payload_fec_r if mode in ("eep", "uep") else 1,
                                       metadata_r=meta_fec_r if mode in ("eep", "uep") else 1)
                count["oracle_side_bits"] = ((0 if uniform else metadata_bits - 32)
                                             + (32 if self.range_policy == "image_minmax" else 0)) if not sends_meta else 0
                self.last_bit_counts.append(count)
                if mode in ("eep", "uep"):
                    pkt = awgn_channel_fec(pkt, ebn0_db, image_rng, meta_fec_r, payload_fec_r)
                elif channel_type == "awgn":
                    pkt = awgn_channel(pkt, ebn0_db, metadata_through_channel, image_rng)
                else:
                    pkt = apply_channel(pkt, mu, metadata_through_channel, image_rng)
                recon[k] = _from_patches(self.decode(pkt), c, self.gh, self.gw, ph, pw)
                self.last_diagnostics[-1]["input_clipped_values"] = int(np.sum(
                    (x[k] < self.quantization_range[0]) | (x[k] > self.quantization_range[1]))) if self.range_policy == "fixed" else 0

        if not np.isfinite(recon).all():
            raise FloatingPointError("Decoder produced nonfinite values; inspect the packet rather than replacing them silently")
        x_hat = torch.from_numpy(recon).to(images.dtype)
        logits, preds = self.enc.classify(x_hat)

        out = {"logits": logits, "preds": preds, "recon_mse": float(np.mean((recon - x) ** 2))}
        out.update(bit_counts=self.last_bit_counts, diagnostics=self.last_diagnostics)
        if labels is not None:
            labels = labels.to(preds.device)
            out["accuracy"] = float((preds == labels).float().mean())
        return out
