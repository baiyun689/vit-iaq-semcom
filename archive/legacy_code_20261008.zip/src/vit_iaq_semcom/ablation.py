"""预先声明消融条件；允许的差异必须明确，其他训练条件严格匹配。"""
from __future__ import annotations

import numpy as np


VARIANTS = {
    "addressed_full": ("addressed", "full", "cross"),
    "addressed_no_depth": ("addressed", "no_depth", "cross"),
    "addressed_no_receiver": ("addressed", "no_receiver", "cross"),
    "addressed_none": ("addressed", "none", "cross"),
    "addressed_single": ("addressed", "full", "single"),
    "uniform_full": ("uniform", "full", "cross"),
}
LABELS = {"addressed_full": "完整条件", "addressed_no_depth": "关闭位深",
          "addressed_no_receiver": "关闭接收状态", "addressed_none": "仅受损图",
          "addressed_single": "单点 SNR 训练", "uniform_full": "均匀量化+修补"}


def validate_ablation_checkpoints(checkpoints, single_snr=6.):
    if set(checkpoints) != set(VARIANTS):
        raise ValueError("Need exactly the six declared ablation checkpoints")
    reference = checkpoints["addressed_full"]
    lo, hi = reference["training"]["snr_train"]
    if not np.isfinite([lo, hi, single_snr]).all() or not lo < hi or not lo <= single_snr <= hi:
        raise ValueError("Cross-SNR range must be nondegenerate and contain the single training SNR")
    for name, (mode, conditioning, regime) in VARIANTS.items():
        c = checkpoints[name]
        if c.get("schema_version") != 2 or c["protocol"].get("transmission_mode") != mode:
            raise ValueError(f"{name}: checkpoint transmission mode mismatch")
        if c["net_config"].get("conditioning", "full") != conditioning or c["training"].get("conditioning", "full") != conditioning:
            raise ValueError(f"{name}: checkpoint conditioning mismatch")
        if not c["net_config"].get("receiver_conditioning"):
            raise ValueError(f"{name}: receiver-conditioned architecture required")
        architecture = lambda value: {k: v for k, v in value.items() if k != "conditioning"}
        if architecture(c["net_config"]) != architecture(reference["net_config"]):
            raise ValueError(f"{name}: architecture mismatch")
        if not c.get("selection_run") or c["selection_run"] != reference.get("selection_run"):
            raise ValueError(f"{name}: training epochs mismatch")
        expected_snr = [single_snr, single_snr] if regime == "single" else [lo, hi]
        if c["training"]["snr_train"] != expected_snr:
            raise ValueError(f"{name}: training SNR contrast mismatch")
        resume = dict(c["resume_config"])
        if [resume["snr_lo"], resume["snr_hi"]] != expected_snr:
            raise ValueError(f"{name}: inconsistent saved SNR configuration")
        resume.update(snr_lo=lo, snr_hi=hi)
        if resume != reference["resume_config"]:
            raise ValueError(f"{name}: non-ablated training settings differ")
        for key in ("train_indices", "validation_indices", "seed", "split_seed", "validation_size",
                    "batch_size", "lr", "lambda_mse"):
            if c["training"][key] != reference["training"][key]:
                raise ValueError(f"{name}: {key} mismatch")
        if c["training"]["channel_budget"]["cap"] != reference["training"]["channel_budget"]["cap"]:
            raise ValueError(f"{name}: channel budget mismatch")
        if mode == "addressed":
            if c["protocol"] != reference["protocol"]:
                raise ValueError(f"{name}: addressed transmission protocol mismatch")
        else:
            for key in ("arch", "classifier_weights", "preprocessing", "quantization_range", "range_policy", "m_max", "grid"):
                if c["protocol"][key] != reference["protocol"][key]:
                    raise ValueError(f"{name}: classifier/quantization mismatch: {key}")


def paired_ablation_differences(result, resamples=10000):
    ids = result["sample_ids"]
    if len(ids) != result["n"] or not ids or len(ids) != len(set(ids)):
        raise ValueError("Need complete unique evaluation IDs")
    draws = np.random.default_rng(20261003).integers(len(ids), size=(resamples, len(ids)))
    output = {}
    for snr in result["snrs"]:
        correct = {}
        labels = None
        for name in VARIANTS:
            runs = [result["runs"][str(snr)][str(seed)][name]["predictions"] for seed in result["seeds"]]
            for rows in runs:
                if [r["sample_id"] for r in rows] != ids:
                    raise ValueError("Unpaired evaluation IDs")
                current_labels = [r["label"] for r in rows]
                if labels is not None and current_labels != labels:
                    raise ValueError("Unpaired evaluation labels")
                labels = current_labels
            correct[name] = np.asarray([[r["after"] == r["label"] for r in rows] for rows in runs])
        output[str(snr)] = {}
        for name in VARIANTS:
            if name == "addressed_full":
                continue
            delta = (correct["addressed_full"].astype(float)-correct[name]).mean(axis=0)
            low, high = np.quantile(delta[draws].mean(axis=1), [.025, .975])*100
            output[str(snr)][name] = {"difference_pp": float(delta.mean()*100),
                "image_bootstrap_95_pp": [float(low), float(high)],
                "positive_images": int((delta > 0).sum()), "negative_images": int((delta < 0).sum())}
    return {"resamples": resamples, "unit": "image; channel seeds kept together",
            "scope": "exploratory, conditional on fixed models and channel seeds; no multiplicity adjustment",
            "comparisons": output}
