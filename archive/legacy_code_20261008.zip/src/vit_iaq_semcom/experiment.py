"""Shared experiment contracts: budgets, splits, provenance and paired evaluation."""
from __future__ import annotations

import subprocess
import hashlib
from importlib.metadata import version, PackageNotFoundError
from pathlib import Path

import numpy as np


def parse_buckets(value: str) -> list[tuple[int, int]]:
    try:
        result = [tuple(map(int, item.split(":"))) for item in value.split(",")]
    except ValueError as exc:
        raise ValueError("Expected bucket configuration count:bits,count:bits") from exc
    if not result or any(len(item) != 2 for item in result):
        raise ValueError("Expected bucket configuration count:bits,count:bits")
    return result


def bit_accounting(*, payload=0, metadata=0, base=0, enhancement=0,
                   payload_r=1, metadata_r=1, base_r=1) -> dict[str, int]:
    from .fec import validate_repetition
    for rate in (payload_r, metadata_r, base_r):
        validate_repetition(rate)
    raw = dict(payload=int(payload), metadata=int(metadata), base=int(base),
               enhancement=int(enhancement))
    if min(raw.values()) < 0:
        raise ValueError("Bit lengths must be nonnegative")
    redundancy = payload * (payload_r - 1) + metadata * (metadata_r - 1) + base * (base_r - 1)
    return {**raw, "fec": int(redundancy), "total": int(sum(raw.values()) + redundancy)}


def split_indices(size: int, validation_size: int = 5000, seed: int = 0):
    if not 0 < validation_size < size:
        raise ValueError("validation_size must lie strictly between zero and dataset size")
    indices = np.random.default_rng(seed).permutation(size)
    return indices[validation_size:].tolist(), indices[:validation_size].tolist()


def provenance() -> dict:
    root = Path(__file__).resolve().parents[2]
    try:
        revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
        dirty = bool(subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True).strip())
    except (OSError, subprocess.CalledProcessError):
        revision, dirty = "unknown", None
    files = sorted((root / "src").rglob("*.py")) + sorted((root / "scripts").glob("*.py"))
    fingerprint = hashlib.sha256()
    for path in files:
        fingerprint.update(path.relative_to(root).as_posix().encode())
        fingerprint.update(path.read_bytes())
    packages = {}
    for package in ("torch", "numpy", "timm", "torchvision"):
        try:
            packages[package] = version(package)
        except PackageNotFoundError:
            packages[package] = "unavailable"
    return {"revision": revision, "dirty": dirty, "source_sha256": fingerprint.hexdigest(),
            "packages": packages, "experiment_schema": 2}


def protocol_config(pipe, m_base, base_fec_r, buckets) -> dict:
    return {"range_policy": pipe.range_policy, "quantization_range": list(pipe.quantization_range),
            "m_max": pipe.m_max, "m_base": m_base, "base_fec_r": base_fec_r,
            "buckets": [list(b) for b in buckets], "arch": pipe.enc.arch,
            "classifier_weights": getattr(pipe.enc, "weights_id", "unspecified"),
            "attention_arch": pipe._attn.arch,
            "attention_weights": getattr(pipe._attn, "weights_id", "unspecified"),
            "preprocessing": getattr(pipe.enc, "preprocessing", {})}


def check_protocol(expected: dict, actual: dict) -> None:
    if expected != actual:
        differences = [key for key in expected.keys() | actual.keys() if expected.get(key) != actual.get(key)]
        raise ValueError(f"Repair checkpoint protocol mismatch: {', '.join(sorted(differences))}")


def paired_repair_evaluation(pipe, net, loader, snr, m_base, base_fec_r, buckets, seed=0,
                             *, mode="bucket", location_fec_r=3, channel_budget=None):
    return paired_model_evaluation(pipe, {"repair": net}, loader, snr, m_base, base_fec_r,
        buckets, seed, mode=mode, location_fec_r=location_fec_r, channel_budget=channel_budget)["repair"]


def paired_model_evaluation(pipe, nets, loader, snr, m_base, base_fec_r, buckets, seed=0,
                            *, mode="bucket", location_fec_r=3, channel_budget=None):
    """Generate each corrupted batch once; evaluate both branches on identical inputs."""
    import torch
    if not nets:
        raise ValueError("No repair models supplied")
    rng = np.random.default_rng(seed)
    records_by_model = {name: [] for name in nets}
    for net in nets.values():
        net.eval()
    with torch.no_grad():
        for xb, yb in loader:
            recon, depth, state = pipe.repair_corrupt(xb.numpy(), snr, m_base, base_fec_r,
                                                     buckets, rng, xb.dtype, mode, location_fec_r)
            received = torch.as_tensor(recon, dtype=xb.dtype, device=pipe.enc.device)
            receiver = torch.as_tensor(state, dtype=xb.dtype, device=pipe.enc.device) if state is not None else None
            def predict(images):
                logits = pipe.enc.model(images)
                if not torch.isfinite(images).all() or not torch.isfinite(logits).all():
                    raise ValueError("Nonfinite reconstruction or classification during evaluation")
                return logits.argmax(1).cpu()
            before = predict(received)
            for name, net in nets.items():
                repaired = net(received, torch.as_tensor(depth, device=pipe.enc.device), receiver)
                after = predict(repaired)
                for i, (y, a, b) in enumerate(zip(yb, before, after)):
                    counts = pipe.last_bit_counts[i]
                    if channel_budget is not None and counts["total"] > channel_budget:
                        raise ValueError("Actual repair packet exceeds budget")
                    row = {"label": int(y), "before": int(a), "after": int(b), "bit_counts": counts}
                    if state is not None:
                        row["receiver_state"] = {"accepted_enhancement_patches": int(state[i, :, 0].sum()),
                                                  "erased_slot_fraction": float(state[i, 0, 1])}
                    records_by_model[name].append(row)
    if not next(iter(records_by_model.values())):
        raise ValueError("Evaluation dataset is empty")
    results = {}
    for name, records in records_by_model.items():
        before = np.array([r["before"] == r["label"] for r in records])
        after = np.array([r["after"] == r["label"] for r in records])
        results[name] = {mode: float(before.mean()), f"{mode}_repair": float(after.mean()),
            "ai_gain": float(after.mean() - before.mean()),
            "harmful_repair_rate": float((before & ~after).mean()),
            "rescued_rate": float((~before & after).mean()), "predictions": records}
    return results
