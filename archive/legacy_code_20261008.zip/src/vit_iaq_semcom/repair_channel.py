"""修补训练的传输协议与预算；不向网络提供发送端诊断真值。"""
from __future__ import annotations

import numpy as np

from .addressed import fit_addressed_buckets
from .bit_allocation import uniform_allocation
from .experiment import bit_accounting, protocol_config


def configure_repair_channel(pipe, mode, b_target, m_base, base_fec_r, buckets, location_fec_r=3):
    """B 表示总信道上限/每块标量数；显式方案从中支付定位开销。"""
    if mode not in ("bucket", "addressed", "uniform") or b_target < 1:
        raise ValueError("Invalid repair channel mode or budget")
    if pipe.range_policy != "fixed":
        raise ValueError("Repair channels require a fixed shared range")
    c, h, w = pipe.enc.preprocessing["input_size"]
    n, p = pipe.gh * pipe.gw, c * (h // pipe.gh) * (w // pipe.gw)
    cap = b_target * p
    if mode == "addressed":
        buckets, counts = fit_addressed_buckets(buckets, n, p, m_base, pipe.m_max,
                                                cap, location_fec_r, base_fec_r)
        pipe.b_target = sum(count * depth for count, depth in buckets)
    elif mode == "uniform":
        if base_fec_r != 1:
            raise ValueError("Uniform repair baseline does not use base-layer FEC")
        pipe.b_target = b_target
        buckets = []
        counts = bit_accounting(payload=int(uniform_allocation(n, b_target, pipe.m_max).sum()) * p)
    else:
        pipe.b_target = b_target
        pipe.validate_bucket_protocol(buckets, m_base, base_fec_r)
        counts = bit_accounting(base=n*p*m_base, enhancement=(b_target-n*m_base)*p,
                                base_r=base_fec_r)
    if counts["total"] > cap:
        raise ValueError("Repair training packet exceeds the channel budget including protection")
    return buckets, {**counts, "unused": cap-counts["total"], "cap": cap}


def repair_channel_protocol(pipe, mode, m_base, base_fec_r, buckets, location_fec_r=3):
    if mode == "bucket":
        return protocol_config(pipe, m_base, base_fec_r, buckets)
    if mode not in ("uniform", "addressed"):
        raise ValueError("Unknown repair channel")
    protocol = protocol_config(pipe, m_base if mode == "addressed" else 0,
                               base_fec_r if mode == "addressed" else 1,
                               buckets if mode == "addressed" else [])
    protocol.update(transmission_mode=mode, repair_transport_version=1,
                    source_budget=pipe.b_target, grid=[pipe.gh, pipe.gw],
                    receiver_features=["accepted_enhancement", "erased_slot_fraction"])
    if mode == "addressed":
        protocol.update(location_fec_r=location_fec_r, id_crc="crc8-poly07-init00-msb-zero-pad")
    return protocol


def training_snr(seed, epoch, batch_index, lo, hi):
    """独立于码流长度的难度序列；连续训练和续训、不同传输模式保持一致。"""
    rng = np.random.default_rng(np.random.SeedSequence([seed, epoch, batch_index, 739]))
    return float(rng.uniform(lo, hi))
