"""Exercise restart equivalence, model selection and bounded evaluation batches."""
import json
import random
import sys

import numpy as np
import pytest
import torch

from test_experiment_contracts import script
from test_pipeline_modes import FakeEncoder, _imgs
from vit_iaq_semcom.pipeline import IAQPipeline
from vit_iaq_semcom.training import capture_rng, restore_rng, save_checkpoint


@pytest.fixture
def tiny_experiment(monkeypatch):
    import torchvision

    class Encoder(FakeEncoder):
        def __init__(self):
            super().__init__()
            self.preprocessing = {"input_size": [3, 8, 8]}
            self.transform = None
            with torch.random.fork_rng():
                torch.manual_seed(71)
                self.model = torch.nn.Sequential(torch.nn.Flatten(), torch.nn.Linear(192, 2)).eval()

    class Dataset(torch.utils.data.Dataset):
        def __init__(self, *args, **kwargs):
            assert kwargs["train"]

        def __len__(self):
            return 9

        def __getitem__(self, index):
            return _imgs(1, index)[0], index % 2

    monkeypatch.setattr(torchvision.datasets, "CIFAR100", Dataset)
    pipes = []

    def pipeline(cls, cfg):
        pipe = IAQPipeline(Encoder(), m_max=4, b_target=28)
        pipes.append(pipe)
        return pipe

    monkeypatch.setattr(IAQPipeline, "from_config", classmethod(pipeline))
    return pipes


def train_args(directory, epochs, extra=()):
    return ["train", "--device", "cpu", "--n-train", "4", "--n-val", "3",
            "--validation-size", "3", "--epochs", str(epochs), "--batch", "2",
            "--dim", "12", "--depth", "1", "--heads", "3", "--b_target", "28",
            "--buckets", "4:3,4:2,8:1", "--eval-snrs", "0,6",
            "--out", str(directory / "metrics.json"), "--ckpt", str(directory / "weights.pt"), *extra]


def assert_nested_equal(left, right):
    if isinstance(left, torch.Tensor):
        assert torch.equal(left, right)
    elif isinstance(left, dict):
        assert left.keys() == right.keys()
        for key in left:
            assert_nested_equal(left[key], right[key])
    elif isinstance(left, (list, tuple)):
        assert len(left) == len(right)
        for a, b in zip(left, right):
            assert_nested_equal(a, b)
    else:
        assert left == right


def test_resume_matches_uninterrupted_training_and_keeps_earlier_best(tmp_path, monkeypatch, tiny_experiment):
    full, first, resumed = [tmp_path / name for name in ("full", "first", "resumed")]

    def run(directory, epochs, scores, extra=()):
        module = script("run_repair_train")
        actual_evaluate = module.paired_repair_evaluation
        sequence = iter(scores)

        def evaluate(*args, **kwargs):
            result = actual_evaluate(*args, **kwargs)
            # Force the first epoch to win, while training and noisy evaluation remain real.
            result["bucket_repair"] = next(sequence)
            return result

        monkeypatch.setattr(module, "paired_repair_evaluation", evaluate)
        monkeypatch.setattr(sys, "argv", train_args(directory, epochs, extra))
        module.main()

    run(full, 3, [.8, .8, .6, .6, .7, .7])
    run(first, 1, [.8, .8])
    # Disturb every global generator; resume must restore the trajectory.
    random.seed(912)
    np.random.seed(912)
    torch.manual_seed(912)
    run(resumed, 3, [.6, .6, .7, .7], ["--resume", str(first / "weights.last.pt")])
    load = lambda path: torch.load(path, weights_only=True, map_location="cpu")
    continuous, restart = load(full / "weights.last.pt"), load(resumed / "weights.last.pt")
    for key in ("state_dict", "optimizer", "rng_state", "history"):
        assert_nested_equal(continuous[key], restart[key])
    assert restart["epoch"] == 3
    best = load(resumed / "weights.pt")
    assert best["epoch"] == 1
    assert_nested_equal(best["state_dict"], load(first / "weights.pt")["state_dict"])
    metrics = json.loads((resumed / "metrics.json").read_text(encoding="utf8"))
    assert metrics["best_epoch"] == 1 and metrics["epochs"] == 3
    assert metrics["curve"]["0.0"]["bucket_repair"] == .8
    assert metrics["last_curve"]["0.0"]["bucket_repair"] == .7
    # Restarts must not silently change batching or training configuration.
    monkeypatch.setattr(sys, "argv", train_args(tmp_path / "invalid", 4,
        ["--resume", str(resumed / "weights.last.pt"), "--batch", "1"]))
    with pytest.raises(SystemExit):
        script("run_repair_train").main()


def test_rng_roundtrip_and_failed_save_preserves_previous_checkpoint(tmp_path, monkeypatch):
    rng, generator = np.random.default_rng(4), torch.Generator().manual_seed(7)
    state = capture_rng(rng, generator)

    def draws():
        return [random.random(), np.random.random(), rng.random(), torch.rand(4),
                torch.randperm(8, generator=generator)]

    expected = draws()
    path = tmp_path / "checkpoint.pt"
    save_checkpoint(state, path)
    restored = torch.load(path, weights_only=True)
    restore_rng(restored, rng, generator)
    assert_nested_equal(expected, draws())
    previous = path.read_bytes()

    def fail(value, stream):
        stream.write(b"incomplete checkpoint")
        raise OSError("simulated disk failure")

    monkeypatch.setattr(torch, "save", fail)
    with pytest.raises(OSError, match="disk failure"):
        save_checkpoint({}, path)
    assert path.read_bytes() == previous
    assert list(tmp_path.glob("*.tmp")) == []


@pytest.mark.parametrize("name,extra,keys", [
    ("run_bucket_probe", ["--buckets", "4:3,4:2,8:1"],
     ["base_acc_no_quant", "a_clean_uniform", "a_clean_incremental", "a_clean_bucket",
      "b_bucket_agreement", "b_acc_bucket_from_base", "b_spearman_mean"]),
    ("run_bucket_sweep", ["--configs", "4:3,4:2,8:1"], ["base_acc"]),
])
def test_probes_bound_batches_and_weight_short_final_batch(
        tmp_path, monkeypatch, tiny_experiment, name, extra, keys):
    results = []
    original = IAQPipeline.from_config
    active_limit = 5

    def create(cls, cfg):
        pipe = original(cfg)
        for attribute in ("classify", "attention_scores"):
            function = getattr(pipe.enc, attribute)

            def bounded(x, fn=function):
                assert len(x) <= active_limit
                return fn(x)

            monkeypatch.setattr(pipe.enc, attribute, bounded)
        return pipe

    monkeypatch.setattr(IAQPipeline, "from_config", classmethod(create))
    for batch in (5, 2):
        active_limit = batch
        output = tmp_path / f"{name}_{batch}.json"
        monkeypatch.setattr(sys, "argv", [name, "--device", "cpu", "--n", "5",
            "--validation-size", "5", "--b_target", "28", "--batch", str(batch),
            "--out", str(output), *extra])
        script(name).main()
        results.append(json.loads(output.read_text(encoding="utf8")))
    for key in keys:
        assert results[0][key] == pytest.approx(results[1][key])
    assert results[0]["sample_ids"] == results[1]["sample_ids"]
    if name == "run_bucket_probe":
        assert results[0]["transport_assignment"] == results[1]["transport_assignment"]
    else:
        assert results[0]["configs"][0]["mse"] == pytest.approx(results[1]["configs"][0]["mse"])


def test_plot_displays_saved_standard_deviation(tmp_path, monkeypatch):
    module = script("run_repair_sixline_experiment")
    from matplotlib.axes import Axes
    calls = []
    original = Axes.errorbar

    def errorbar(self, *args, **kwargs):
        calls.append(kwargs["yerr"])
        return original(self, *args, **kwargs)

    monkeypatch.setattr(Axes, "errorbar", errorbar)
    result = {"snr": [0, 6], "base_acc": .8, "b_target": 392,
              "acc": {"bucket": [.3, .6]}, "std": {"bucket": [.04, .02]}}
    module.plot_results(result, tmp_path / "curve.png")
    assert calls == [[.04, .02]]
    assert (tmp_path / "curve.png").stat().st_size > 1000
    assert not module.plt.get_fignums()
