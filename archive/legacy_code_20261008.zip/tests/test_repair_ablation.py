import copy
import json
import sys

import numpy as np
import pytest
import torch

from test_experiment_contracts import script
from test_pipeline_modes import _imgs, BUCKETS
from test_training_lifecycle import tiny_experiment, train_args, assert_nested_equal
from vit_iaq_semcom.ablation import VARIANTS, validate_ablation_checkpoints, paired_ablation_differences
from vit_iaq_semcom.experiment import paired_model_evaluation
from vit_iaq_semcom.pipeline import IAQPipeline
from vit_iaq_semcom.repair import SemanticRepairNet


@pytest.mark.parametrize("conditioning", ["full", "no_depth", "no_receiver", "none"])
def test_masks_preserve_initial_parameters_and_remove_only_declared_inputs(conditioning):
    config = dict(grid=(4, 4), patch_dim=(3, 2, 2), m_max=4, dim=12, depth=1, heads=3, receiver_conditioning=True)
    torch.manual_seed(39)
    full = SemanticRepairNet(**config)
    torch.manual_seed(39)
    net = SemanticRepairNet(**config, conditioning=conditioning).eval()
    assert_nested_equal(full.state_dict(), net.state_dict())
    with torch.no_grad():
        net.head.weight.normal_(0, .1)
    image, depth, receiver = _imgs(2), torch.ones(2, 16, dtype=torch.long), torch.zeros(2, 16, 2)
    output = net(image, depth, receiver)
    depth_changed = net(image, depth+1, receiver)
    receiver_changed = net(image, depth, receiver+1)
    assert torch.equal(output, depth_changed) == (conditioning in ("no_depth", "none"))
    assert torch.equal(output, receiver_changed) == (conditioning in ("no_receiver", "none"))
    output.sum().backward()
    if conditioning in ("no_depth", "none"):
        assert not torch.count_nonzero(net.depth_embed.weight.grad)
    if conditioning in ("no_receiver", "none"):
        assert not torch.count_nonzero(net.receiver_embed.weight.grad)


def test_multi_model_evaluation_reuses_corruption_and_rejects_nonfinite(monkeypatch, tiny_experiment):
    pipe = IAQPipeline.from_config({})
    original = pipe.repair_corrupt
    calls = []
    def corrupt(*args, **kwargs):
        calls.append(1)
        return original(*args, **kwargs)
    monkeypatch.setattr(pipe, "repair_corrupt", corrupt)
    observed = {}
    nets = {}
    for name in ("full", "no_depth", "none"):
        nets[name] = SemanticRepairNet(grid=(4, 4), patch_dim=(3, 2, 2), m_max=4, dim=12, depth=1,
                                       heads=3, receiver_conditioning=True, conditioning=name)
        observed[name] = []
        nets[name].register_forward_pre_hook(lambda m, args, key=name: observed[key].append(tuple(v.clone() for v in args)))
    loader = [(_imgs(2), torch.tensor([0, 1])), (_imgs(1), torch.tensor([0]))]
    result = paired_model_evaluation(pipe, nets, loader, 0, 1, 1, BUCKETS, mode="addressed")
    assert len(calls) == 2
    assert_nested_equal(observed["full"], observed["no_depth"])
    assert_nested_equal(observed["full"], observed["none"])
    assert all(v["ai_gain"] == 0 for v in result.values())
    with torch.no_grad():
        nets["full"].head.weight.fill_(float("nan"))
    with pytest.raises(ValueError, match="Nonfinite"):
        paired_model_evaluation(pipe, {"bad": nets["full"]}, loader, 0, 1, 1, BUCKETS, mode="addressed")


def test_ablation_training_evaluation_and_rejection(tmp_path, monkeypatch, tiny_experiment):
    checkpoints = {}
    for name, (mode, conditioning, regime) in VARIANTS.items():
        folder = tmp_path/name
        extra = ["--mode", mode, "--conditioning", conditioning, "--n-val", "2", "--ckpt", str(folder/"best.pt")]
        if regime == "single":
            extra += ["--snr-lo", "6", "--snr-hi", "6"]
        monkeypatch.setattr(sys, "argv", train_args(folder, 1, extra))
        script("run_repair_train").main()
        checkpoints[name] = torch.load(folder/"best.pt", weights_only=True)
    validate_ablation_checkpoints(checkpoints)
    # 不允许在续训中偷偷改变输入条件。
    monkeypatch.setattr(sys, "argv", train_args(tmp_path/"bad_resume", 2,
        ["--mode", "addressed", "--n-val", "2", "--resume", str(tmp_path/"addressed_none"/"best.last.pt")]))
    with pytest.raises(SystemExit):
        script("run_repair_train").main()
    for name, field, value, error in (("addressed_no_depth", "conditioning", "full", "conditioning"),
                                     ("addressed_single", "snr_train", [0., 12.], "SNR"),
                                     ("addressed_none", "train_indices", [], "train_indices")):
        bad = copy.deepcopy(checkpoints)
        bad[name]["training"][field] = value
        with pytest.raises(ValueError, match=error):
            validate_ablation_checkpoints(bad)
    output = tmp_path/"ablation.json"
    argv = ["ablation", "--checkpoint-root", str(tmp_path), "--n", "1", "--batch", "1",
            "--snrs", "0,6", "--seeds", "0,1", "--out", str(output)]
    monkeypatch.setattr(sys, "argv", argv)
    script("run_repair_ablation").main()
    result = json.loads(output.read_text(encoding="utf-8"))
    assert result["complete"] and result["sample_offset"] == 2
    for runs in result["runs"].values():
        for seed in runs.values():
            reference = seed["addressed_full"]["predictions"]
            for name in VARIANTS:
                if name.startswith("addressed"):
                    rows = seed[name]["predictions"]
                    assert [(r["before"], r["bit_counts"], r["receiver_state"]) for r in rows] == [
                        (r["before"], r["bit_counts"], r["receiver_state"]) for r in reference]
    one = copy.deepcopy(result)
    one["seeds"] = [0]
    repeated = copy.deepcopy(one)
    repeated["seeds"] = [0, 1, 2]
    for seeds in repeated["runs"].values():
        seeds["1"] = seeds["2"] = seeds["0"]
    assert paired_ablation_differences(one) == paired_ablation_differences(repeated)
    wrong = copy.deepcopy(result)
    wrong["runs"]["0.0"]["0"]["uniform_full"]["predictions"][0]["label"] += 1
    with pytest.raises(ValueError, match="labels"):
        paired_ablation_differences(wrong)
    monkeypatch.setattr(sys, "argv", argv+["--sample-offset", "0", "--out", str(tmp_path/"overlap.json")])
    with pytest.raises(SystemExit):
        script("run_repair_ablation").main()


def test_suite_is_plan_only_by_default_and_rejects_drift(tmp_path, monkeypatch):
    module = script("run_repair_suite")
    monkeypatch.setattr(module, "execute_plan", lambda *a: pytest.fail("No execution without --execute"))
    monkeypatch.setattr(sys, "argv", ["suite", "--out-dir", str(tmp_path), "--profile", "formal"])
    module.main()
    plan = json.loads((tmp_path/"plan.json").read_text())
    assert len(plan["jobs"]) == 21 and plan["training_seeds"] == [0, 1, 2]
    assert plan["evaluation_offset"] == 1000
    assert plan["settings"]["device"] == "cuda"
    assert sum(j["kind"] == "train" for j in plan["jobs"]) == 18
    monkeypatch.setattr(sys, "argv", ["suite", "--out-dir", str(tmp_path), "--profile", "formal", "--batch", "1"])
    with pytest.raises(SystemExit):
        module.main()


def test_suite_skips_only_verified_outputs_and_stops_on_failure(tmp_path, monkeypatch):
    module = script("run_repair_suite")
    job = dict(id="first", kind="evaluate", argv=["dummy"], outputs=[str(tmp_path/"data.json")], log=str(tmp_path/"job.log"))
    plan = {"jobs": [job], "settings": {"epochs": 1}}
    calls = []
    def run(*args, **kwargs):
        calls.append(1)
        (tmp_path/"data.json").write_text("{}")
    monkeypatch.setattr(module.subprocess, "run", run)
    module.execute_plan(plan, tmp_path)
    module.execute_plan(plan, tmp_path)
    assert calls == [1]
    (tmp_path/"data.json").write_text("changed")
    with pytest.raises(ValueError, match="changed"):
        module.execute_plan(plan, tmp_path)
    def fail(*args, **kwargs):
        raise RuntimeError("child failed")
    monkeypatch.setattr(module.subprocess, "run", fail)
    failure = tmp_path/"failure"
    failure.mkdir()
    badjob = {**job, "id": "bad", "outputs": [str(failure/"data.json")], "log": str(failure/"job.log")}
    with pytest.raises(RuntimeError, match="child failed"):
        module.execute_plan({"jobs": [badjob, job]}, failure)
    state = json.loads((failure/"state.json").read_text())
    assert state["jobs"]["bad"]["status"] == "failed" and "first" not in state["jobs"]


def test_suite_resumes_incomplete_epoch_but_does_not_silently_accept_unverified_completion(tmp_path, monkeypatch):
    module = script("run_repair_suite")
    latest = tmp_path/"best.last.pt"
    torch.save({"epoch": 1}, latest)
    job = dict(id="train", kind="train", argv=["dummy"], outputs=[str(latest)],
               last_checkpoint=str(latest), log=str(tmp_path/"run.log"))
    calls = []
    monkeypatch.setattr(module.subprocess, "run", lambda command, **kwargs: calls.append(command))
    module.execute_plan({"jobs": [job], "settings": {"epochs": 2}}, tmp_path)
    assert calls[0][-3:] == ["--resume", str(latest), "--overwrite"]
    other = tmp_path/"unverified"
    other.mkdir()
    torch.save({"epoch": 2}, other/"last.pt")
    completed = {**job, "outputs": [str(other/"last.pt")], "last_checkpoint": str(other/"last.pt")}
    with pytest.raises(ValueError, match="without verified suite state"):
        module.execute_plan({"jobs": [completed], "settings": {"epochs": 2}}, other)
