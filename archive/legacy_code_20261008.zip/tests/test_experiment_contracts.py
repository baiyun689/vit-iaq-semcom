"""Regression tests for scientific experiment contracts, with no model downloads."""
import importlib.util
import sys
from pathlib import Path

import numpy as np
import pytest
import torch

from test_pipeline_modes import FakeEncoder, BUCKETS, _imgs, _pipe, _repair_net
from vit_iaq_semcom.bucket import bucket_encode, bucket_decode, assignment_diagnostics, bits_per_rank
from vit_iaq_semcom.channel import pack_metadata
from vit_iaq_semcom.experiment import split_indices, protocol_config, paired_repair_evaluation
from vit_iaq_semcom.fec import repetition_encode, repetition_decode, repetition_decoded_ber
from vit_iaq_semcom.pipeline import IAQPipeline


def script(name):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).resolve().parents[1] / "scripts" / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_actual_packet_budget_includes_base_fec():
    pipe = _pipe(28)
    plain = pipe.run_batch(_imgs(), mode="bucket", channel_type="awgn", buckets=BUCKETS)
    fec = pipe.run_batch(_imgs(), mode="bucket", channel_type="awgn", buckets=BUCKETS, base_fec_r=3)
    for a, b in zip(plain["bit_counts"], fec["bit_counts"]):
        assert a["total"] == 28 * 12
        assert b["total"] == (28 + 16 * 2) * 12
        assert b["fec"] == 16 * 12 * 2


def test_actual_metadata_and_experiment_budget():
    meta = pack_metadata(np.ones(196, dtype=int), 0, 1, 8)
    assert len(meta) == 816
    module = script("run_repair_sixline_experiment")
    budget = module.source_budget(392 * 768, 768, len(meta), 3)
    assert budget * 768 + 816 * 3 <= 392 * 768
    pipe = _pipe(28)
    loader = [(_imgs(), torch.zeros(4, dtype=torch.long))]
    with pytest.raises(ValueError, match="exceeds budget"):
        module.evaluate(pipe, loader, 6, channel_budget=28 * 12, mode="bucket",
                        buckets=BUCKETS, base_fec_r=3, b_target=28)
    assert pipe.b_target == 28


def test_fixed_range_is_independent_of_current_image():
    pipe = _pipe(28)
    a = np.ones(16)
    p1 = pipe.encode(_imgs()[0].numpy(), a)
    p2 = pipe.encode((_imgs()[0] * 0.1).numpy(), a)
    assert (p1.umin, p1.umax) == (p2.umin, p2.umax) == (0.0, 1.0)
    pipe.range_policy = "image_minmax"
    with pytest.raises(ValueError, match="fixed shared"):
        pipe.run_batch(_imgs(), mode="bucket", channel_type="awgn", buckets=BUCKETS)


def test_same_bucket_swap_changes_values_and_is_counted():
    x = np.array([[.1], [.4], [.6], [.9]])
    tx, rx = np.array([4., 3., 2., 1.]), np.array([3., 4., 2., 1.])
    buckets = [(4, 3)]
    pkt = bucket_encode(x, tx, 0, 1, 1, buckets, 8)
    before, after = bucket_decode(pkt, tx), bucket_decode(pkt, rx)
    assert np.count_nonzero(before != after) == 2
    metrics = assignment_diagnostics(tx, rx, buckets, 1)
    assert metrics["bucket_mismatch_rate"] == 0
    assert metrics["enhancement_assignment_error_rate"] == .5
    assert metrics["misassigned_slot_count"] == 2


@pytest.mark.parametrize("kwargs", [dict(mode="typo"), dict(channel_type="typo"),
    dict(mode="bucket", channel_type="bsc"), dict(mode="bucket", channel_type="awgn", buckets=[(16, 2)]),
    dict(mode="bucket", channel_type="awgn", buckets=BUCKETS, m_base=2), dict(base_fec_r=2)])
def test_invalid_protocols_are_rejected(kwargs):
    with pytest.raises(ValueError):
        _pipe(28).run_batch(_imgs(), **kwargs)


@pytest.mark.parametrize("buckets", [[(15, 2)], [(17, 2)], [], [(16, 0)], [(16.0, 2)]])
def test_bucket_framing_must_match(buckets):
    with pytest.raises(ValueError):
        bits_per_rank(buckets, 16)


def test_truncated_bucket_packet_is_rejected():
    pkt = bucket_encode(np.ones((4, 2)), np.arange(4), 0, 1, 1, [(4, 2)], 8)
    pkt.enh_bits = pkt.enh_bits[:-1]
    with pytest.raises(ValueError, match="length"):
        bucket_decode(pkt, np.arange(4))


@pytest.mark.parametrize("rate", [0, -1, 2, 4, 1.5, True])
def test_all_fec_entrypoints_reject_invalid_rates(rate):
    for fn, args in [(repetition_encode, (np.array([0]),)), (repetition_decode, (np.array([0]),)),
                     (repetition_decoded_ber, (.1,))]:
        with pytest.raises(ValueError):
            fn(*args, rate)


def test_data_split_is_deterministic_and_disjoint():
    train, validation = split_indices(100, 20, 3)
    assert (train, validation) == split_indices(100, 20, 3)
    assert not set(train) & set(validation)
    assert set(train) | set(validation) == set(range(100))


def test_checkpoint_roundtrip_and_protocol_rejection(tmp_path):
    pipe = _pipe(28)
    config = dict(grid=(4, 4), patch_dim=(3, 2, 2), m_max=4, dim=24, depth=2, heads=2)
    protocol = protocol_config(pipe, 1, 1, BUCKETS)
    checkpoint = tmp_path / "repair.pt"
    net = _repair_net()
    torch.save(dict(schema_version=2, net_config=config, protocol=protocol, state_dict=net.state_dict()), checkpoint)
    pipe.load_repair_net(str(checkpoint))
    pipe.validate_repair_protocol(1, 1, BUCKETS)
    with pytest.raises(ValueError, match="protocol mismatch"):
        pipe.validate_repair_protocol(1, 3, BUCKETS)
    torch.save(net.state_dict(), checkpoint)
    with pytest.raises(ValueError, match="Legacy"):
        pipe.load_repair_net(str(checkpoint))


def test_training_entrypoint_streams_and_writes_loadable_checkpoint(tmp_path, monkeypatch):
    import torchvision
    dataset_splits = []
    class Encoder(FakeEncoder):
        def __init__(self):
            super().__init__()
            self.preprocessing = {"input_size": [3, 8, 8], "mean": [0, 0, 0], "std": [1, 1, 1]}
            self.transform = None
            self.model = torch.nn.Sequential(torch.nn.Flatten(), torch.nn.Linear(192, 2)).eval()
    class Dataset(torch.utils.data.Dataset):
        def __init__(self, *args, **kwargs):
            dataset_splits.append(kwargs["train"])
        def __len__(self): return 8
        def __getitem__(self, index): return _imgs(1, index)[0], index % 2
    encoder = Encoder()
    pipe = IAQPipeline(encoder, m_max=4, b_target=28)
    monkeypatch.setattr(IAQPipeline, "from_config", classmethod(lambda cls, cfg: pipe))
    monkeypatch.setattr(torchvision.datasets, "CIFAR100", Dataset)
    out, ckpt = tmp_path / "metrics.json", tmp_path / "weights.pt"
    monkeypatch.setattr(sys, "argv", ["train", "--device", "cpu", "--n-train", "4", "--n-val", "2",
        "--validation-size", "2", "--epochs", "1", "--batch", "2", "--dim", "12", "--depth", "1",
        "--heads", "3", "--b_target", "28", "--buckets", "4:3,4:2,8:1", "--eval-snrs", "0,6",
        "--out", str(out), "--ckpt", str(ckpt)])
    script("run_repair_train").main()
    assert dataset_splits == [True]  # Training must never tune against CIFAR test.
    pipe.load_repair_net(str(ckpt))
    pipe.validate_repair_protocol(1, 1, BUCKETS)
    import json
    result = json.loads(out.read_text(encoding="utf8"))
    assert not set(result["train_indices"]) & set(result["validation_indices"])
    assert result["evaluation_split"] == "validation"
    # An identity repair must produce exactly paired predictions on noisy inputs.
    identity = _repair_net()
    paired = paired_repair_evaluation(pipe, identity, [(_imgs(), torch.zeros(4, dtype=torch.long))],
                                      0, 1, 1, BUCKETS, seed=5)
    assert paired["ai_gain"] == paired["harmful_repair_rate"] == 0
    assert all(row["before"] == row["after"] for row in paired["predictions"])
    # Exercise the actual six-line CLI, including checkpoint compatibility, budgets,
    # held-out test split, repeated seeds and JSON serialization.
    comparison = script("run_repair_sixline_experiment")
    monkeypatch.setattr(comparison, "plot_results", lambda *args: None)
    output = tmp_path / "comparison.png"
    monkeypatch.setattr(sys, "argv", ["compare", "--device", "cpu", "--n", "4", "--batch", "2",
        "--b_target", "28", "--buckets", "4:3,4:2,8:1", "--snr", "6", "--seeds", "0,1",
        "--repair-ckpt", str(ckpt), "--out", str(output)])
    comparison.main()
    results = json.loads(output.with_suffix(".json").read_text(encoding="utf8"))
    assert dataset_splits == [True, False]
    assert len(results["acc"]) == 6
    assert results["seeds"] == [0, 1]
    for branch in results["runs"]["6.0"].values():
        assert all(result["channel_bits"]["max"] <= 28 * 12 for result in branch)
    # Configuration search and attribution probes must use the same validation split.
    for name, extra in [("run_bucket_sweep", ["--configs", "4:3,4:2,8:1"]),
                        ("run_bucket_probe", ["--buckets", "4:3,4:2,8:1"])]:
        destination = tmp_path / f"{name}.json"
        monkeypatch.setattr(sys, "argv", [name, "--device", "cpu", "--n", "2", "--b_target", "28",
                                         "--validation-size", "2", "--out", str(destination), *extra])
        script(name).main()
        artifact = json.loads(destination.read_text(encoding="utf8"))
        assert artifact["evaluation_split"] == "validation"
        assert artifact["sample_ids"] == result["validation_indices"]
