from dataclasses import replace

import numpy as np
import pytest

from vit_iaq_semcom.addressed import (
    addressed_encode, addressed_decode, addressed_through_channel, encode_id, decode_ids,
    fit_addressed_buckets, addressed_bit_counts, location_diagnostics, crc8,
)
from vit_iaq_semcom.bucket import bucket_decode, bucket_decode_base, bucket_through_channel
from test_pipeline_modes import _pipe, _imgs, BUCKETS


def packet(r=3, buckets=None):
    x = np.random.default_rng(4).uniform(0, 1, (5, 12))
    scores = np.array([1., 5., 3., 2., 4.])
    return addressed_encode(x, scores, 0, 1, 1, buckets or [(3, 3), (2, 1)], 4, r), scores


def test_noiseless_reconstruction_matches_sender_rank_without_receiver_attention():
    sent, scores = packet()
    rx = addressed_through_channel(sent, np.inf, np.random.default_rng(0))
    recon, depth, diag = addressed_decode(rx)
    np.testing.assert_array_equal(recon, bucket_decode(sent.payload, scores))
    assert depth.tolist() == [1, 3, 3, 1, 3]
    assert diag["accepted_records"] == 3
    assert diag["erased_records"] == 0
    assert location_diagnostics(sent, rx)["undetected_wrong_records"] == 0


def test_corrupt_id_erases_one_slot_without_shifting_later_payload():
    sent, _ = packet(r=1, buckets=[(1, 4), (1, 3), (1, 2), (2, 1)])
    headers = sent.headers.copy()
    headers[0] ^= 1  # ID bit flips while CRC is unchanged.
    damaged = replace(sent, headers=headers)
    clean, _, _ = addressed_decode(sent)
    recon, depth, diag = addressed_decode(damaged)
    assert diag["crc_failures"] == diag["erased_records"] == 1
    np.testing.assert_array_equal(recon[1], bucket_decode_base(sent.payload)[1])
    np.testing.assert_array_equal(recon[[0, 2, 3, 4]], clean[[0, 2, 3, 4]])
    assert depth[1] == 1


def test_duplicates_are_all_erased_and_valid_wrong_ids_are_not_oracle_corrected():
    sent, _ = packet(r=1)
    header_len = len(sent.headers) // 3
    headers = sent.headers.copy()
    headers[header_len:2*header_len] = headers[:header_len]
    recon, depth, diag = addressed_decode(replace(sent, headers=headers))
    assert diag["duplicate_records"] == diag["erased_records"] == 2
    assert depth[1] == depth[4] == 1
    headers = sent.headers.copy()
    headers[:header_len] = encode_id(0, 5, 1)  # Valid but wrong codeword: CRC cannot catch it.
    rx = replace(sent, headers=headers)
    _, depth, diag = addressed_decode(rx)
    assert depth[0] == 3 and depth[1] == 1
    assert diag["erased_records"] == 0
    assert location_diagnostics(sent, rx)["undetected_wrong_records"] == 1


def test_protection_and_length_validation():
    sent, _ = packet()
    headers = sent.headers.copy()
    headers[::3] ^= 1  # One flip per repetition group is correctable.
    np.testing.assert_array_equal(addressed_decode(replace(sent, headers=headers))[0], addressed_decode(sent)[0])
    with pytest.raises(ValueError, match="length"):
        addressed_decode(replace(sent, headers=sent.headers[:-1]))
    with pytest.raises(ValueError, match="binary"):
        addressed_decode(replace(sent, headers=np.full_like(sent.headers, 2)))
    with pytest.raises(ValueError, match="positive odd"):
        packet(r=2)


def test_out_of_range_id_with_valid_crc_is_erased():
    from vit_iaq_semcom.quantization import index_to_bits
    sent, _ = packet(r=1)
    bits = index_to_bits(7, 3)  # n=5, but three ID bits represent 0..7.
    headers = sent.headers.copy()
    headers[:11] = np.concatenate([bits, index_to_bits(crc8(bits), 8)])
    ids, diag = decode_ids(replace(sent, headers=headers))
    assert ids[0] is None and diag["out_of_range_ids"] == 1


def test_actual_lengths_pay_for_headers_under_original_channel_cap():
    buckets, counts = fit_addressed_buckets([(98, 3), (98, 1)], 196, 768, 1, 8, 392*768)
    assert buckets == [(95, 3), (101, 1)]
    assert counts == dict(base=150528, enhancement=145920, metadata=760, checksum=760,
                          fec=3040, total=301008, unused=48)
    pkt = addressed_encode(np.zeros((196, 768)), np.arange(196), 0, 1, 1, buckets, 8)
    assert len(pkt.payload.base_bits) + len(pkt.payload.enh_bits) + len(pkt.headers) == counts["total"]
    with pytest.raises(ValueError, match="base layer"):
        fit_addressed_buckets([(5, 2)], 5, 12, 1, 4, 59)
    bare, counts = fit_addressed_buckets([(5, 2)], 5, 12, 1, 4, 60)
    assert bare == [(5, 1)] and counts["metadata"] == 0
    sent, _ = packet(buckets=[(5, 1)])
    assert len(sent.headers) == 0
    assert addressed_decode(sent)[2]["accepted_records"] == 0


def test_payload_noise_is_shared_with_same_precision_implicit_branch():
    sent, _ = packet()
    addressed = addressed_through_channel(sent, 0, np.random.default_rng(91))
    implicit = bucket_through_channel(sent.payload, 0, np.random.default_rng(91))
    np.testing.assert_array_equal(addressed.payload.base_bits, implicit.base_bits)
    np.testing.assert_array_equal(addressed.payload.enh_bits, implicit.enh_bits)


def test_addressed_pipeline_mode_and_actual_budget():
    pipe = _pipe(28)
    out = pipe.run_batch(_imgs(), mode="addressed", channel_type="awgn", buckets=BUCKETS,
                         ebn0_db=np.inf)
    expected = pipe.run_batch(_imgs(), mode="bucket", channel_type="awgn", buckets=BUCKETS,
                             ebn0_db=np.inf)
    assert out["recon_mse"] == pytest.approx(expected["recon_mse"])
    counts = addressed_bit_counts(BUCKETS, 16, 12, 1)
    assert out["bit_counts"] == [counts] * 4
    assert all(row["accepted_records"] == 8 for row in out["diagnostics"])


def test_experiment_pairs_samples_independent_of_batch_size():
    import torch
    from test_experiment_contracts import script
    module = script("run_addressed_experiment")
    pipe = _pipe(28)
    images, labels, ids = _imgs(3), torch.tensor([0, 1, 0]), [13, 71, 92]
    adjusted, _ = fit_addressed_buckets(BUCKETS, 16, 12, 1, 4, 28 * 12)
    args = ([0., 6.], [0, 1], BUCKETS, BUCKETS, adjusted, 1, 3, 28 * 12)
    full = module.evaluate_batch(pipe, images, labels, ids, *args)
    pieces = [module.evaluate_batch(pipe, images[s:e], labels[s:e], ids[s:e], *args)
              for s, e in [(0, 2), (2, 3)]]
    for key, branches in full.items():
        for branch, rows in branches.items():
            assert rows == pieces[0][key][branch] + pieces[1][key][branch]
            assert all(row["bit_counts"]["total"] <= 28 * 12 for row in rows)
    # At very high SNR all valid IDs arrive, matching the oracle with identical payload.
    clean = module.evaluate_batch(pipe, images, labels, ids, [100.], [0], *args[2:])
    actual, oracle = clean[("100.0", "0")]["addressed"], clean[("100.0", "0")]["oracle"]
    assert [row["recon_mse"] for row in actual] == [row["recon_mse"] for row in oracle]
    for row in actual:
        assert row["diagnostics"]["erased_records"] == 0


def test_validation_window_and_image_level_pairing():
    from test_experiment_contracts import script
    module = script("run_addressed_experiment")
    assert module.select_validation_ids(list(range(150)), 96, 24) == list(range(24, 120))
    for n, offset in ((0, 0), (3, -1), (96, 80)):
        with pytest.raises(ValueError):
            module.select_validation_ids(list(range(150)), n, offset)
    # Three repeated noise seeds must not change the image resampling distribution.
    def make(seeds):
        branches = {name: [{"sample_id": i, "label": 1, "prediction": int(i % 2 == 0)}
                           for i in range(4)] for name in module.LABELS}
        branches["addressed"] = [{"sample_id": i, "label": 1, "prediction": 1} for i in range(4)]
        return dict(n=4, sample_ids=list(range(4)), snrs=[6.], seeds=seeds,
                    runs={"6.0": {str(seed): branches for seed in seeds}})
    one = module.paired_differences(make([0]), n_resamples=1000)
    three = module.paired_differences(make([0, 1, 2]), n_resamples=1000)
    assert one == three
    point = three["comparisons"]["6.0"]["uniform"]
    assert point["mean_difference_pp"] == 50
    assert (point["positive_images"], point["negative_images"], point["tied_images"]) == (2, 0, 2)
    bad = make([0])
    bad["runs"]["6.0"]["0"]["uniform"].reverse()
    with pytest.raises(ValueError, match="Unpaired"):
        module.paired_differences(bad)
