"""真实编解码、小分类器：新修补协议的泄漏边界、预算和可恢复训练。"""
import copy
import json
import sys
from dataclasses import replace

import numpy as np
import pytest
import torch

from test_experiment_contracts import script
from test_pipeline_modes import BUCKETS, _imgs, _pipe
from test_training_lifecycle import tiny_experiment, train_args, assert_nested_equal
from vit_iaq_semcom.experiment import paired_repair_evaluation
from vit_iaq_semcom.repair import SemanticRepairNet
from vit_iaq_semcom.repair_channel import configure_repair_channel, repair_channel_protocol, training_snr


def test_receiver_state_uses_only_received_ids_and_global_erasure(monkeypatch):
    import vit_iaq_semcom.addressed as codec
    pipe = _pipe(28)
    def damage(sent, *args):
        headers = sent.headers.copy()
        headers[0] ^= 1  # r=1，一条编号 CRC 不通过；不得用真实编号给它定位。
        return replace(sent, headers=headers)
    monkeypatch.setattr(codec, "addressed_through_channel", damage)
    # 仿真诊断故意填入不可能数值，不得成为网络条件。
    monkeypatch.setattr(codec, "location_diagnostics", lambda *a: {"erased_records": 9999})
    recon, depth, state = pipe.repair_corrupt(_imgs().numpy(), 0, 1, 1, BUCKETS,
                                              np.random.default_rng(0), torch.float32, "addressed", 1)
    assert np.isfinite(recon).all()
    np.testing.assert_array_equal(state[:, :, 0], depth > 1)
    assert np.all(state[:, :, 1] == 1 / 8)
    assert np.all(state[:, :, 0].sum(axis=1) == 7)


def test_uniform_does_not_use_attention_and_records_unused_budget(monkeypatch, tiny_experiment):
    from vit_iaq_semcom.pipeline import IAQPipeline
    pipe = IAQPipeline.from_config({})
    buckets, counts = configure_repair_channel(pipe, "uniform", 28, 1, 1, BUCKETS)
    monkeypatch.setattr(pipe.enc, "attention_scores", lambda *a: pytest.fail("Uniform must not use attention"))
    recon, depth, state = pipe.repair_corrupt(_imgs().numpy(), 6, 1, 1, buckets,
                                              np.random.default_rng(4), torch.float32, "uniform")
    assert np.all(depth == 1) and not state.any()
    assert counts["total"] == 192 and counts["unused"] == 144
    assert pipe.last_bit_counts[0]["total"] == counts["total"]
    with pytest.raises(ValueError, match="base-layer FEC"):
        configure_repair_channel(pipe, "uniform", 28, 1, 3, BUCKETS)


def test_conditioned_identity_and_receiver_state_changes_trained_output():
    net = SemanticRepairNet(grid=(4, 4), patch_dim=(3, 2, 2), m_max=4,
                            dim=12, depth=1, heads=3, receiver_conditioning=True).eval()
    x, depth = _imgs(2), torch.ones(2, 16, dtype=torch.long)
    state = torch.zeros(2, 16, 2)
    assert torch.equal(net(x, depth, state), x)
    with torch.no_grad():
        net.head.weight.normal_(0, .1)
    assert not torch.equal(net(x, depth, state), net(x, depth, torch.ones_like(state)))
    for bad in (None, torch.zeros(2, 16, 1), torch.full_like(state, float("nan")), state-1):
        with pytest.raises(ValueError, match="receiver state"):
            net(x, depth, bad)


@pytest.mark.parametrize("mode", ["addressed", "uniform"])
def test_new_training_resume_and_checkpoint_inference(tmp_path, monkeypatch, tiny_experiment, mode):
    first, resumed, full = [tmp_path / key for key in ("first", "resumed", "full")]
    extra = ["--mode", mode]
    for path, epochs, resume in ((first, 1, []), (resumed, 2, ["--resume", str(first/"weights.last.pt")]),
                                 (full, 2, [])):
        monkeypatch.setattr(sys, "argv", train_args(path, epochs, extra+resume))
        script("run_repair_train").main()
    load = lambda p: torch.load(p, weights_only=True, map_location="cpu")
    a, b = load(resumed/"weights.last.pt"), load(full/"weights.last.pt")
    for key in ("state_dict", "optimizer", "rng_state", "history"):
        assert_nested_equal(a[key], b[key])
    assert a["net_config"]["receiver_conditioning"]
    assert a["protocol"]["transmission_mode"] == mode
    assert not torch.equal(a["state_dict"]["head.weight"], torch.zeros_like(a["state_dict"]["head.weight"]))
    pipe = tiny_experiment[-1]
    assert all(not p.requires_grad and p.grad is None for p in pipe.enc.model.parameters())
    result = json.loads((full/"metrics.json").read_text())
    counts = result["channel_budget"]
    assert counts["total"] <= counts["cap"] == 336
    assert all(row["bit_counts"]["total"] == counts["total"]
               for point in result["curve"].values() for row in point["predictions"])
    pipe.load_repair_net(str(full/"weights.pt"))
    buckets = result["buckets"]
    pipe.validate_repair_protocol(1, 1, buckets, mode)
    with pytest.raises(ValueError, match="protocol mismatch"):
        pipe.validate_repair_protocol(1, 1, buckets, "bucket")
    if mode == "addressed":
        with pytest.raises(ValueError, match="protocol mismatch"):
            pipe.validate_repair_protocol(1, 1, buckets, mode, 5)
    # 零初始化的修补器既不改变预测，也不增加实际发送量。
    identity = SemanticRepairNet(**a["net_config"])
    pipe.repair_net = identity
    paired = paired_repair_evaluation(pipe, identity, [(_imgs(), torch.zeros(4, dtype=torch.long))],
                                      0, 1, 1, buckets, mode=mode, channel_budget=336)
    assert paired["ai_gain"] == paired["harmful_repair_rate"] == paired["rescued_rate"] == 0
    plain = pipe.run_batch(_imgs(), mode=mode, channel_type="awgn", ebn0_db=0, buckets=buckets)
    fixed = pipe.run_batch(_imgs(), mode=mode+"+repair", channel_type="awgn", ebn0_db=0, buckets=buckets)
    assert plain["recon_mse"] == fixed["recon_mse"] and plain["bit_counts"] == fixed["bit_counts"]


def test_training_snr_schedule_does_not_depend_on_channel_rng():
    schedule = [training_snr(4, ep, step, 0, 12) for ep in range(3) for step in range(4)]
    np.random.default_rng(4).normal(size=100000)
    assert schedule == [training_snr(4, ep, step, 0, 12) for ep in range(3) for step in range(4)]
    assert schedule[4:] == [training_snr(4, ep, step, 0, 12) for ep in range(1, 3) for step in range(4)]


def test_fourline_comparison_checks_fairness_and_excludes_selection_data(tmp_path, monkeypatch, tiny_experiment):
    paths = {}
    for mode in ("addressed", "uniform"):
        folder = tmp_path/mode
        monkeypatch.setattr(sys, "argv", train_args(folder, 1, ["--mode", mode, "--n-val", "2"]))
        script("run_repair_train").main()
        paths[mode] = folder/"weights.pt"
    module = script("run_repair_comparison")
    output = tmp_path/"comparison.json"
    argv = ["compare", "--addressed-ckpt", str(paths["addressed"]), "--uniform-ckpt", str(paths["uniform"]),
            "--n", "1", "--batch", "1", "--snrs", "0,6", "--seeds", "0,1", "--out", str(output)]
    monkeypatch.setattr(sys, "argv", argv)
    module.main()
    result = json.loads(output.read_text(encoding="utf-8"))
    assert result["complete"] and result["sample_offset"] == 2
    checkpoints = {mode: torch.load(path, weights_only=True) for mode, path in paths.items()}
    selected = checkpoints["addressed"]["training"]["validation_indices"]
    assert not set(result["sample_ids"]) & set(selected)
    for modes in result["runs"].values():
        for mode, seeds in modes.items():
            for run in seeds.values():
                assert [r["sample_id"] for r in run["predictions"]] == result["sample_ids"]
                assert run["ai_gain"] == pytest.approx(run["rescued_rate"]-run["harmful_repair_rate"])
                assert run["predictions"][0]["bit_counts"]["total"] == result["budgets"][mode]["total"]
    assert output.with_suffix(".png").exists() and output.with_suffix(".md").exists()
    mismatch = copy.deepcopy(checkpoints)
    mismatch["uniform"]["selection_run"]["completed_epochs"] += 1
    with pytest.raises(ValueError, match="training epochs"):
        module.validate_comparable(mismatch)
    mismatch = copy.deepcopy(checkpoints)
    mismatch["uniform"]["training"]["train_indices"] = []
    with pytest.raises(ValueError, match="train_indices"):
        module.validate_comparable(mismatch)
    monkeypatch.setattr(sys, "argv", argv+["--out", str(tmp_path/"bad.json"), "--sample-offset", "0"])
    with pytest.raises(SystemExit):
        module.main()
